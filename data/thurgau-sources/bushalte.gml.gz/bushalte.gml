<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver http://ows.geo.tg.ch/geofy_access_proxy/oev?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:bushalte&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-09-08T19:59:20" numberMatched="718" numberReturned="718">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
      		<gml:lowerCorner>2691259.678000 1250681.093000</gml:lowerCorner>
      		<gml:upperCorner>2752535.454000 1282478.138000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723706.679000 1281201.887000</gml:lowerCorner>
        		<gml:upperCorner>2723706.679000 1281201.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.694.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723706.679000 1281201.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>694</ms:objectid>
        <ms:id_didok>8573355</ms:id_didok>
        <ms:name>Ermatingen, Bahnhof</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730080.066000 1279394.804000</gml:lowerCorner>
        		<gml:upperCorner>2730080.066000 1279394.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.329.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730080.066000 1279394.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>329</ms:objectid>
        <ms:id_didok>8573376</ms:id_didok>
        <ms:name>Kreuzlingen, Bahnhof</ms:name>
        <ms:linien_nummer>80.920, 80.923, 80.925, BN820</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737097.089000 1264854.667000</gml:lowerCorner>
        		<gml:upperCorner>2737097.089000 1264854.667000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.769.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737097.089000 1264854.667000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>769</ms:objectid>
        <ms:id_didok>8587224</ms:id_didok>
        <ms:name>Zihlschlacht, Mitteldorf
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736917.608000 1264598.197000</gml:lowerCorner>
        		<gml:upperCorner>2736917.608000 1264598.197000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.770.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736917.608000 1264598.197000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>770</ms:objectid>
        <ms:id_didok>8587222</ms:id_didok>
        <ms:name>Zihlschlacht, Rehaklinik
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736570.896000 1263428.697000</gml:lowerCorner>
        		<gml:upperCorner>2736570.896000 1263428.697000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.771.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736570.896000 1263428.697000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>771</ms:objectid>
        <ms:id_didok>8587213</ms:id_didok>
        <ms:name>Sitterdorf, Landhaus
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736389.390000 1263155.675000</gml:lowerCorner>
        		<gml:upperCorner>2736389.390000 1263155.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.772.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736389.390000 1263155.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>772</ms:objectid>
        <ms:id_didok>8587211</ms:id_didok>
        <ms:name>Sitterdorf, Bahnhof
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736209.982000 1262836.095000</gml:lowerCorner>
        		<gml:upperCorner>2736209.982000 1262836.095000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.773.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736209.982000 1262836.095000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>773</ms:objectid>
        <ms:id_didok>8587214</ms:id_didok>
        <ms:name>Sitterdorf, alte Post
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735805.076000 1262557.492000</gml:lowerCorner>
        		<gml:upperCorner>2735805.076000 1262557.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.774.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735805.076000 1262557.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>774</ms:objectid>
        <ms:id_didok>8587212</ms:id_didok>
        <ms:name>Sitterdorf, Bruggfeld
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735634.359000 1262507.585000</gml:lowerCorner>
        		<gml:upperCorner>2735634.359000 1262507.585000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.775.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735634.359000 1262507.585000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>775</ms:objectid>
        <ms:id_didok>8587155</ms:id_didok>
        <ms:name>Bischofszell, Ibergstrasse
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735729.338000 1262362.551000</gml:lowerCorner>
        		<gml:upperCorner>2735729.338000 1262362.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.776.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735729.338000 1262362.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>776</ms:objectid>
        <ms:id_didok>8587156</ms:id_didok>
        <ms:name>Bischofszell, Bruggmühle
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718896.923000 1281594.785000</gml:lowerCorner>
        		<gml:upperCorner>2718896.923000 1281594.785000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.870.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718896.923000 1281594.785000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>870</ms:objectid>
        <ms:id_didok>8594967</ms:id_didok>
        <ms:name>Berlingen, Seestrasse/Werft</ms:name>
        <ms:linien_nummer>BN820</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2701475.958000 1276921.959000</gml:lowerCorner>
        		<gml:upperCorner>2701475.958000 1276921.959000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.230.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2701475.958000 1276921.959000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>230</ms:objectid>
        <ms:id_didok>8573203</ms:id_didok>
        <ms:name>Stammheim, Bahnhof</ms:name>
        <ms:linien_nummer>70.605, 80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721190.471000 1281559.791000</gml:lowerCorner>
        		<gml:upperCorner>2721190.471000 1281559.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.871.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721190.471000 1281559.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>871</ms:objectid>
        <ms:id_didok>8510304</ms:id_didok>
        <ms:name>Mannenbach-Salenstein, Bahnhof</ms:name>
        <ms:linien_nummer>BN820</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728161.299000 1255856.638000</gml:lowerCorner>
        		<gml:upperCorner>2728161.299000 1255856.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.143.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728161.299000 1255856.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>143</ms:objectid>
        <ms:id_didok>8506735</ms:id_didok>
        <ms:name>Uzwil, Schöntal</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2702301.437000 1276621.850000</gml:lowerCorner>
        		<gml:upperCorner>2702301.437000 1276621.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.742.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2702301.437000 1276621.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>742</ms:objectid>
        <ms:id_didok>8573328</ms:id_didok>
        <ms:name>Stammheim, Frohsinn</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2701953.964000 1276798.023000</gml:lowerCorner>
        		<gml:upperCorner>2701953.964000 1276798.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.229.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2701953.964000 1276798.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>229</ms:objectid>
        <ms:id_didok>8506954</ms:id_didok>
        <ms:name>Oberstammheim, Rietweg</ms:name>
        <ms:linien_nummer>70.605, 80.823</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725513.959000 1280299.431000</gml:lowerCorner>
        		<gml:upperCorner>2725513.959000 1280299.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.872.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725513.959000 1280299.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>872</ms:objectid>
        <ms:id_didok>8573380</ms:id_didok>
        <ms:name>Triboltingen, Dorf</ms:name>
        <ms:linien_nummer>BN820</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706013.771000 1254994.133000</gml:lowerCorner>
        		<gml:upperCorner>2706013.771000 1254994.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.311.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706013.771000 1254994.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>311</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Turbenthal, Bahnhof</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727275.782000 1280121.834000</gml:lowerCorner>
        		<gml:upperCorner>2727275.782000 1280121.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.873.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727275.782000 1280121.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>873</ms:objectid>
        <ms:id_didok>8502511</ms:id_didok>
        <ms:name>Tägerwilen-Gottlieben, Bahnhof</ms:name>
        <ms:linien_nummer>BN820</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706355.770000 1254810.946000</gml:lowerCorner>
        		<gml:upperCorner>2706355.770000 1254810.946000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.313.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706355.770000 1254810.946000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>313</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Turbenthal, Schloss</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720854.856000 1258142.182000</gml:lowerCorner>
        		<gml:upperCorner>2720854.856000 1258142.182000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.434.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720854.856000 1258142.182000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>434</ms:objectid>
        <ms:id_didok>8573602</ms:id_didok>
        <ms:name>Wil SG, Bahnhof</ms:name>
        <ms:linien_nummer>80.702, 80.706, 80.722, 80.731, 80.732, 80.733, 80.734, 80.735</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720589.323000 1259171.439000</gml:lowerCorner>
        		<gml:upperCorner>2720589.323000 1259171.439000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.438.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720589.323000 1259171.439000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>438</ms:objectid>
        <ms:id_didok>8573618</ms:id_didok>
        <ms:name>Wil SG, Letten</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720856.219000 1258702.611000</gml:lowerCorner>
        		<gml:upperCorner>2720856.219000 1258702.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.437.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720856.219000 1258702.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>437</ms:objectid>
        <ms:id_didok>8573617</ms:id_didok>
        <ms:name>Wil SG, Kreuzackerstrasse</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720399.375000 1259844.079000</gml:lowerCorner>
        		<gml:upperCorner>2720399.375000 1259844.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.446.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720399.375000 1259844.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>446</ms:objectid>
        <ms:id_didok>8506659</ms:id_didok>
        <ms:name>Bronschhofen, Feuerwehrdepot</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721297.129000 1261036.749000</gml:lowerCorner>
        		<gml:upperCorner>2721297.129000 1261036.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.165.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721297.129000 1261036.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>165</ms:objectid>
        <ms:id_didok>8506737</ms:id_didok>
        <ms:name>Bronschhofen, Maugwil</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722156.695000 1261763.929000</gml:lowerCorner>
        		<gml:upperCorner>2722156.695000 1261763.929000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.164.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722156.695000 1261763.929000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>164</ms:objectid>
        <ms:id_didok>8506659</ms:id_didok>
        <ms:name>Braunau, Hittingen</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720313.150000 1256732.275000</gml:lowerCorner>
        		<gml:upperCorner>2720313.150000 1256732.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.376.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720313.150000 1256732.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>376</ms:objectid>
        <ms:id_didok>8578821</ms:id_didok>
        <ms:name>Wilen bei Wil, Langwiesen</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2744336.937000 1262426.280000</gml:lowerCorner>
        		<gml:upperCorner>2744336.937000 1262426.280000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.596.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2744336.937000 1262426.280000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>596</ms:objectid>
        <ms:id_didok>8579904</ms:id_didok>
        <ms:name>Lömmenschwil, Romanshornerstrasse</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747774.483000 1257119.580000</gml:lowerCorner>
        		<gml:upperCorner>2747774.483000 1257119.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.501.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747774.483000 1257119.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>501</ms:objectid>
        <ms:id_didok>8506703</ms:id_didok>
        <ms:name>St. Gallen, Sonnrainweg</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.32">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712797.828000 1270690.198000</gml:lowerCorner>
        		<gml:upperCorner>2712797.828000 1270690.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.32.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712797.828000 1270690.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>32</ms:objectid>
        <ms:id_didok>8573285</ms:id_didok>
        <ms:name>Felben, Unterdorf</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715477.471000 1252984.441000</gml:lowerCorner>
        		<gml:upperCorner>2715477.471000 1252984.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.623.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715477.471000 1252984.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>623</ms:objectid>
        <ms:id_didok>8506850</ms:id_didok>
        <ms:name>Fischingen, Sonne</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747959.310000 1266141.506000</gml:lowerCorner>
        		<gml:upperCorner>2747959.310000 1266141.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.341.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747959.310000 1266141.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>341</ms:objectid>
        <ms:id_didok>8587169</ms:id_didok>
        <ms:name>Frasnacht, Domino</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.61">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722149.681000 1279847.805000</gml:lowerCorner>
        		<gml:upperCorner>2722149.681000 1279847.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.61.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722149.681000 1279847.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>61</ms:objectid>
        <ms:id_didok>8573352</ms:id_didok>
        <ms:name>Fruthwilen, Oberfruthwilen</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731424.172000 1266794.448000</gml:lowerCorner>
        		<gml:upperCorner>2731424.172000 1266794.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.874.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731424.172000 1266794.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>874</ms:objectid>
        <ms:id_didok>8573425</ms:id_didok>
        <ms:name>Sulgen, Bahnhof</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732644.843000 1265479.710000</gml:lowerCorner>
        		<gml:upperCorner>2732644.843000 1265479.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.875.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732644.843000 1265479.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>875</ms:objectid>
        <ms:id_didok>8511551</ms:id_didok>
        <ms:name>Kradolf, Heldswilerstrasse</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736590.520000 1260301.092000</gml:lowerCorner>
        		<gml:upperCorner>2736590.520000 1260301.092000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.876.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736590.520000 1260301.092000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>876</ms:objectid>
        <ms:id_didok>8587336</ms:id_didok>
        <ms:name>Hauptwil, Dorfplatz</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738184.006000 1255857.143000</gml:lowerCorner>
        		<gml:upperCorner>2738184.006000 1255857.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.883.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738184.006000 1255857.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>883</ms:objectid>
        <ms:id_didok>8506789</ms:id_didok>
        <ms:name>Andwil SG, Post</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737150.987000 1253375.272000</gml:lowerCorner>
        		<gml:upperCorner>2737150.987000 1253375.272000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.888.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737150.987000 1253375.272000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>888</ms:objectid>
        <ms:id_didok>8573954</ms:id_didok>
        <ms:name>Gossau SG, Migros-Markt</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736970.527000 1252835.828000</gml:lowerCorner>
        		<gml:upperCorner>2736970.527000 1252835.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.890.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736970.527000 1252835.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>890</ms:objectid>
        <ms:id_didok>8573945</ms:id_didok>
        <ms:name>Gossau SG, Bahnhof</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738179.527000 1253216.924000</gml:lowerCorner>
        		<gml:upperCorner>2738179.527000 1253216.924000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.891.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738179.527000 1253216.924000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>891</ms:objectid>
        <ms:id_didok>8506468</ms:id_didok>
        <ms:name>Gossau SG, Mettendorf</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738837.583000 1258875.443000</gml:lowerCorner>
        		<gml:upperCorner>2738837.583000 1258875.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.878.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738837.583000 1258875.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>878</ms:objectid>
        <ms:id_didok>8573959</ms:id_didok>
        <ms:name>Waldkirch, Friedegg</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739119.846000 1259105.240000</gml:lowerCorner>
        		<gml:upperCorner>2739119.846000 1259105.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.877.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739119.846000 1259105.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>877</ms:objectid>
        <ms:id_didok>8587336</ms:id_didok>
        <ms:name>Waldkirch, Dorf</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737968.697000 1257991.248000</gml:lowerCorner>
        		<gml:upperCorner>2737968.697000 1257991.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.879.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737968.697000 1257991.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>879</ms:objectid>
        <ms:id_didok>8506499</ms:id_didok>
        <ms:name>Waldkirch, Ronwil</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737801.947000 1257575.334000</gml:lowerCorner>
        		<gml:upperCorner>2737801.947000 1257575.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.880.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737801.947000 1257575.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>880</ms:objectid>
        <ms:id_didok>8506699</ms:id_didok>
        <ms:name>Waldkirch, Rickenhueb</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720336.910000 1256861.849000</gml:lowerCorner>
        		<gml:upperCorner>2720336.910000 1256861.849000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.445.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720336.910000 1256861.849000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>445</ms:objectid>
        <ms:id_didok>8588721</ms:id_didok>
        <ms:name>Wilen bei Wil, Sonnenplatz</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720854.695000 1256932.240000</gml:lowerCorner>
        		<gml:upperCorner>2720854.695000 1256932.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.749.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720854.695000 1256932.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>749</ms:objectid>
        <ms:id_didok>8507442</ms:id_didok>
        <ms:name>Wilen bei Wil, Glärnischstr.
</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721282.681000 1254526.725000</gml:lowerCorner>
        		<gml:upperCorner>2721282.681000 1254526.725000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.382.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721282.681000 1254526.725000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>382</ms:objectid>
        <ms:id_didok>8578520</ms:id_didok>
        <ms:name>Kirchberg SG, Lamperswil</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2697246.356000 1274210.353000</gml:lowerCorner>
        		<gml:upperCorner>2697246.356000 1274210.353000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.605.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2697246.356000 1274210.353000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>605</ms:objectid>
        <ms:id_didok>8573200</ms:id_didok>
        <ms:name>Ossingen, Usserdorf</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2700744.735000 1275527.309000</gml:lowerCorner>
        		<gml:upperCorner>2700744.735000 1275527.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.606.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2700744.735000 1275527.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>606</ms:objectid>
        <ms:id_didok>8573202</ms:id_didok>
        <ms:name>Waltalingen</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730121.708000 1257021.414000</gml:lowerCorner>
        		<gml:upperCorner>2730121.708000 1257021.414000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.628.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730121.708000 1257021.414000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>628</ms:objectid>
        <ms:id_didok>8573933</ms:id_didok>
        <ms:name>Oberbüren, Oberstufe Thurzelg</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743587.751000 1262104.700000</gml:lowerCorner>
        		<gml:upperCorner>2743587.751000 1262104.700000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.199.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743587.751000 1262104.700000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>199</ms:objectid>
        <ms:id_didok>8579979</ms:id_didok>
        <ms:name>Häggenschwil, Dorfplatz</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.58">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746519.185000 1254652.154000</gml:lowerCorner>
        		<gml:upperCorner>2746519.185000 1254652.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.58.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746519.185000 1254652.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>58</ms:objectid>
        <ms:id_didok>8574469</ms:id_didok>
        <ms:name>St. Gallen, Theater</ms:name>
        <ms:linien_nummer>80.201, 80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748165.290000 1255700.423000</gml:lowerCorner>
        		<gml:upperCorner>2748165.290000 1255700.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.495.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748165.290000 1255700.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>495</ms:objectid>
        <ms:id_didok>8589579</ms:id_didok>
        <ms:name>St. Gallen, Grütlistrasse</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720747.718000 1258320.937000</gml:lowerCorner>
        		<gml:upperCorner>2720747.718000 1258320.937000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.892.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720747.718000 1258320.937000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>892</ms:objectid>
        <ms:id_didok>8578596</ms:id_didok>
        <ms:name>Wil SG, Winkelriedstrasse</ms:name>
        <ms:linien_nummer>80.733 (Abendkurs), 80.734</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.9">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716590.567000 1277158.675000</gml:lowerCorner>
        		<gml:upperCorner>2716590.567000 1277158.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.9.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716590.567000 1277158.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>9</ms:objectid>
        <ms:id_didok>8506597</ms:id_didok>
        <ms:name>Reckenwil, Steinberg</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.62">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708212.937000 1266378.841000</gml:lowerCorner>
        		<gml:upperCorner>2708212.937000 1266378.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.62.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708212.937000 1266378.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>62</ms:objectid>
        <ms:id_didok>8578816</ms:id_didok>
        <ms:name>Gerlikon, Bausel</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.63">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708494.512000 1266383.345000</gml:lowerCorner>
        		<gml:upperCorner>2708494.512000 1266383.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.63.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708494.512000 1266383.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>63</ms:objectid>
        <ms:id_didok>8578815</ms:id_didok>
        <ms:name>Gerlikon, Huggenbergerhaus</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.66">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2742017.586000 1268946.619000</gml:lowerCorner>
        		<gml:upperCorner>2742017.586000 1268946.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.66.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2742017.586000 1268946.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>66</ms:objectid>
        <ms:id_didok>8587175</ms:id_didok>
        <ms:name>Hefenhofen, Hatswil</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.18">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710632.109000 1273737.115000</gml:lowerCorner>
        		<gml:upperCorner>2710632.109000 1273737.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.18.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710632.109000 1273737.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>18</ms:objectid>
        <ms:id_didok>8506758</ms:id_didok>
        <ms:name>Herdern, Dorf</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.72">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725734.535000 1273317.788000</gml:lowerCorner>
        		<gml:upperCorner>2725734.535000 1273317.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.72.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725734.535000 1273317.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>72</ms:objectid>
        <ms:id_didok>8573398</ms:id_didok>
        <ms:name>Hugelshofen, Langgasse</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749513.266000 1265049.794000</gml:lowerCorner>
        		<gml:upperCorner>2749513.266000 1265049.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.797.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749513.266000 1265049.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>797</ms:objectid>
        <ms:id_didok>8510057</ms:id_didok>
        <ms:name>Arbon, Frohmattstrasse</ms:name>
        <ms:linien_nummer>80.940, 80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.39">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2742218.318000 1267033.926000</gml:lowerCorner>
        		<gml:upperCorner>2742218.318000 1267033.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.39.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2742218.318000 1267033.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>39</ms:objectid>
        <ms:id_didok>8587135</ms:id_didok>
        <ms:name>Amriswil, Almensberg</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.43">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748845.517000 1265204.163000</gml:lowerCorner>
        		<gml:upperCorner>2748845.517000 1265204.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.43.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748845.517000 1265204.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>43</ms:objectid>
        <ms:id_didok>8587152</ms:id_didok>
        <ms:name>Arbon, Scheidweg</ms:name>
        <ms:linien_nummer>80.940, 80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.44">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749206.174000 1265109.175000</gml:lowerCorner>
        		<gml:upperCorner>2749206.174000 1265109.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.44.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749206.174000 1265109.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>44</ms:objectid>
        <ms:id_didok>8587153</ms:id_didok>
        <ms:name>Arbon, Seemoosholz</ms:name>
        <ms:linien_nummer>80.940, 80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.17">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726977.866000 1273338.476000</gml:lowerCorner>
        		<gml:upperCorner>2726977.866000 1273338.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.17.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726977.866000 1273338.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>17</ms:objectid>
        <ms:id_didok>8573396</ms:id_didok>
        <ms:name>Hugelshofen, Schlatt</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.73">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726138.044000 1273322.082000</gml:lowerCorner>
        		<gml:upperCorner>2726138.044000 1273322.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.73.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726138.044000 1273322.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>73</ms:objectid>
        <ms:id_didok>8573397</ms:id_didok>
        <ms:name>Hugelshofen, Unterdorf</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.46">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710306.428000 1265047.729000</gml:lowerCorner>
        		<gml:upperCorner>2710306.428000 1265047.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.46.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710306.428000 1265047.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>46</ms:objectid>
        <ms:id_didok>8506866</ms:id_didok>
        <ms:name>Häuslenen, Zentrum</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.29">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715362.110000 1277292.454000</gml:lowerCorner>
        		<gml:upperCorner>2715362.110000 1277292.454000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.29.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715362.110000 1277292.454000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>29</ms:objectid>
        <ms:id_didok>85733380</ms:id_didok>
        <ms:name>Hörhausen, Freihof</ms:name>
        <ms:linien_nummer>80.826, 80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.8">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734377.497000 1277349.346000</gml:lowerCorner>
        		<gml:upperCorner>2734377.497000 1277349.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.8.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734377.497000 1277349.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>8</ms:objectid>
        <ms:id_didok>8506772</ms:id_didok>
        <ms:name>Scherzingen, Bahnhof</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.47">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723181.213000 1262717.833000</gml:lowerCorner>
        		<gml:upperCorner>2723181.213000 1262717.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.47.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723181.213000 1262717.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>47</ms:objectid>
        <ms:id_didok>8589071</ms:id_didok>
        <ms:name>Braunau, Ebnet</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.5">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715711.898000 1278310.758000</gml:lowerCorner>
        		<gml:upperCorner>2715711.898000 1278310.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.5.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715711.898000 1278310.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>5</ms:objectid>
        <ms:id_didok>8506718</ms:id_didok>
        <ms:name>Hörhausen, Hochstrasse</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.14">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708652.855000 1274883.865000</gml:lowerCorner>
        		<gml:upperCorner>2708652.855000 1274883.865000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.14.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708652.855000 1274883.865000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>14</ms:objectid>
        <ms:id_didok>8573266</ms:id_didok>
        <ms:name>Hüttwilen, Hörnliwald</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.34">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720241.028000 1275458.840000</gml:lowerCorner>
        		<gml:upperCorner>2720241.028000 1275458.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.34.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720241.028000 1275458.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>34</ms:objectid>
        <ms:id_didok>8506593</ms:id_didok>
        <ms:name>Illhart, Sternen</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.55">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747821.956000 1257877.206000</gml:lowerCorner>
        		<gml:upperCorner>2747821.956000 1257877.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.55.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747821.956000 1257877.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>55</ms:objectid>
        <ms:id_didok>8574240</ms:id_didok>
        <ms:name>Kronbühl, Bruggbach</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.70">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735294.648000 1276391.304000</gml:lowerCorner>
        		<gml:upperCorner>2735294.648000 1276391.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.70.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735294.648000 1276391.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>70</ms:objectid>
        <ms:id_didok>8581700</ms:id_didok>
        <ms:name>Landschlacht, Blindenzentrum</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750770.859000 1263307.087000</gml:lowerCorner>
        		<gml:upperCorner>2750770.859000 1263307.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.863.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750770.859000 1263307.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>863</ms:objectid>
        <ms:id_didok>8594859</ms:id_didok>
        <ms:name>Steinach, Kirche</ms:name>
        <ms:linien_nummer>80.210</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.33">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721764.368000 1281376.915000</gml:lowerCorner>
        		<gml:upperCorner>2721764.368000 1281376.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.33.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721764.368000 1281376.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>33</ms:objectid>
        <ms:id_didok>8581947</ms:id_didok>
        <ms:name>Arenenberg, Schloss</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2742289.115000 1264851.449000</gml:lowerCorner>
        		<gml:upperCorner>2742289.115000 1264851.449000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.181.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2742289.115000 1264851.449000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>181</ms:objectid>
        <ms:id_didok>8587183</ms:id_didok>
        <ms:name>Muolen, Hirschen</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.26">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737587.058000 1269126.013000</gml:lowerCorner>
        		<gml:upperCorner>2737587.058000 1269126.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.26.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737587.058000 1269126.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>26</ms:objectid>
        <ms:id_didok>8587190</ms:id_didok>
        <ms:name>Oberaach, Schlösslipark</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.22">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723810.832000 1272068.958000</gml:lowerCorner>
        		<gml:upperCorner>2723810.832000 1272068.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.22.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723810.832000 1272068.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>22</ms:objectid>
        <ms:id_didok>8506560</ms:id_didok>
        <ms:name>Ottoberg, Schulhaus</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.21">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713868.630000 1272739.698000</gml:lowerCorner>
        		<gml:upperCorner>2713868.630000 1272739.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.21.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713868.630000 1272739.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>21</ms:objectid>
        <ms:id_didok>8573344</ms:id_didok>
        <ms:name>Pfyn, Grütli</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.7">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734378.963000 1277047.732000</gml:lowerCorner>
        		<gml:upperCorner>2734378.963000 1277047.732000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.7.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734378.963000 1277047.732000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>7</ms:objectid>
        <ms:id_didok>8573415</ms:id_didok>
        <ms:name>Scherzingen, Bäckerstübli</ms:name>
        <ms:linien_nummer>80.908, 80.925, 80.931</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.10">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723255.970000 1275743.614000</gml:lowerCorner>
        		<gml:upperCorner>2723255.970000 1275743.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.10.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723255.970000 1275743.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>10</ms:objectid>
        <ms:id_didok>8506566</ms:id_didok>
        <ms:name>Sonterswil, Volg</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.51">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740384.416000 1261211.843000</gml:lowerCorner>
        		<gml:upperCorner>2740384.416000 1261211.843000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.51.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740384.416000 1261211.843000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>51</ms:objectid>
        <ms:id_didok>8506469</ms:id_didok>
        <ms:name>St. Pelagiberg, Trön</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.65">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714428.236000 1264771.587000</gml:lowerCorner>
        		<gml:upperCorner>2714428.236000 1264771.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.65.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714428.236000 1264771.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>65</ms:objectid>
        <ms:id_didok>8573627</ms:id_didok>
        <ms:name>Stettfurt, Lettenstrasse</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.57">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709738.532000 1255336.350000</gml:lowerCorner>
        		<gml:upperCorner>2709738.532000 1255336.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.57.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709738.532000 1255336.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>57</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Turbenthal, Neubrunn</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.53">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710547.338000 1259843.867000</gml:lowerCorner>
        		<gml:upperCorner>2710547.338000 1259843.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.53.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710547.338000 1259843.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>53</ms:objectid>
        <ms:id_didok>8576957</ms:id_didok>
        <ms:name>Tänikon, Forschungsanstalt</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.27">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727575.914000 1269194.230000</gml:lowerCorner>
        		<gml:upperCorner>2727575.914000 1269194.230000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.27.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727575.914000 1269194.230000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>27</ms:objectid>
        <ms:id_didok>8506569</ms:id_didok>
        <ms:name>Weinfelden, Giessen</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.20">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719750.005000 1273206.870000</gml:lowerCorner>
        		<gml:upperCorner>2719750.005000 1273206.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.20.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719750.005000 1273206.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>20</ms:objectid>
        <ms:id_didok>8506979</ms:id_didok>
        <ms:name>Wigoltingen, Dorf</ms:name>
        <ms:linien_nummer>80.829</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.35">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2692999.533000 1278631.944000</gml:lowerCorner>
        		<gml:upperCorner>2692999.533000 1278631.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.35.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2692999.533000 1278631.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>35</ms:objectid>
        <ms:id_didok>8582607</ms:id_didok>
        <ms:name>Wildensbuch, Dorf</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.48">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738981.254000 1261964.085000</gml:lowerCorner>
        		<gml:upperCorner>2738981.254000 1261964.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.48.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738981.254000 1261964.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>48</ms:objectid>
        <ms:id_didok>8578804</ms:id_didok>
        <ms:name>Wilen (Gottshaus)</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.99">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724089.812000 1268679.912000</gml:lowerCorner>
        		<gml:upperCorner>2724089.812000 1268679.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.99.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724089.812000 1268679.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>99</ms:objectid>
        <ms:id_didok>8582159</ms:id_didok>
        <ms:name>Bussnang, Stadler</ms:name>
        <ms:linien_nummer>80.722, 80.935</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.38">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746714.134000 1267094.567000</gml:lowerCorner>
        		<gml:upperCorner>2746714.134000 1267094.567000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.38.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746714.134000 1267094.567000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>38</ms:objectid>
        <ms:id_didok>8587159</ms:id_didok>
        <ms:name>Egnach, Buech</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.25">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733346.488000 1269911.145000</gml:lowerCorner>
        		<gml:upperCorner>2733346.488000 1269911.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.25.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733346.488000 1269911.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>25</ms:objectid>
        <ms:id_didok>8582178</ms:id_didok>
        <ms:name>Heimenhofen, Kreuzung</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.23">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718637.137000 1272034.206000</gml:lowerCorner>
        		<gml:upperCorner>2718637.137000 1272034.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.23.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718637.137000 1272034.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>23</ms:objectid>
        <ms:id_didok>8573346</ms:id_didok>
        <ms:name>Müllheim-Wigoltingen, Bahnhof</ms:name>
        <ms:linien_nummer>80.831, 80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747659.098000 1263123.774000</gml:lowerCorner>
        		<gml:upperCorner>2747659.098000 1263123.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.360.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747659.098000 1263123.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>360</ms:objectid>
        <ms:id_didok>8506694</ms:id_didok>
        <ms:name>Roggwil TG, Post</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718116.341000 1261873.987000</gml:lowerCorner>
        		<gml:upperCorner>2718116.341000 1261873.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.823.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718116.341000 1261873.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>823</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>St. Margarethen, Sedel</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.45">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2742591.335000 1264791.075000</gml:lowerCorner>
        		<gml:upperCorner>2742591.335000 1264791.075000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.45.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2742591.335000 1264791.075000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>45</ms:objectid>
        <ms:id_didok>8587181</ms:id_didok>
        <ms:name>Muolen, Bahnhofstrasse</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.69">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733099.154000 1277838.216000</gml:lowerCorner>
        		<gml:upperCorner>2733099.154000 1277838.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.69.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733099.154000 1277838.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>69</ms:objectid>
        <ms:id_didok>8573411</ms:id_didok>
        <ms:name>Bottighofen, Turnhalle</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717912.727000 1250681.093000</gml:lowerCorner>
        		<gml:upperCorner>2717912.727000 1250681.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.800.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717912.727000 1250681.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>800</ms:objectid>
        <ms:id_didok>8508037</ms:id_didok>
        <ms:name>Gähwil, Sportstrasse
</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721515.805000 1255707.076000</gml:lowerCorner>
        		<gml:upperCorner>2721515.805000 1255707.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.799.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721515.805000 1255707.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>799</ms:objectid>
        <ms:id_didok>8578521</ms:id_didok>
        <ms:name>Kirchberg SG, Fetzhof</ms:name>
        <ms:linien_nummer>80.731, 80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722251.860000 1259362.604000</gml:lowerCorner>
        		<gml:upperCorner>2722251.860000 1259362.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.154.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722251.860000 1259362.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>154</ms:objectid>
        <ms:id_didok>8587865</ms:id_didok>
        <ms:name>Rossrüti, Altersheim</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.52">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723584.764000 1260304.076000</gml:lowerCorner>
        		<gml:upperCorner>2723584.764000 1260304.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.52.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723584.764000 1260304.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>52</ms:objectid>
        <ms:id_didok>8506665</ms:id_didok>
        <ms:name>Rossrüti, Rislen</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.80">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706122.123000 1269585.299000</gml:lowerCorner>
        		<gml:upperCorner>2706122.123000 1269585.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.80.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706122.123000 1269585.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>80</ms:objectid>
        <ms:id_didok>8573318</ms:id_didok>
        <ms:name>Erzenholz, Dorfbrunnen</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714922.758000 1254335.580000</gml:lowerCorner>
        		<gml:upperCorner>2714922.758000 1254335.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.185.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714922.758000 1254335.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>185</ms:objectid>
        <ms:id_didok>8595459</ms:id_didok>
        <ms:name>Dussnang, Kirche/Klinik</ms:name>
        <ms:linien_nummer>70.806, 80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.81">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706371.756000 1269524.788000</gml:lowerCorner>
        		<gml:upperCorner>2706371.756000 1269524.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.81.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706371.756000 1269524.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>81</ms:objectid>
        <ms:id_didok>8573317</ms:id_didok>
        <ms:name>Erzenholz, Schulhaus</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.84">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748649.570000 1265350.047000</gml:lowerCorner>
        		<gml:upperCorner>2748649.570000 1265350.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.84.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748649.570000 1265350.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>84</ms:objectid>
        <ms:id_didok>8587167</ms:id_didok>
        <ms:name>Frasnacht, Arbonia</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.78">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706888.538000 1269395.504000</gml:lowerCorner>
        		<gml:upperCorner>2706888.538000 1269395.504000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.78.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706888.538000 1269395.504000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>78</ms:objectid>
        <ms:id_didok>8573316</ms:id_didok>
        <ms:name>Frauenfeld, Graströchni</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.79">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707538.149000 1269232.724000</gml:lowerCorner>
        		<gml:upperCorner>2707538.149000 1269232.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.79.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707538.149000 1269232.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>79</ms:objectid>
        <ms:id_didok>8573315</ms:id_didok>
        <ms:name>Frauenfeld, Hilzinger</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.97">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2711549.338000 1269868.569000</gml:lowerCorner>
        		<gml:upperCorner>2711549.338000 1269868.569000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.97.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2711549.338000 1269868.569000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>97</ms:objectid>
        <ms:id_didok>8573284</ms:id_didok>
        <ms:name>Frauenfeld, Scheidweg</ms:name>
        <ms:linien_nummer>80.826, 80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741120.401000 1268426.878000</gml:lowerCorner>
        		<gml:upperCorner>2741120.401000 1268426.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.129.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741120.401000 1268426.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>129</ms:objectid>
        <ms:id_didok>8587176</ms:id_didok>
        <ms:name>Hefenhofen, Metropol</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741036.434000 1269660.219000</gml:lowerCorner>
        		<gml:upperCorner>2741036.434000 1269660.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.116.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741036.434000 1269660.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>116</ms:objectid>
        <ms:id_didok>8587178</ms:id_didok>
        <ms:name>Hefenhofen, Sonnenberg</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.54">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749396.181000 1259048.864000</gml:lowerCorner>
        		<gml:upperCorner>2749396.181000 1259048.864000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.54.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749396.181000 1259048.864000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>54</ms:objectid>
        <ms:id_didok>8581396</ms:id_didok>
        <ms:name>Mörschwil, Bitzi</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.82">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705801.549000 1269651.285000</gml:lowerCorner>
        		<gml:upperCorner>2705801.549000 1269651.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.82.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705801.549000 1269651.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>82</ms:objectid>
        <ms:id_didok>8506867</ms:id_didok>
        <ms:name>Horgenbach, Hauptstrasse</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717132.849000 1273292.604000</gml:lowerCorner>
        		<gml:upperCorner>2717132.849000 1273292.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.356.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717132.849000 1273292.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>356</ms:objectid>
        <ms:id_didok>8582160</ms:id_didok>
        <ms:name>Müllheim Dorf, Felsenau</ms:name>
        <ms:linien_nummer>80.829, 80.831, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731550.319000 1278266.384000</gml:lowerCorner>
        		<gml:upperCorner>2731550.319000 1278266.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.131.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731550.319000 1278266.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>131</ms:objectid>
        <ms:id_didok>8573407</ms:id_didok>
        <ms:name>Kreuzlingen, Breite</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729777.457000 1278851.041000</gml:lowerCorner>
        		<gml:upperCorner>2729777.457000 1278851.041000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.134.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729777.457000 1278851.041000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>134</ms:objectid>
        <ms:id_didok>8581690</ms:id_didok>
        <ms:name>Kreuzlingen, Fliegaufstrasse</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731038.012000 1277930.036000</gml:lowerCorner>
        		<gml:upperCorner>2731038.012000 1277930.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.130.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731038.012000 1277930.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>130</ms:objectid>
        <ms:id_didok>8581681</ms:id_didok>
        <ms:name>Kreuzlingen, Gaissbergstrasse</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730350.073000 1278890.159000</gml:lowerCorner>
        		<gml:upperCorner>2730350.073000 1278890.159000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.104.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730350.073000 1278890.159000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>104</ms:objectid>
        <ms:id_didok>8573403</ms:id_didok>
        <ms:name>Kreuzlingen, Löwenstrasse</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730945.420000 1278299.892000</gml:lowerCorner>
        		<gml:upperCorner>2730945.420000 1278299.892000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.132.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730945.420000 1278299.892000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>132</ms:objectid>
        <ms:id_didok>8581680</ms:id_didok>
        <ms:name>Kreuzlingen, Remisbergstrasse</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730436.308000 1279082.342000</gml:lowerCorner>
        		<gml:upperCorner>2730436.308000 1279082.342000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.106.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730436.308000 1279082.342000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>106</ms:objectid>
        <ms:id_didok>8581698</ms:id_didok>
        <ms:name>Kreuzlingen, Sonnenweg</ms:name>
        <ms:linien_nummer>80.908</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736410.033000 1271941.921000</gml:lowerCorner>
        		<gml:upperCorner>2736410.033000 1271941.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.112.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736410.033000 1271941.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>112</ms:objectid>
        <ms:id_didok>8582171</ms:id_didok>
        <ms:name>Langrickenbach, Waldhof</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731927.705000 1276251.016000</gml:lowerCorner>
        		<gml:upperCorner>2731927.705000 1276251.016000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.109.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731927.705000 1276251.016000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>109</ms:objectid>
        <ms:id_didok>8581684</ms:id_didok>
        <ms:name>Lengwil, Dorf</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.75">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733233.351000 1271331.058000</gml:lowerCorner>
        		<gml:upperCorner>2733233.351000 1271331.058000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.75.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733233.351000 1271331.058000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>75</ms:objectid>
        <ms:id_didok>8506613</ms:id_didok>
        <ms:name>Mattwil, Schule</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.87">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2742024.249000 1265125.171000</gml:lowerCorner>
        		<gml:upperCorner>2742024.249000 1265125.171000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.87.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2742024.249000 1265125.171000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>87</ms:objectid>
        <ms:id_didok>8587182</ms:id_didok>
        <ms:name>Muolen, Dorf</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736989.606000 1275454.473000</gml:lowerCorner>
        		<gml:upperCorner>2736989.606000 1275454.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.110.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736989.606000 1275454.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>110</ms:objectid>
        <ms:id_didok>8573429</ms:id_didok>
        <ms:name>Altnau, Unterhof</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740677.039000 1267536.830000</gml:lowerCorner>
        		<gml:upperCorner>2740677.039000 1267536.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.135.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740677.039000 1267536.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>135</ms:objectid>
        <ms:id_didok>8587141</ms:id_didok>
        <ms:name>Amriswil, Hemmerswil</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740090.931000 1267696.278000</gml:lowerCorner>
        		<gml:upperCorner>2740090.931000 1267696.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.136.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740090.931000 1267696.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>136</ms:objectid>
        <ms:id_didok>8587145</ms:id_didok>
        <ms:name>Amriswil, Marktplatz</ms:name>
        <ms:linien_nummer>80.940, 80.941, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740263.364000 1267852.804000</gml:lowerCorner>
        		<gml:upperCorner>2740263.364000 1267852.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.139.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740263.364000 1267852.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>139</ms:objectid>
        <ms:id_didok>8587150</ms:id_didok>
        <ms:name>Amriswil, Zentrum</ms:name>
        <ms:linien_nummer>80.940, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749902.890000 1264112.941000</gml:lowerCorner>
        		<gml:upperCorner>2749902.890000 1264112.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.117.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749902.890000 1264112.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>117</ms:objectid>
        <ms:id_didok>8580919</ms:id_didok>
        <ms:name>Arbon, Bündnerhof</ms:name>
        <ms:linien_nummer>80.201, 80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749636.632000 1265025.172000</gml:lowerCorner>
        		<gml:upperCorner>2749636.632000 1265025.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.118.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749636.632000 1265025.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>118</ms:objectid>
        <ms:id_didok>8574248</ms:id_didok>
        <ms:name>Arbon, Romanshornerstrasse</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736020.494000 1261932.118000</gml:lowerCorner>
        		<gml:upperCorner>2736020.494000 1261932.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.140.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736020.494000 1261932.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>140</ms:objectid>
        <ms:id_didok>8578798</ms:id_didok>
        <ms:name>Bischofszell, Obertor</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736283.543000 1262221.332000</gml:lowerCorner>
        		<gml:upperCorner>2736283.543000 1262221.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.141.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736283.543000 1262221.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>141</ms:objectid>
        <ms:id_didok>8578799</ms:id_didok>
        <ms:name>Bischofszell, Sattelbogen</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717728.537000 1273169.751000</gml:lowerCorner>
        		<gml:upperCorner>2717728.537000 1273169.751000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.123.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717728.537000 1273169.751000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>123</ms:objectid>
        <ms:id_didok>8582011</ms:id_didok>
        <ms:name>Müllheim, Bahnhofstrasse</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734915.326000 1277212.711000</gml:lowerCorner>
        		<gml:upperCorner>2734915.326000 1277212.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.107.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734915.326000 1277212.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>107</ms:objectid>
        <ms:id_didok>8581757</ms:id_didok>
        <ms:name>Münsterlingen, Nonnenpförtli</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.923, 80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717416.665000 1273757.676000</gml:lowerCorner>
        		<gml:upperCorner>2717416.665000 1273757.676000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.111.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717416.665000 1273757.676000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>111</ms:objectid>
        <ms:id_didok>8573356</ms:id_didok>
        <ms:name>Müllheim, Alterssiedlung</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735118.752000 1277149.758000</gml:lowerCorner>
        		<gml:upperCorner>2735118.752000 1277149.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.108.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735118.752000 1277149.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>108</ms:objectid>
        <ms:id_didok>8573413</ms:id_didok>
        <ms:name>Münsterlingen, Spitaleingang</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.923, 80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724608.370000 1264901.195000</gml:lowerCorner>
        		<gml:upperCorner>2724608.370000 1264901.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.119.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724608.370000 1264901.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>119</ms:objectid>
        <ms:id_didok>8582603</ms:id_didok>
        <ms:name>Niederhof, Feuerwehrdepot</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726411.715000 1264264.769000</gml:lowerCorner>
        		<gml:upperCorner>2726411.715000 1264264.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.100.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726411.715000 1264264.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>100</ms:objectid>
        <ms:id_didok>8582601</ms:id_didok>
        <ms:name>Schönholzerswilen, Hagenbuch</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.94">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717335.200000 1258019.301000</gml:lowerCorner>
        		<gml:upperCorner>2717335.200000 1258019.301000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.94.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717335.200000 1258019.301000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>94</ms:objectid>
        <ms:id_didok>8578617</ms:id_didok>
        <ms:name>Sirnach, Breite</ms:name>
        <ms:linien_nummer>80.735, 80.739</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.91">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716046.884000 1280490.149000</gml:lowerCorner>
        		<gml:upperCorner>2716046.884000 1280490.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.91.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716046.884000 1280490.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>91</ms:objectid>
        <ms:id_didok>8573340</ms:id_didok>
        <ms:name>Steckborn, Schulhaus Hub</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.95">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715963.089000 1279882.418000</gml:lowerCorner>
        		<gml:upperCorner>2715963.089000 1279882.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.95.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715963.089000 1279882.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>95</ms:objectid>
        <ms:id_didok>8579758</ms:id_didok>
        <ms:name>Steckborn, im Rank</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750915.698000 1263215.973000</gml:lowerCorner>
        		<gml:upperCorner>2750915.698000 1263215.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.122.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750915.698000 1263215.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>122</ms:objectid>
        <ms:id_didok>8506264</ms:id_didok>
        <ms:name>Steinach, Post</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.98">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714720.828000 1267233.421000</gml:lowerCorner>
        		<gml:upperCorner>2714720.828000 1267233.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.98.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714720.828000 1267233.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>98</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Thundorf, Brückenwaage</ms:name>
        <ms:linien_nummer>80.837, 80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.93">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709860.335000 1256908.796000</gml:lowerCorner>
        		<gml:upperCorner>2709860.335000 1256908.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.93.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709860.335000 1256908.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>93</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Turbenthal, Seelmatten</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726902.910000 1279862.690000</gml:lowerCorner>
        		<gml:upperCorner>2726902.910000 1279862.690000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.103.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726902.910000 1279862.690000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>103</ms:objectid>
        <ms:id_didok>8573379</ms:id_didok>
        <ms:name>Tägerwilen, Hertler</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731037.488000 1281663.653000</gml:lowerCorner>
        		<gml:upperCorner>2731037.488000 1281663.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.819.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731037.488000 1281663.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>819</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Konstanz, Zähringerplatz</ms:name>
        <ms:linien_nummer>80.908</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726832.514000 1269324.135000</gml:lowerCorner>
        		<gml:upperCorner>2726832.514000 1269324.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.113.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726832.514000 1269324.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>113</ms:objectid>
        <ms:id_didok>8582226</ms:id_didok>
        <ms:name>Weinfelden, Güttingersreuti</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.77">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725472.949000 1270182.845000</gml:lowerCorner>
        		<gml:upperCorner>2725472.949000 1270182.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.77.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725472.949000 1270182.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>77</ms:objectid>
        <ms:id_didok>8573400</ms:id_didok>
        <ms:name>Weinfelden, Schlossgasse</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.59">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747951.665000 1261420.132000</gml:lowerCorner>
        		<gml:upperCorner>2747951.665000 1261420.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.59.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747951.665000 1261420.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>59</ms:objectid>
        <ms:id_didok>8506647</ms:id_didok>
        <ms:name>Berg SG, Seeblick</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730776.451000 1278597.682000</gml:lowerCorner>
        		<gml:upperCorner>2730776.451000 1278597.682000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.105.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730776.451000 1278597.682000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>105</ms:objectid>
        <ms:id_didok>8573405</ms:id_didok>
        <ms:name>Kreuzlingen, Seminar</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.924, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747013.152000 1258393.620000</gml:lowerCorner>
        		<gml:upperCorner>2747013.152000 1258393.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.865.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747013.152000 1258393.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>865</ms:objectid>
        <ms:id_didok>8573966</ms:id_didok>
        <ms:name>Wittenbach, Zentrum</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725166.465000 1267921.261000</gml:lowerCorner>
        		<gml:upperCorner>2725166.465000 1267921.261000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.125.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725166.465000 1267921.261000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>125</ms:objectid>
        <ms:id_didok>8506553</ms:id_didok>
        <ms:name>Rothenhausen, Dorf</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730763.104000 1281105.706000</gml:lowerCorner>
        		<gml:upperCorner>2730763.104000 1281105.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.820.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730763.104000 1281105.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>820</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Konstanz, Sternenplatz</ms:name>
        <ms:linien_nummer>80.908</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.88">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741405.913000 1265157.942000</gml:lowerCorner>
        		<gml:upperCorner>2741405.913000 1265157.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.88.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741405.913000 1265157.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>88</ms:objectid>
        <ms:id_didok>8587184</ms:id_didok>
        <ms:name>Muolen, Sonnental</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709838.765000 1261375.183000</gml:lowerCorner>
        		<gml:upperCorner>2709838.765000 1261375.183000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.120.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709838.765000 1261375.183000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>120</ms:objectid>
        <ms:id_didok>8576958</ms:id_didok>
        <ms:name>Aadorf, Morgental</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730615.999000 1280517.204000</gml:lowerCorner>
        		<gml:upperCorner>2730615.999000 1280517.204000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.822.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730615.999000 1280517.204000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>822</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Konstanz, Konzilstr./Theater</ms:name>
        <ms:linien_nummer>80.908</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.36">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743459.191000 1269363.553000</gml:lowerCorner>
        		<gml:upperCorner>2743459.191000 1269363.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.36.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743459.191000 1269363.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>36</ms:objectid>
        <ms:id_didok>8587205</ms:id_didok>
        <ms:name>Romanshorn, Spitz</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705960.974000 1267283.898000</gml:lowerCorner>
        		<gml:upperCorner>2705960.974000 1267283.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.124.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705960.974000 1267283.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>124</ms:objectid>
        <ms:id_didok>8581974</ms:id_didok>
        <ms:name>Islikon, Bahnhof</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707451.937000 1271193.576000</gml:lowerCorner>
        		<gml:upperCorner>2707451.937000 1271193.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.214.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707451.937000 1271193.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>214</ms:objectid>
        <ms:id_didok>8506869</ms:id_didok>
        <ms:name>Warth, Kartause Ittingen</ms:name>
        <ms:linien_nummer>80.819</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715494.935000 1252787.254000</gml:lowerCorner>
        		<gml:upperCorner>2715494.935000 1252787.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.158.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715494.935000 1252787.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>158</ms:objectid>
        <ms:id_didok>8578609</ms:id_didok>
        <ms:name>Fischingen, Grüner Baum</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748346.372000 1265694.879000</gml:lowerCorner>
        		<gml:upperCorner>2748346.372000 1265694.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.198.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748346.372000 1265694.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>198</ms:objectid>
        <ms:id_didok>8587168</ms:id_didok>
        <ms:name>Frasnacht, Bruderer</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710179.951000 1268844.918000</gml:lowerCorner>
        		<gml:upperCorner>2710179.951000 1268844.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.161.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710179.951000 1268844.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>161</ms:objectid>
        <ms:id_didok>8506628</ms:id_didok>
        <ms:name>Frauenfeld, Langdorf</ms:name>
        <ms:linien_nummer>80.826, 80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710483.863000 1260408.031000</gml:lowerCorner>
        		<gml:upperCorner>2710483.863000 1260408.031000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.166.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710483.863000 1260408.031000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>166</ms:objectid>
        <ms:id_didok>8576958</ms:id_didok>
        <ms:name>Aadorf, Matthofstrasse</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2693215.079000 1272206.708000</gml:lowerCorner>
        		<gml:upperCorner>2693215.079000 1272206.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.212.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2693215.079000 1272206.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>212</ms:objectid>
        <ms:id_didok>8573196</ms:id_didok>
        <ms:name>Andelfingen, Bahnhof</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709436.907000 1267982.133000</gml:lowerCorner>
        		<gml:upperCorner>2709436.907000 1267982.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.150.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709436.907000 1267982.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>150</ms:objectid>
        <ms:id_didok>8578813</ms:id_didok>
        <ms:name>Frauenfeld, Ochsen</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2703719.718000 1272722.485000</gml:lowerCorner>
        		<gml:upperCorner>2703719.718000 1272722.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.232.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2703719.718000 1272722.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>232</ms:objectid>
        <ms:id_didok>8581409</ms:id_didok>
        <ms:name>Buch bei Frauenfeld, Trüttlikon</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750086.730000 1264807.151000</gml:lowerCorner>
        		<gml:upperCorner>2750086.730000 1264807.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.197.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750086.730000 1264807.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>197</ms:objectid>
        <ms:id_didok>8574249</ms:id_didok>
        <ms:name>Arbon, Stahelplatz</ms:name>
        <ms:linien_nummer>80.200, 80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728462.047000 1256277.444000</gml:lowerCorner>
        		<gml:upperCorner>2728462.047000 1256277.444000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.142.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728462.047000 1256277.444000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>142</ms:objectid>
        <ms:id_didok>8573931</ms:id_didok>
        <ms:name>Niederuzwil, Marienfried</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717598.781000 1259588.051000</gml:lowerCorner>
        		<gml:upperCorner>2717598.781000 1259588.051000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.826.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717598.781000 1259588.051000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>826</ms:objectid>
        <ms:id_didok>8503022</ms:id_didok>
        <ms:name>Münchwilen TG, Bahnhof Süd</ms:name>
        <ms:linien_nummer>80.736, 80.739, 80.841</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712661.577000 1267195.446000</gml:lowerCorner>
        		<gml:upperCorner>2712661.577000 1267195.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.274.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712661.577000 1267195.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>274</ms:objectid>
        <ms:id_didok>8580967</ms:id_didok>
        <ms:name>Dingenhart, Dorf</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735201.357000 1260830.656000</gml:lowerCorner>
        		<gml:upperCorner>2735201.357000 1260830.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.178.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735201.357000 1260830.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>178</ms:objectid>
        <ms:id_didok>8573935</ms:id_didok>
        <ms:name>Bischofszell, Waldschenke</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707402.280000 1266892.499000</gml:lowerCorner>
        		<gml:upperCorner>2707402.280000 1266892.499000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.222.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707402.280000 1266892.499000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>222</ms:objectid>
        <ms:id_didok>8578817</ms:id_didok>
        <ms:name>Gachnang, Hofen</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706627.906000 1266343.203000</gml:lowerCorner>
        		<gml:upperCorner>2706627.906000 1266343.203000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.223.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706627.906000 1266343.203000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>223</ms:objectid>
        <ms:id_didok>8578818</ms:id_didok>
        <ms:name>Gachnang, Oberwilerstrasse</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2752535.454000 1262264.194000</gml:lowerCorner>
        		<gml:upperCorner>2752535.454000 1262264.194000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.201.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2752535.454000 1262264.194000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>201</ms:objectid>
        <ms:id_didok>8574277</ms:id_didok>
        <ms:name>Horn, Bahnhof</ms:name>
        <ms:linien_nummer>80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2752251.417000 1262618.940000</gml:lowerCorner>
        		<gml:upperCorner>2752251.417000 1262618.940000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.200.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2752251.417000 1262618.940000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>200</ms:objectid>
        <ms:id_didok>85742780</ms:id_didok>
        <ms:name>Horn, evang. Kirche</ms:name>
        <ms:linien_nummer>80.211</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2751734.826000 1262730.885000</gml:lowerCorner>
        		<gml:upperCorner>2751734.826000 1262730.885000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.217.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2751734.826000 1262730.885000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>217</ms:objectid>
        <ms:id_didok>8574279</ms:id_didok>
        <ms:name>Horn, Rütiwiese</ms:name>
        <ms:linien_nummer>80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709028.204000 1268857.991000</gml:lowerCorner>
        		<gml:upperCorner>2709028.204000 1268857.991000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.160.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709028.204000 1268857.991000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>160</ms:objectid>
        <ms:id_didok>8573313</ms:id_didok>
        <ms:name>Frauenfeld, Neuhofstrasse</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2744635.880000 1263208.945000</gml:lowerCorner>
        		<gml:upperCorner>2744635.880000 1263208.945000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.215.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2744635.880000 1263208.945000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>215</ms:objectid>
        <ms:id_didok>8574216</ms:id_didok>
        <ms:name>Häggenschwil-Winden, Bahnhof</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710370.214000 1265371.563000</gml:lowerCorner>
        		<gml:upperCorner>2710370.214000 1265371.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.167.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710370.214000 1265371.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>167</ms:objectid>
        <ms:id_didok>8573361</ms:id_didok>
        <ms:name>Häuslenen, Moos</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705326.965000 1271776.062000</gml:lowerCorner>
        		<gml:upperCorner>2705326.965000 1271776.062000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.213.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705326.965000 1271776.062000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>213</ms:objectid>
        <ms:id_didok>8582454</ms:id_didok>
        <ms:name>Iselisberg, Abzweigung</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709360.245000 1268654.659000</gml:lowerCorner>
        		<gml:upperCorner>2709360.245000 1268654.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.869.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709360.245000 1268654.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>869</ms:objectid>
        <ms:id_didok>8512260</ms:id_didok>
        <ms:name>Frauenfeld, Kirche Kurzdorf</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705673.927000 1266959.229000</gml:lowerCorner>
        		<gml:upperCorner>2705673.927000 1266959.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.225.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705673.927000 1266959.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>225</ms:objectid>
        <ms:id_didok>8582196</ms:id_didok>
        <ms:name>Islikon, Zentrum</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724801.326000 1264672.848000</gml:lowerCorner>
        		<gml:upperCorner>2724801.326000 1264672.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.168.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724801.326000 1264672.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>168</ms:objectid>
        <ms:id_didok>8582608</ms:id_didok>
        <ms:name>Lanterswil, Schulhaus</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2691516.349000 1276358.023000</gml:lowerCorner>
        		<gml:upperCorner>2691516.349000 1276358.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.227.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2691516.349000 1276358.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>227</ms:objectid>
        <ms:id_didok>8506875</ms:id_didok>
        <ms:name>Marthalen, Bahnhof</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717466.537000 1264170.894000</gml:lowerCorner>
        		<gml:upperCorner>2717466.537000 1264170.894000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.188.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717466.537000 1264170.894000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>188</ms:objectid>
        <ms:id_didok>8580249</ms:id_didok>
        <ms:name>Lommis, Krattenbach</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2751675.498000 1260038.081000</gml:lowerCorner>
        		<gml:upperCorner>2751675.498000 1260038.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.218.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2751675.498000 1260038.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>218</ms:objectid>
        <ms:id_didok>8580865</ms:id_didok>
        <ms:name>Tübach, Waldegg</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2700509.613000 1273154.485000</gml:lowerCorner>
        		<gml:upperCorner>2700509.613000 1273154.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.228.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2700509.613000 1273154.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>228</ms:objectid>
        <ms:id_didok>8506590</ms:id_didok>
        <ms:name>Oberneunforn, Hochberg</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728536.300000 1264505.225000</gml:lowerCorner>
        		<gml:upperCorner>2728536.300000 1264505.225000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.191.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728536.300000 1264505.225000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>191</ms:objectid>
        <ms:id_didok>8573294</ms:id_didok>
        <ms:name>Schönholzerswilen, Klingen</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726612.275000 1263776.474000</gml:lowerCorner>
        		<gml:upperCorner>2726612.275000 1263776.474000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.192.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726612.275000 1263776.474000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>192</ms:objectid>
        <ms:id_didok>8573608</ms:id_didok>
        <ms:name>Schönholzerswilen, Wartenwil</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713938.347000 1265687.030000</gml:lowerCorner>
        		<gml:upperCorner>2713938.347000 1265687.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.189.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713938.347000 1265687.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>189</ms:objectid>
        <ms:id_didok>8581615</ms:id_didok>
        <ms:name>Stettfurt, Freudenberg</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2751776.548000 1261486.091000</gml:lowerCorner>
        		<gml:upperCorner>2751776.548000 1261486.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.208.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2751776.548000 1261486.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>208</ms:objectid>
        <ms:id_didok>8580867</ms:id_didok>
        <ms:name>Tübach, Sonne</ms:name>
        <ms:linien_nummer>80.210</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724026.900000 1265919.680000</gml:lowerCorner>
        		<gml:upperCorner>2724026.900000 1265919.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.175.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724026.900000 1265919.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>175</ms:objectid>
        <ms:id_didok>8582807</ms:id_didok>
        <ms:name>Weingarten, Brunnenwies</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710315.688000 1260778.320000</gml:lowerCorner>
        		<gml:upperCorner>2710315.688000 1260778.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.155.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710315.688000 1260778.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>155</ms:objectid>
        <ms:id_didok>8573363</ms:id_didok>
        <ms:name>Aadorf, Bahnhof</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724412.773000 1260499.276000</gml:lowerCorner>
        		<gml:upperCorner>2724412.773000 1260499.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.184.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724412.773000 1260499.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>184</ms:objectid>
        <ms:id_didok>8506664</ms:id_didok>
        <ms:name>Wuppenau, Obermörenau-Hasenloh</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725148.213000 1261221.401000</gml:lowerCorner>
        		<gml:upperCorner>2725148.213000 1261221.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.221.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725148.213000 1261221.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>221</ms:objectid>
        <ms:id_didok>8506670</ms:id_didok>
        <ms:name>Wuppenau, Untermörenau</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712397.584000 1266817.914000</gml:lowerCorner>
        		<gml:upperCorner>2712397.584000 1266817.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.273.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712397.584000 1266817.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>273</ms:objectid>
        <ms:id_didok>8506855</ms:id_didok>
        <ms:name>Dingenhart, Brand</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718440.677000 1255645.168000</gml:lowerCorner>
        		<gml:upperCorner>2718440.677000 1255645.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.169.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718440.677000 1255645.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>169</ms:objectid>
        <ms:id_didok>8578789</ms:id_didok>
        <ms:name>Littenheid, Klinik</ms:name>
        <ms:linien_nummer>80.733</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745970.996000 1267966.337000</gml:lowerCorner>
        		<gml:upperCorner>2745970.996000 1267966.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.353.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745970.996000 1267966.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>353</ms:objectid>
        <ms:id_didok>8587162</ms:id_didok>
        <ms:name>Egnach, Mooswiesen</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741561.561000 1271174.962000</gml:lowerCorner>
        		<gml:upperCorner>2741561.561000 1271174.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.248.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741561.561000 1271174.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>248</ms:objectid>
        <ms:id_didok>8511198</ms:id_didok>
        <ms:name>Dozwil, Pärkli</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749791.774000 1263572.164000</gml:lowerCorner>
        		<gml:upperCorner>2749791.774000 1263572.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.196.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749791.774000 1263572.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>196</ms:objectid>
        <ms:id_didok>8580870</ms:id_didok>
        <ms:name>Arbon, Landquartstrasse</ms:name>
        <ms:linien_nummer>80.201, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725555.447000 1269150.194000</gml:lowerCorner>
        		<gml:upperCorner>2725555.447000 1269150.194000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.828.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725555.447000 1269150.194000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>828</ms:objectid>
        <ms:id_didok>8502585</ms:id_didok>
        <ms:name>Weinfelden, Wilerstrasse</ms:name>
        <ms:linien_nummer>80.722, 80.932</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2742959.280000 1264718.242000</gml:lowerCorner>
        		<gml:upperCorner>2742959.280000 1264718.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.202.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2742959.280000 1264718.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>202</ms:objectid>
        <ms:id_didok>8587180</ms:id_didok>
        <ms:name>Muolen, Bahnhof</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749574.655000 1264674.791000</gml:lowerCorner>
        		<gml:upperCorner>2749574.655000 1264674.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.195.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749574.655000 1264674.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>195</ms:objectid>
        <ms:id_didok>8574247</ms:id_didok>
        <ms:name>Arbon, Bergli</ms:name>
        <ms:linien_nummer>80.200, 80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726651.299000 1261401.976000</gml:lowerCorner>
        		<gml:upperCorner>2726651.299000 1261401.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.182.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726651.299000 1261401.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>182</ms:objectid>
        <ms:id_didok>8506680</ms:id_didok>
        <ms:name>Hosenruck, Dorf</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706423.952000 1266366.088000</gml:lowerCorner>
        		<gml:upperCorner>2706423.952000 1266366.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.224.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706423.952000 1266366.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>224</ms:objectid>
        <ms:id_didok>8578819</ms:id_didok>
        <ms:name>Gachnang, Trotte</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727983.807000 1273515.425000</gml:lowerCorner>
        		<gml:upperCorner>2727983.807000 1273515.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.247.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727983.807000 1273515.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>247</ms:objectid>
        <ms:id_didok>8506556</ms:id_didok>
        <ms:name>Dotnacht, Dorfplatz</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721515.085000 1273437.140000</gml:lowerCorner>
        		<gml:upperCorner>2721515.085000 1273437.140000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.275.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721515.085000 1273437.140000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>275</ms:objectid>
        <ms:id_didok>8573384</ms:id_didok>
        <ms:name>Engwang, Dorf</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707917.873000 1278198.410000</gml:lowerCorner>
        		<gml:upperCorner>2707917.873000 1278198.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.308.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707917.873000 1278198.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>308</ms:objectid>
        <ms:id_didok>8506902</ms:id_didok>
        <ms:name>Eschenz, Barriere</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708235.999000 1276125.114000</gml:lowerCorner>
        		<gml:upperCorner>2708235.999000 1276125.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.276.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708235.999000 1276125.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>276</ms:objectid>
        <ms:id_didok>8506719</ms:id_didok>
        <ms:name>Eschenz, Bornhausen</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713179.760000 1271009.436000</gml:lowerCorner>
        		<gml:upperCorner>2713179.760000 1271009.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.288.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713179.760000 1271009.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>288</ms:objectid>
        <ms:id_didok>8506706</ms:id_didok>
        <ms:name>Felben, Löwen</ms:name>
        <ms:linien_nummer>80.826, 80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713337.712000 1270551.165000</gml:lowerCorner>
        		<gml:upperCorner>2713337.712000 1270551.165000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.277.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713337.712000 1270551.165000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>277</ms:objectid>
        <ms:id_didok>8573343</ms:id_didok>
        <ms:name>Felben-Wellhausen, Schulhaus</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709867.719000 1266390.728000</gml:lowerCorner>
        		<gml:upperCorner>2709867.719000 1266390.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.278.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709867.719000 1266390.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>278</ms:objectid>
        <ms:id_didok>8503688</ms:id_didok>
        <ms:name>Frauenfeld, Aumühle</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2700135.394000 1276896.576000</gml:lowerCorner>
        		<gml:upperCorner>2700135.394000 1276896.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.219.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2700135.394000 1276896.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>219</ms:objectid>
        <ms:id_didok>85066290</ms:id_didok>
        <ms:name>Guntalingen</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720430.653000 1259528.854000</gml:lowerCorner>
        		<gml:upperCorner>2720430.653000 1259528.854000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.153.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720430.653000 1259528.854000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>153</ms:objectid>
        <ms:id_didok>8573619</ms:id_didok>
        <ms:name>Bronschhofen, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2693916.393000 1273129.098000</gml:lowerCorner>
        		<gml:upperCorner>2693916.393000 1273129.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.220.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2693916.393000 1273129.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>220</ms:objectid>
        <ms:id_didok>8573198</ms:id_didok>
        <ms:name>Kleinandelfingen, Bad</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734528.866000 1259235.487000</gml:lowerCorner>
        		<gml:upperCorner>2734528.866000 1259235.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.187.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734528.866000 1259235.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>187</ms:objectid>
        <ms:id_didok>8506586</ms:id_didok>
        <ms:name>Niederbüren, Sorntal</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746972.396000 1258727.899000</gml:lowerCorner>
        		<gml:upperCorner>2746972.396000 1258727.899000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.209.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746972.396000 1258727.899000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>209</ms:objectid>
        <ms:id_didok>8573965</ms:id_didok>
        <ms:name>Wittenbach, Bahnhof</ms:name>
        <ms:linien_nummer>80.200, 80.205, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746548.816000 1259023.331000</gml:lowerCorner>
        		<gml:upperCorner>2746548.816000 1259023.331000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.210.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746548.816000 1259023.331000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>210</ms:objectid>
        <ms:id_didok>8574255</ms:id_didok>
        <ms:name>Wittenbach, Sportanlagen</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743159.387000 1261631.452000</gml:lowerCorner>
        		<gml:upperCorner>2743159.387000 1261631.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.216.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743159.387000 1261631.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>216</ms:objectid>
        <ms:id_didok>8579844</ms:id_didok>
        <ms:name>Häggenschwil, Agen</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746789.187000 1254984.165000</gml:lowerCorner>
        		<gml:upperCorner>2746789.187000 1254984.165000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.144.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746789.187000 1254984.165000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>144</ms:objectid>
        <ms:id_didok>8594348</ms:id_didok>
        <ms:name>St. Gallen, Athletik Zentrum</ms:name>
        <ms:linien_nummer>80.201</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747080.928000 1254988.584000</gml:lowerCorner>
        		<gml:upperCorner>2747080.928000 1254988.584000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.146.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747080.928000 1254988.584000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>146</ms:objectid>
        <ms:id_didok>8574467</ms:id_didok>
        <ms:name>St. Gallen, Kantonsspital</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747631.409000 1255244.983000</gml:lowerCorner>
        		<gml:upperCorner>2747631.409000 1255244.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.145.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747631.409000 1255244.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>145</ms:objectid>
        <ms:id_didok>8574465</ms:id_didok>
        <ms:name>St. Gallen, Grossacker</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749495.474000 1258120.891000</gml:lowerCorner>
        		<gml:upperCorner>2749495.474000 1258120.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.203.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749495.474000 1258120.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>203</ms:objectid>
        <ms:id_didok>8581398</ms:id_didok>
        <ms:name>Mörschwil, Alberenberg</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749744.076000 1259388.868000</gml:lowerCorner>
        		<gml:upperCorner>2749744.076000 1259388.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.204.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749744.076000 1259388.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>204</ms:objectid>
        <ms:id_didok>8581394</ms:id_didok>
        <ms:name>Mörschwil, Kirche</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749405.023000 1258904.434000</gml:lowerCorner>
        		<gml:upperCorner>2749405.023000 1258904.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.205.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749405.023000 1258904.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>205</ms:objectid>
        <ms:id_didok>8581397</ms:id_didok>
        <ms:name>Mörschwil, Lantschen</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720099.128000 1264623.466000</gml:lowerCorner>
        		<gml:upperCorner>2720099.128000 1264623.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.183.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720099.128000 1264623.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>183</ms:objectid>
        <ms:id_didok>8573622</ms:id_didok>
        <ms:name>Tobel-Affeltrangen, Bahnhof</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705257.215000 1278964.401000</gml:lowerCorner>
        		<gml:upperCorner>2705257.215000 1278964.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.852.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705257.215000 1278964.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>852</ms:objectid>
        <ms:id_didok>8511173</ms:id_didok>
        <ms:name>Kaltenbach, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712999.109000 1256850.689000</gml:lowerCorner>
        		<gml:upperCorner>2712999.109000 1256850.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.159.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712999.109000 1256850.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>159</ms:objectid>
        <ms:id_didok>8578625</ms:id_didok>
        <ms:name>Balterswil, Dorf</ms:name>
        <ms:linien_nummer>80.735</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709141.142000 1267600.201000</gml:lowerCorner>
        		<gml:upperCorner>2709141.142000 1267600.201000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.290.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709141.142000 1267600.201000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>290</ms:objectid>
        <ms:id_didok>8579932</ms:id_didok>
        <ms:name>Frauenfeld, Fliederstrasse</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709941.686000 1267745.705000</gml:lowerCorner>
        		<gml:upperCorner>2709941.686000 1267745.705000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.280.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709941.686000 1267745.705000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>280</ms:objectid>
        <ms:id_didok>8573360</ms:id_didok>
        <ms:name>Frauenfeld, Reutenenstrasse</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709642.682000 1268097.669000</gml:lowerCorner>
        		<gml:upperCorner>2709642.682000 1268097.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.282.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709642.682000 1268097.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>282</ms:objectid>
        <ms:id_didok>8573303</ms:id_didok>
        <ms:name>Frauenfeld, Schlosspark</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728976.879000 1274623.339000</gml:lowerCorner>
        		<gml:upperCorner>2728976.879000 1274623.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.236.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728976.879000 1274623.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>236</ms:objectid>
        <ms:id_didok>8506554</ms:id_didok>
        <ms:name>Alterswilen, Kirche</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734284.035000 1271187.528000</gml:lowerCorner>
        		<gml:upperCorner>2734284.035000 1271187.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.251.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734284.035000 1271187.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>251</ms:objectid>
        <ms:id_didok>85066100</ms:id_didok>
        <ms:name>Happerswil, Dorf</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709051.410000 1274520.745000</gml:lowerCorner>
        		<gml:upperCorner>2709051.410000 1274520.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.295.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709051.410000 1274520.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>295</ms:objectid>
        <ms:id_didok>8506720</ms:id_didok>
        <ms:name>Hüttwilen, Kalchrain</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708669.846000 1268947.055000</gml:lowerCorner>
        		<gml:upperCorner>2708669.846000 1268947.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.286.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708669.846000 1268947.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>286</ms:objectid>
        <ms:id_didok>8573314</ms:id_didok>
        <ms:name>Frauenfeld, Sonnmatt</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736760.330000 1274589.597000</gml:lowerCorner>
        		<gml:upperCorner>2736760.330000 1274589.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.238.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736760.330000 1274589.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>238</ms:objectid>
        <ms:id_didok>8573431</ms:id_didok>
        <ms:name>Altnau, Kirche</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723948.629000 1266628.668000</gml:lowerCorner>
        		<gml:upperCorner>2723948.629000 1266628.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.284.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723948.629000 1266628.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>284</ms:objectid>
        <ms:id_didok>8506742</ms:id_didok>
        <ms:name>Friltschen, Dorf</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736965.711000 1274753.276000</gml:lowerCorner>
        		<gml:upperCorner>2736965.711000 1274753.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.240.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736965.711000 1274753.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>240</ms:objectid>
        <ms:id_didok>8573432</ms:id_didok>
        <ms:name>Altnau, Rössli</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740265.241000 1268281.195000</gml:lowerCorner>
        		<gml:upperCorner>2740265.241000 1268281.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.241.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740265.241000 1268281.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>241</ms:objectid>
        <ms:id_didok>8587138</ms:id_didok>
        <ms:name>Amriswil, Bahnhof</ms:name>
        <ms:linien_nummer>80.931, 80.94, 80.941, 80.942, 80.943, 80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740006.472000 1267877.172000</gml:lowerCorner>
        		<gml:upperCorner>2740006.472000 1267877.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.243.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740006.472000 1267877.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>243</ms:objectid>
        <ms:id_didok>8582163</ms:id_didok>
        <ms:name>Amriswil, Kirchstrasse</ms:name>
        <ms:linien_nummer>80.931, 80.940, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740650.109000 1269159.814000</gml:lowerCorner>
        		<gml:upperCorner>2740650.109000 1269159.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.252.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740650.109000 1269159.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>252</ms:objectid>
        <ms:id_didok>8587172</ms:id_didok>
        <ms:name>Hefenhofen, Auenhofen</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741353.807000 1270000.820000</gml:lowerCorner>
        		<gml:upperCorner>2741353.807000 1270000.820000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.253.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741353.807000 1270000.820000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>253</ms:objectid>
        <ms:id_didok>8587173</ms:id_didok>
        <ms:name>Hefenhofen, Brüschwil</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741430.200000 1268634.331000</gml:lowerCorner>
        		<gml:upperCorner>2741430.200000 1268634.331000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.256.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741430.200000 1268634.331000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>256</ms:objectid>
        <ms:id_didok>8587177</ms:id_didok>
        <ms:name>Hefenhofen, Moos</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712251.910000 1270422.690000</gml:lowerCorner>
        		<gml:upperCorner>2712251.910000 1270422.690000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.289.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712251.910000 1270422.690000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>289</ms:objectid>
        <ms:id_didok>8506957</ms:id_didok>
        <ms:name>Felben, Römerstrasse</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735824.514000 1273362.965000</gml:lowerCorner>
        		<gml:upperCorner>2735824.514000 1273362.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.258.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735824.514000 1273362.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>258</ms:objectid>
        <ms:id_didok>8573419</ms:id_didok>
        <ms:name>Herrenhof, Dorf</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717735.133000 1277168.056000</gml:lowerCorner>
        		<gml:upperCorner>2717735.133000 1277168.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.293.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717735.133000 1277168.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>293</ms:objectid>
        <ms:id_didok>8506977</ms:id_didok>
        <ms:name>Homburg, Dorf</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736870.790000 1271374.283000</gml:lowerCorner>
        		<gml:upperCorner>2736870.790000 1271374.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.261.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736870.790000 1271374.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>261</ms:objectid>
        <ms:id_didok>8582170</ms:id_didok>
        <ms:name>Langrickenbach, Rutishausen</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705740.257000 1279792.843000</gml:lowerCorner>
        		<gml:upperCorner>2705740.257000 1279792.843000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.853.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705740.257000 1279792.843000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>853</ms:objectid>
        <ms:id_didok>8511172</ms:id_didok>
        <ms:name>Wagenhausen, Probstei</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727413.460000 1275572.851000</gml:lowerCorner>
        		<gml:upperCorner>2727413.460000 1275572.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.263.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727413.460000 1275572.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>263</ms:objectid>
        <ms:id_didok>8573395</ms:id_didok>
        <ms:name>Neuwilen, Käserei</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724704.279000 1272871.118000</gml:lowerCorner>
        		<gml:upperCorner>2724704.279000 1272871.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.298.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724704.279000 1272871.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>298</ms:objectid>
        <ms:id_didok>8506562</ms:id_didok>
        <ms:name>Ottoberg, Gaishaus</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724180.226000 1272740.021000</gml:lowerCorner>
        		<gml:upperCorner>2724180.226000 1272740.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.299.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724180.226000 1272740.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>299</ms:objectid>
        <ms:id_didok>8573399</ms:id_didok>
        <ms:name>Ottoberg, Wald</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724140.894000 1271522.304000</gml:lowerCorner>
        		<gml:upperCorner>2724140.894000 1271522.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.300.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724140.894000 1271522.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>300</ms:objectid>
        <ms:id_didok>8506561</ms:id_didok>
        <ms:name>Ottoberg, Weinberg</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734123.627000 1277248.763000</gml:lowerCorner>
        		<gml:upperCorner>2734123.627000 1277248.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.264.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734123.627000 1277248.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>264</ms:objectid>
        <ms:id_didok>8581718</ms:id_didok>
        <ms:name>Scherzingen, Kirche</ms:name>
        <ms:linien_nummer>80.908, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727951.025000 1276219.044000</gml:lowerCorner>
        		<gml:upperCorner>2727951.025000 1276219.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.265.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727951.025000 1276219.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>265</ms:objectid>
        <ms:id_didok>8573394</ms:id_didok>
        <ms:name>Schwaderloh, Dorf</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715697.696000 1280416.513000</gml:lowerCorner>
        		<gml:upperCorner>2715697.696000 1280416.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.309.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715697.696000 1280416.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>309</ms:objectid>
        <ms:id_didok>8581758</ms:id_didok>
        <ms:name>Steckborn, Feldbach</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705726.867000 1271485.101000</gml:lowerCorner>
        		<gml:upperCorner>2705726.867000 1271485.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.233.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705726.867000 1271485.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>233</ms:objectid>
        <ms:id_didok>8583227</ms:id_didok>
        <ms:name>Uesslingen, Berlingerhof</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2701572.446000 1277418.014000</gml:lowerCorner>
        		<gml:upperCorner>2701572.446000 1277418.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.255.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2701572.446000 1277418.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>255</ms:objectid>
        <ms:id_didok>8573330</ms:id_didok>
        <ms:name>Unterstammheim, Adler</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737400.838000 1276079.251000</gml:lowerCorner>
        		<gml:upperCorner>2737400.838000 1276079.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.237.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737400.838000 1276079.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>237</ms:objectid>
        <ms:id_didok>8581706</ms:id_didok>
        <ms:name>Altnau, Bahnhof</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713364.116000 1270241.942000</gml:lowerCorner>
        		<gml:upperCorner>2713364.116000 1270241.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.306.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713364.116000 1270241.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>306</ms:objectid>
        <ms:id_didok>8573342</ms:id_didok>
        <ms:name>Wellhausen, Weinfelderstrasse</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724529.310000 1271246.887000</gml:lowerCorner>
        		<gml:upperCorner>2724529.310000 1271246.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.305.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724529.310000 1271246.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>305</ms:objectid>
        <ms:id_didok>8581619</ms:id_didok>
        <ms:name>Weinfelden, vorderes Bachtobel</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722612.709000 1272574.499000</gml:lowerCorner>
        		<gml:upperCorner>2722612.709000 1272574.499000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.829.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722612.709000 1272574.499000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>829</ms:objectid>
        <ms:id_didok>8502744</ms:id_didok>
        <ms:name>Märstetten, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715137.754000 1253938.615000</gml:lowerCorner>
        		<gml:upperCorner>2715137.754000 1253938.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.351.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715137.754000 1253938.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>351</ms:objectid>
        <ms:id_didok>8578607</ms:id_didok>
        <ms:name>Dussnang, Frohsinn</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745932.548000 1268273.424000</gml:lowerCorner>
        		<gml:upperCorner>2745932.548000 1268273.424000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.352.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745932.548000 1268273.424000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>352</ms:objectid>
        <ms:id_didok>8587160</ms:id_didok>
        <ms:name>Egnach, Kehlhof</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706927.724000 1279029.510000</gml:lowerCorner>
        		<gml:upperCorner>2706927.724000 1279029.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.349.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706927.724000 1279029.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>349</ms:objectid>
        <ms:id_didok>8583737</ms:id_didok>
        <ms:name>Eschenz, Mettlen</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715623.056000 1258276.293000</gml:lowerCorner>
        		<gml:upperCorner>2715623.056000 1258276.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.362.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715623.056000 1258276.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>362</ms:objectid>
        <ms:id_didok>8578620</ms:id_didok>
        <ms:name>Eschlikon TG, altes Schulhaus</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748151.136000 1265916.658000</gml:lowerCorner>
        		<gml:upperCorner>2748151.136000 1265916.658000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.342.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748151.136000 1265916.658000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>342</ms:objectid>
        <ms:id_didok>8587136</ms:id_didok>
        <ms:name>Frasnacht, Post</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708371.994000 1266196.183000</gml:lowerCorner>
        		<gml:upperCorner>2708371.994000 1266196.183000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.323.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708371.994000 1266196.183000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>323</ms:objectid>
        <ms:id_didok>85815230</ms:id_didok>
        <ms:name>Gerlikon, Dorf</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739909.152000 1269896.871000</gml:lowerCorner>
        		<gml:upperCorner>2739909.152000 1269896.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.257.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739909.152000 1269896.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>257</ms:objectid>
        <ms:id_didok>8582162</ms:id_didok>
        <ms:name>Hefenhofen, Sonne</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708066.014000 1271407.336000</gml:lowerCorner>
        		<gml:upperCorner>2708066.014000 1271407.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.304.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708066.014000 1271407.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>304</ms:objectid>
        <ms:id_didok>8573324</ms:id_didok>
        <ms:name>Warth, Oberdorf</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717697.213000 1260768.145000</gml:lowerCorner>
        		<gml:upperCorner>2717697.213000 1260768.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.682.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717697.213000 1260768.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>682</ms:objectid>
        <ms:id_didok>8503031</ms:id_didok>
        <ms:name>St. Margarethen, Dorf</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727484.077000 1275841.005000</gml:lowerCorner>
        		<gml:upperCorner>2727484.077000 1275841.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.262.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727484.077000 1275841.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>262</ms:objectid>
        <ms:id_didok>8506559</ms:id_didok>
        <ms:name>Neuwilen, Dorf</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750274.464000 1264122.276000</gml:lowerCorner>
        		<gml:upperCorner>2750274.464000 1264122.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.687.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750274.464000 1264122.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>687</ms:objectid>
        <ms:id_didok>8507329</ms:id_didok>
        <ms:name>Arbon, Bahnhof Ost</ms:name>
        <ms:linien_nummer>80.210</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750486.268000 1264638.572000</gml:lowerCorner>
        		<gml:upperCorner>2750486.268000 1264638.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.688.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750486.268000 1264638.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>688</ms:objectid>
        <ms:id_didok>8574250</ms:id_didok>
        <ms:name>Arbon, Schloss</ms:name>
        <ms:linien_nummer>80.210</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730570.296000 1280129.827000</gml:lowerCorner>
        		<gml:upperCorner>2730570.296000 1280129.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.866.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730570.296000 1280129.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>866</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Konstanz, Bahnhof</ms:name>
        <ms:linien_nummer>80.908</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705031.816000 1270458.019000</gml:lowerCorner>
        		<gml:upperCorner>2705031.816000 1270458.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.234.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705031.816000 1270458.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>234</ms:objectid>
        <ms:id_didok>8573319</ms:id_didok>
        <ms:name>Uesslingen, Thurbrücke</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732933.598000 1278067.215000</gml:lowerCorner>
        		<gml:upperCorner>2732933.598000 1278067.215000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.327.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732933.598000 1278067.215000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>327</ms:objectid>
        <ms:id_didok>8573410</ms:id_didok>
        <ms:name>Bottighofen, Post</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2694650.052000 1279140.460000</gml:lowerCorner>
        		<gml:upperCorner>2694650.052000 1279140.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.325.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2694650.052000 1279140.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>325</ms:objectid>
        <ms:id_didok>8580969</ms:id_didok>
        <ms:name>Schlatt TG, Mettschlatt</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732443.905000 1275929.838000</gml:lowerCorner>
        		<gml:upperCorner>2732443.905000 1275929.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.355.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732443.905000 1275929.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>355</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Dettighofen (Lengwil), Dorf</ms:name>
        <ms:linien_nummer></ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718357.651000 1250801.758000</gml:lowerCorner>
        		<gml:upperCorner>2718357.651000 1250801.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.347.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718357.651000 1250801.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>347</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Gähwil, Schmid Garage</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719330.224000 1250891.174000</gml:lowerCorner>
        		<gml:upperCorner>2719330.224000 1250891.174000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.348.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719330.224000 1250891.174000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>348</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Gähwil, Waldwies</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709672.281000 1263157.395000</gml:lowerCorner>
        		<gml:upperCorner>2709672.281000 1263157.395000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.368.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709672.281000 1263157.395000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>368</ms:objectid>
        <ms:id_didok>8506859</ms:id_didok>
        <ms:name>Hagenbuch ZH, Egghof</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745729.736000 1254274.229000</gml:lowerCorner>
        		<gml:upperCorner>2745729.736000 1254274.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.206.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745729.736000 1254274.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>206</ms:objectid>
        <ms:id_didok>8574095</ms:id_didok>
        <ms:name>St. Gallen, Bahnhof</ms:name>
        <ms:linien_nummer>80.200, 80.201, 80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747325.844000 1255133.328000</gml:lowerCorner>
        		<gml:upperCorner>2747325.844000 1255133.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.502.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747325.844000 1255133.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>502</ms:objectid>
        <ms:id_didok>8589629</ms:id_didok>
        <ms:name>St. Gallen, St. Fiden Zentrum</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714857.220000 1272927.340000</gml:lowerCorner>
        		<gml:upperCorner>2714857.220000 1272927.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.301.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714857.220000 1272927.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>301</ms:objectid>
        <ms:id_didok>8506969</ms:id_didok>
        <ms:name>Pfyn, Ost</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717532.745000 1273498.811000</gml:lowerCorner>
        		<gml:upperCorner>2717532.745000 1273498.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.297.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717532.745000 1273498.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>297</ms:objectid>
        <ms:id_didok>8506688</ms:id_didok>
        <ms:name>Müllheim Dorf, Post</ms:name>
        <ms:linien_nummer>80.829, 80.831, 80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720431.243000 1275819.415000</gml:lowerCorner>
        		<gml:upperCorner>2720431.243000 1275819.415000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.319.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720431.243000 1275819.415000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>319</ms:objectid>
        <ms:id_didok>8573349</ms:id_didok>
        <ms:name>Illhart, Oberdorf</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721083.416000 1252720.954000</gml:lowerCorner>
        		<gml:upperCorner>2721083.416000 1252720.954000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.383.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721083.416000 1252720.954000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>383</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Kirchberg SG, Neudorf</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722317.481000 1272342.644000</gml:lowerCorner>
        		<gml:upperCorner>2722317.481000 1272342.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.370.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722317.481000 1272342.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>370</ms:objectid>
        <ms:id_didok>8506565</ms:id_didok>
        <ms:name>Märstetten, Weitsicht</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731117.158000 1278396.587000</gml:lowerCorner>
        		<gml:upperCorner>2731117.158000 1278396.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.330.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731117.158000 1278396.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>330</ms:objectid>
        <ms:id_didok>8573406</ms:id_didok>
        <ms:name>Kreuzlingen, Blaues-Haus-Platz</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730512.505000 1278849.441000</gml:lowerCorner>
        		<gml:upperCorner>2730512.505000 1278849.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.328.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730512.505000 1278849.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>328</ms:objectid>
        <ms:id_didok>8573404</ms:id_didok>
        <ms:name>Kreuzlingen, Bärenplatz</ms:name>
        <ms:linien_nummer>80.908, 80.921, 80.923, 80.924, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730318.160000 1279687.085000</gml:lowerCorner>
        		<gml:upperCorner>2730318.160000 1279687.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.331.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730318.160000 1279687.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>331</ms:objectid>
        <ms:id_didok>8581696</ms:id_didok>
        <ms:name>Kreuzlingen, Hauptzoll</ms:name>
        <ms:linien_nummer>80.908</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729819.500000 1278091.269000</gml:lowerCorner>
        		<gml:upperCorner>2729819.500000 1278091.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.333.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729819.500000 1278091.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>333</ms:objectid>
        <ms:id_didok>8573391</ms:id_didok>
        <ms:name>Kreuzlingen, Jakobshöhe</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731925.226000 1278077.888000</gml:lowerCorner>
        		<gml:upperCorner>2731925.226000 1278077.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.335.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731925.226000 1278077.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>335</ms:objectid>
        <ms:id_didok>8573408</ms:id_didok>
        <ms:name>Kreuzlingen, Kurzrickenbach</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729591.002000 1278893.328000</gml:lowerCorner>
        		<gml:upperCorner>2729591.002000 1278893.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.336.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729591.002000 1278893.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>336</ms:objectid>
        <ms:id_didok>8573401</ms:id_didok>
        <ms:name>Kreuzlingen, Rebstockplatz</ms:name>
        <ms:linien_nummer>80.920, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732047.142000 1278155.786000</gml:lowerCorner>
        		<gml:upperCorner>2732047.142000 1278155.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.337.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732047.142000 1278155.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>337</ms:objectid>
        <ms:id_didok>8581717</ms:id_didok>
        <ms:name>Kreuzlingen, Seepark</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729711.508000 1279221.050000</gml:lowerCorner>
        		<gml:upperCorner>2729711.508000 1279221.050000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.338.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729711.508000 1279221.050000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>338</ms:objectid>
        <ms:id_didok>8581996</ms:id_didok>
        <ms:name>Kreuzlingen, Weiherstrasse</ms:name>
        <ms:linien_nummer>80.920, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721584.312000 1274934.312000</gml:lowerCorner>
        		<gml:upperCorner>2721584.312000 1274934.312000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.367.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721584.312000 1274934.312000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>367</ms:objectid>
        <ms:id_didok>8506885</ms:id_didok>
        <ms:name>Lipperswil, Conny Land</ms:name>
        <ms:linien_nummer>80.832, 80.833, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721574.099000 1275161.350000</gml:lowerCorner>
        		<gml:upperCorner>2721574.099000 1275161.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.320.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721574.099000 1275161.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>320</ms:objectid>
        <ms:id_didok>8581971</ms:id_didok>
        <ms:name>Lipperswil, Kellhof</ms:name>
        <ms:linien_nummer>80.832, 80.833, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716914.641000 1258189.749000</gml:lowerCorner>
        		<gml:upperCorner>2716914.641000 1258189.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.707.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716914.641000 1258189.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>707</ms:objectid>
        <ms:id_didok>8578618</ms:id_didok>
        <ms:name>Sirnach, Hofen</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2701189.949000 1272538.901000</gml:lowerCorner>
        		<gml:upperCorner>2701189.949000 1272538.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.363.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2701189.949000 1272538.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>363</ms:objectid>
        <ms:id_didok>8506887</ms:id_didok>
        <ms:name>Niederneunforn, Dorf</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740549.898000 1268128.895000</gml:lowerCorner>
        		<gml:upperCorner>2740549.898000 1268128.895000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.137.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740549.898000 1268128.895000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>137</ms:objectid>
        <ms:id_didok>8587147</ms:id_didok>
        <ms:name>Amriswil, Säntisstrasse</ms:name>
        <ms:linien_nummer>80.942, 80.943, 80.944</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730667.276000 1269102.091000</gml:lowerCorner>
        		<gml:upperCorner>2730667.276000 1269102.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.372.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730667.276000 1269102.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>372</ms:objectid>
        <ms:id_didok>8581620</ms:id_didok>
        <ms:name>Opfershofen TG, Dorf</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713475.341000 1272270.223000</gml:lowerCorner>
        		<gml:upperCorner>2713475.341000 1272270.223000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.317.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713475.341000 1272270.223000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>317</ms:objectid>
        <ms:id_didok>8581973</ms:id_didok>
        <ms:name>Pfyn, Biberpfad</ms:name>
        <ms:linien_nummer>80.826, 80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720225.475000 1276077.989000</gml:lowerCorner>
        		<gml:upperCorner>2720225.475000 1276077.989000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.322.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720225.475000 1276077.989000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>322</ms:objectid>
        <ms:id_didok>8573350</ms:id_didok>
        <ms:name>Raperswilen, Im Wiel</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746847.456000 1265648.366000</gml:lowerCorner>
        		<gml:upperCorner>2746847.456000 1265648.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.374.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746847.456000 1265648.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>374</ms:objectid>
        <ms:id_didok>8587193</ms:id_didok>
        <ms:name>Roggwil TG, Ebnet</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726659.606000 1263372.666000</gml:lowerCorner>
        		<gml:upperCorner>2726659.606000 1263372.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.373.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726659.606000 1263372.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>373</ms:objectid>
        <ms:id_didok>8506658</ms:id_didok>
        <ms:name>Schönholzerswilen, Hagenwil</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.50">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740259.035000 1261344.705000</gml:lowerCorner>
        		<gml:upperCorner>2740259.035000 1261344.705000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.50.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740259.035000 1261344.705000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>50</ms:objectid>
        <ms:id_didok>8503031</ms:id_didok>
        <ms:name>St. Pelagiberg, Kurhaus</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2744514.375000 1266415.580000</gml:lowerCorner>
        		<gml:upperCorner>2744514.375000 1266415.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.344.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2744514.375000 1266415.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>344</ms:objectid>
        <ms:id_didok>8587218</ms:id_didok>
        <ms:name>Steinebrunn, Erdhausen</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714454.159000 1267260.795000</gml:lowerCorner>
        		<gml:upperCorner>2714454.159000 1267260.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.324.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714454.159000 1267260.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>324</ms:objectid>
        <ms:id_didok>8573366</ms:id_didok>
        <ms:name>Thundorf, Ildbach</ms:name>
        <ms:linien_nummer>80.837, 80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715812.095000 1275308.145000</gml:lowerCorner>
        		<gml:upperCorner>2715812.095000 1275308.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.318.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715812.095000 1275308.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>318</ms:objectid>
        <ms:id_didok>8506978</ms:id_didok>
        <ms:name>Unterhörstetten, Dorf</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708049.278000 1271194.853000</gml:lowerCorner>
        		<gml:upperCorner>2708049.278000 1271194.853000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.358.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708049.278000 1271194.853000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>358</ms:objectid>
        <ms:id_didok>8506948</ms:id_didok>
        <ms:name>Warth, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726235.028000 1269823.529000</gml:lowerCorner>
        		<gml:upperCorner>2726235.028000 1269823.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.385.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726235.028000 1269823.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>385</ms:objectid>
        <ms:id_didok>8582006</ms:id_didok>
        <ms:name>Weinfelden, Sonnenplatz</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710070.833000 1259621.296000</gml:lowerCorner>
        		<gml:upperCorner>2710070.833000 1259621.296000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.448.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710070.833000 1259621.296000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>448</ms:objectid>
        <ms:id_didok>8576933</ms:id_didok>
        <ms:name>Ettenhausen TG, Elggerstrasse</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2711539.773000 1266919.687000</gml:lowerCorner>
        		<gml:upperCorner>2711539.773000 1266919.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.388.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2711539.773000 1266919.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>388</ms:objectid>
        <ms:id_didok>8506856</ms:id_didok>
        <ms:name>Frauenfeld, Bühl</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737318.415000 1275783.235000</gml:lowerCorner>
        		<gml:upperCorner>2737318.415000 1275783.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.239.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737318.415000 1275783.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>239</ms:objectid>
        <ms:id_didok>8573428</ms:id_didok>
        <ms:name>Altnau, Längiacker</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750157.436000 1264615.254000</gml:lowerCorner>
        		<gml:upperCorner>2750157.436000 1264615.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.689.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750157.436000 1264615.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>689</ms:objectid>
        <ms:id_didok>8581389</ms:id_didok>
        <ms:name>Arbon, Friedenstrasse</ms:name>
        <ms:linien_nummer>80.210</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743907.497000 1266302.635000</gml:lowerCorner>
        		<gml:upperCorner>2743907.497000 1266302.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.830.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743907.497000 1266302.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>830</ms:objectid>
        <ms:id_didok>8505057</ms:id_didok>
        <ms:name>Steinebrunn, Bahnhof</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706124.605000 1266601.705000</gml:lowerCorner>
        		<gml:upperCorner>2706124.605000 1266601.705000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.407.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706124.605000 1266601.705000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>407</ms:objectid>
        <ms:id_didok>8582010</ms:id_didok>
        <ms:name>Gachnang, Kath. Kirche</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730469.258000 1278657.805000</gml:lowerCorner>
        		<gml:upperCorner>2730469.258000 1278657.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.398.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730469.258000 1278657.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>398</ms:objectid>
        <ms:id_didok>8580246</ms:id_didok>
        <ms:name>Kreuzlingen, Alterszentrum</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729401.157000 1278961.214000</gml:lowerCorner>
        		<gml:upperCorner>2729401.157000 1278961.214000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.421.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729401.157000 1278961.214000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>421</ms:objectid>
        <ms:id_didok>8573377</ms:id_didok>
        <ms:name>Kreuzlingen, MOWAG</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733713.452000 1270012.576000</gml:lowerCorner>
        		<gml:upperCorner>2733713.452000 1270012.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.371.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733713.452000 1270012.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>371</ms:objectid>
        <ms:id_didok>8582177</ms:id_didok>
        <ms:name>Andwil TG, Volg</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715302.579000 1277116.245000</gml:lowerCorner>
        		<gml:upperCorner>2715302.579000 1277116.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.365.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715302.579000 1277116.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>365</ms:objectid>
        <ms:id_didok>8573337</ms:id_didok>
        <ms:name>Hörhausen, alte Post</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724066.254000 1267749.928000</gml:lowerCorner>
        		<gml:upperCorner>2724066.254000 1267749.928000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.326.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724066.254000 1267749.928000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>326</ms:objectid>
        <ms:id_didok>8582604</ms:id_didok>
        <ms:name>Oberbussnang, Feuerwehrdepot</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718057.123000 1250812.487000</gml:lowerCorner>
        		<gml:upperCorner>2718057.123000 1250812.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.346.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718057.123000 1250812.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>346</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Gähwil, Dorf</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714995.491000 1276781.208000</gml:lowerCorner>
        		<gml:upperCorner>2714995.491000 1276781.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.316.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714995.491000 1276781.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>316</ms:objectid>
        <ms:id_didok>8506881</ms:id_didok>
        <ms:name>Hörhausen, Dorf</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745901.432000 1265842.459000</gml:lowerCorner>
        		<gml:upperCorner>2745901.432000 1265842.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.394.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745901.432000 1265842.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>394</ms:objectid>
        <ms:id_didok>8587187</ms:id_didok>
        <ms:name>Neukirch (Egnach), Ost</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2694307.441000 1279179.383000</gml:lowerCorner>
        		<gml:upperCorner>2694307.441000 1279179.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.369.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2694307.441000 1279179.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>369</ms:objectid>
        <ms:id_didok>8580970</ms:id_didok>
        <ms:name>Oberschlatt TG, Dorf</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715743.452000 1254921.884000</gml:lowerCorner>
        		<gml:upperCorner>2715743.452000 1254921.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.419.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715743.452000 1254921.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>419</ms:objectid>
        <ms:id_didok>8578605</ms:id_didok>
        <ms:name>Oberwangen TG, Grueb</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735947.089000 1276694.653000</gml:lowerCorner>
        		<gml:upperCorner>2735947.089000 1276694.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.514.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735947.089000 1276694.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>514</ms:objectid>
        <ms:id_didok>8573426</ms:id_didok>
        <ms:name>Landschlacht, Schulstrasse</ms:name>
        <ms:linien_nummer>80.908, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736831.011000 1275092.908000</gml:lowerCorner>
        		<gml:upperCorner>2736831.011000 1275092.908000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.408.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736831.011000 1275092.908000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>408</ms:objectid>
        <ms:id_didok>8573430</ms:id_didok>
        <ms:name>Altnau, Zentrum</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720575.810000 1256748.600000</gml:lowerCorner>
        		<gml:upperCorner>2720575.810000 1256748.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.321.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720575.810000 1256748.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>321</ms:objectid>
        <ms:id_didok>8594468</ms:id_didok>
        <ms:name>Wilen bei Wil, Engi</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728800.664000 1256397.176000</gml:lowerCorner>
        		<gml:upperCorner>2728800.664000 1256397.176000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.403.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728800.664000 1256397.176000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>403</ms:objectid>
        <ms:id_didok>8506874</ms:id_didok>
        <ms:name>Niederuzwil, Augarten</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732883.908000 1258659.193000</gml:lowerCorner>
        		<gml:upperCorner>2732883.908000 1258659.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.404.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732883.908000 1258659.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>404</ms:objectid>
        <ms:id_didok>8573934</ms:id_didok>
        <ms:name>Niederbüren, Freizeitpark</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733114.171000 1258853.708000</gml:lowerCorner>
        		<gml:upperCorner>2733114.171000 1258853.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.405.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733114.171000 1258853.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>405</ms:objectid>
        <ms:id_didok>8506687</ms:id_didok>
        <ms:name>Niederbüren, Dorf</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2744879.831000 1260564.541000</gml:lowerCorner>
        		<gml:upperCorner>2744879.831000 1260564.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.361.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2744879.831000 1260564.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>361</ms:objectid>
        <ms:id_didok>8579847</ms:id_didok>
        <ms:name>Wittenbach, Unterlören</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714617.847000 1254428.966000</gml:lowerCorner>
        		<gml:upperCorner>2714617.847000 1254428.966000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.447.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714617.847000 1254428.966000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>447</ms:objectid>
        <ms:id_didok>8578632</ms:id_didok>
        <ms:name>Dussnang, Tannegg</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721723.106000 1255604.655000</gml:lowerCorner>
        		<gml:upperCorner>2721723.106000 1255604.655000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.411.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721723.106000 1255604.655000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>411</ms:objectid>
        <ms:id_didok>8507441</ms:id_didok>
        <ms:name>Wil SG, Stelz</ms:name>
        <ms:linien_nummer>80.731</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>REGO</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714143.886000 1272834.269000</gml:lowerCorner>
        		<gml:upperCorner>2714143.886000 1272834.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.357.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714143.886000 1272834.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>357</ms:objectid>
        <ms:id_didok>8506871</ms:id_didok>
        <ms:name>Pfyn, Gemeinde</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717776.462000 1273687.769000</gml:lowerCorner>
        		<gml:upperCorner>2717776.462000 1273687.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.406.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717776.462000 1273687.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>406</ms:objectid>
        <ms:id_didok>8583226</ms:id_didok>
        <ms:name>Müllheim Dorf, Rosengasse</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745474.187000 1266106.267000</gml:lowerCorner>
        		<gml:upperCorner>2745474.187000 1266106.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.386.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745474.187000 1266106.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>386</ms:objectid>
        <ms:id_didok>8587185</ms:id_didok>
        <ms:name>Neukirch (Egnach), Dorf</ms:name>
        <ms:linien_nummer>80.940, 80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749645.815000 1264212.008000</gml:lowerCorner>
        		<gml:upperCorner>2749645.815000 1264212.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.402.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749645.815000 1264212.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>402</ms:objectid>
        <ms:id_didok>8587154</ms:id_didok>
        <ms:name>Arbon, Alter Werkhof</ms:name>
        <ms:linien_nummer>80.200, 80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726685.242000 1269716.880000</gml:lowerCorner>
        		<gml:upperCorner>2726685.242000 1269716.880000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.401.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726685.242000 1269716.880000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>401</ms:objectid>
        <ms:id_didok>8573287</ms:id_didok>
        <ms:name>Weinfelden, Aeuli</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745851.202000 1269903.805000</gml:lowerCorner>
        		<gml:upperCorner>2745851.202000 1269903.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.126.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745851.202000 1269903.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>126</ms:objectid>
        <ms:id_didok>8587197</ms:id_didok>
        <ms:name>Romanshorn, Coop</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734748.226000 1276868.747000</gml:lowerCorner>
        		<gml:upperCorner>2734748.226000 1276868.747000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.409.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734748.226000 1276868.747000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>409</ms:objectid>
        <ms:id_didok>8581699</ms:id_didok>
        <ms:name>Scherzingen, Rohrenzelg</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2694176.950000 1281100.478000</gml:lowerCorner>
        		<gml:upperCorner>2694176.950000 1281100.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.390.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2694176.950000 1281100.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>390</ms:objectid>
        <ms:id_didok>8573490</ms:id_didok>
        <ms:name>Schlatt TG, Held</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725577.698000 1264470.419000</gml:lowerCorner>
        		<gml:upperCorner>2725577.698000 1264470.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.393.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725577.698000 1264470.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>393</ms:objectid>
        <ms:id_didok>85826060</ms:id_didok>
        <ms:name>Schönholzerswilen, Toos</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745238.340000 1269475.047000</gml:lowerCorner>
        		<gml:upperCorner>2745238.340000 1269475.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.127.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745238.340000 1269475.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>127</ms:objectid>
        <ms:id_didok>8587199</ms:id_didok>
        <ms:name>Romanshorn, Hofstrasse</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745408.958000 1269739.757000</gml:lowerCorner>
        		<gml:upperCorner>2745408.958000 1269739.757000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.128.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745408.958000 1269739.757000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>128</ms:objectid>
        <ms:id_didok>8587204</ms:id_didok>
        <ms:name>Romanshorn, Salmsacherstrasse</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722050.263000 1271554.246000</gml:lowerCorner>
        		<gml:upperCorner>2722050.263000 1271554.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.518.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722050.263000 1271554.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>518</ms:objectid>
        <ms:id_didok>8573386</ms:id_didok>
        <ms:name>Märstetten, Bahnhof</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722221.824000 1274303.721000</gml:lowerCorner>
        		<gml:upperCorner>2722221.824000 1274303.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.302.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722221.824000 1274303.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>302</ms:objectid>
        <ms:id_didok>8506567</ms:id_didok>
        <ms:name>Wagerswil, Dorf</ms:name>
        <ms:linien_nummer>80.832, 80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.96">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716200.501000 1279946.438000</gml:lowerCorner>
        		<gml:upperCorner>2716200.501000 1279946.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.96.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716200.501000 1279946.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>96</ms:objectid>
        <ms:id_didok>8506626</ms:id_didok>
        <ms:name>Steckborn, Sportplatz Emmig</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716078.275000 1280179.824000</gml:lowerCorner>
        		<gml:upperCorner>2716078.275000 1280179.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.310.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716078.275000 1280179.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>310</ms:objectid>
        <ms:id_didok>8506591</ms:id_didok>
        <ms:name>Steckborn, Haldenberg</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724287.366000 1264955.696000</gml:lowerCorner>
        		<gml:upperCorner>2724287.366000 1264955.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.359.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724287.366000 1264955.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>359</ms:objectid>
        <ms:id_didok>8506668</ms:id_didok>
        <ms:name>Stehrenberg, Dorf</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2751316.234000 1263150.556000</gml:lowerCorner>
        		<gml:upperCorner>2751316.234000 1263150.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.600.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2751316.234000 1263150.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>600</ms:objectid>
        <ms:id_didok>85837880</ms:id_didok>
        <ms:name>Steinach, Hafen</ms:name>
        <ms:linien_nummer>80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743412.241000 1266555.480000</gml:lowerCorner>
        		<gml:upperCorner>2743412.241000 1266555.480000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.343.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743412.241000 1266555.480000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>343</ms:objectid>
        <ms:id_didok>8587217</ms:id_didok>
        <ms:name>Steinebrunn, Dorf</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2701075.285000 1278965.654000</gml:lowerCorner>
        		<gml:upperCorner>2701075.285000 1278965.654000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.364.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2701075.285000 1278965.654000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>364</ms:objectid>
        <ms:id_didok>8573331</ms:id_didok>
        <ms:name>Unterstammheim, Neubr.-Ulmerh.</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716175.487000 1255834.969000</gml:lowerCorner>
        		<gml:upperCorner>2716175.487000 1255834.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.418.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716175.487000 1255834.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>418</ms:objectid>
        <ms:id_didok>8578604</ms:id_didok>
        <ms:name>Wiezikon b.Sirnach, Wies</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720238.903000 1256937.331000</gml:lowerCorner>
        		<gml:upperCorner>2720238.903000 1256937.331000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.444.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720238.903000 1256937.331000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>444</ms:objectid>
        <ms:id_didok>8588106</ms:id_didok>
        <ms:name>Wilen bei Wil, Gemeindezentrum</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723304.756000 1281150.870000</gml:lowerCorner>
        		<gml:upperCorner>2723304.756000 1281150.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.307.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723304.756000 1281150.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>307</ms:objectid>
        <ms:id_didok>8581970</ms:id_didok>
        <ms:name>Ermatingen, Rathaus</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713493.149000 1275107.714000</gml:lowerCorner>
        		<gml:upperCorner>2713493.149000 1275107.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.532.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713493.149000 1275107.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>532</ms:objectid>
        <ms:id_didok>8506857</ms:id_didok>
        <ms:name>Dettighofen, Lanzenneunfornstr</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713963.954000 1275267.040000</gml:lowerCorner>
        		<gml:upperCorner>2713963.954000 1275267.040000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.531.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713963.954000 1275267.040000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>531</ms:objectid>
        <ms:id_didok>8581972</ms:id_didok>
        <ms:name>Dettighofen, Linde</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724565.279000 1275634.521000</gml:lowerCorner>
        		<gml:upperCorner>2724565.279000 1275634.521000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.540.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724565.279000 1275634.521000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>540</ms:objectid>
        <ms:id_didok>8581810</ms:id_didok>
        <ms:name>Engwilen, Hauptstrasse</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709034.194000 1267387.302000</gml:lowerCorner>
        		<gml:upperCorner>2709034.194000 1267387.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.537.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709034.194000 1267387.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>537</ms:objectid>
        <ms:id_didok>8578082</ms:id_didok>
        <ms:name>Frauenfeld, Bruder-K. Kapelle</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740953.099000 1266081.303000</gml:lowerCorner>
        		<gml:upperCorner>2740953.099000 1266081.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.508.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740953.099000 1266081.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>508</ms:objectid>
        <ms:id_didok>8587170</ms:id_didok>
        <ms:name>Hagenwil bei Amriswil, Käserei</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705207.631000 1272914.938000</gml:lowerCorner>
        		<gml:upperCorner>2705207.631000 1272914.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.505.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705207.631000 1272914.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>505</ms:objectid>
        <ms:id_didok>8506689</ms:id_didok>
        <ms:name>Buch bei Frauenfeld, Dorf</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733059.969000 1274124.362000</gml:lowerCorner>
        		<gml:upperCorner>2733059.969000 1274124.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.509.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733059.969000 1274124.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>509</ms:objectid>
        <ms:id_didok>8578137</ms:id_didok>
        <ms:name>Illighausen, Dorf</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747465.465000 1258317.252000</gml:lowerCorner>
        		<gml:upperCorner>2747465.465000 1258317.252000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.491.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747465.465000 1258317.252000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>491</ms:objectid>
        <ms:id_didok>8574253</ms:id_didok>
        <ms:name>Kronbühl, Kantonalbank</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722711.866000 1271266.462000</gml:lowerCorner>
        		<gml:upperCorner>2722711.866000 1271266.462000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.519.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722711.866000 1271266.462000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>519</ms:objectid>
        <ms:id_didok>8582808</ms:id_didok>
        <ms:name>Märstetten, Muggenwinggel</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720183.180000 1274561.620000</gml:lowerCorner>
        		<gml:upperCorner>2720183.180000 1274561.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.517.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720183.180000 1274561.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>517</ms:objectid>
        <ms:id_didok>8506594</ms:id_didok>
        <ms:name>Lamperswil TG, Illharterstr.</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748051.275000 1263381.474000</gml:lowerCorner>
        		<gml:upperCorner>2748051.275000 1263381.474000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.387.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748051.275000 1263381.474000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>387</ms:objectid>
        <ms:id_didok>8574245</ms:id_didok>
        <ms:name>Roggwil TG, Frohheim</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719580.568000 1268570.129000</gml:lowerCorner>
        		<gml:upperCorner>2719580.568000 1268570.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.577.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719580.568000 1268570.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>577</ms:objectid>
        <ms:id_didok>8573369</ms:id_didok>
        <ms:name>Griesenberg, Vogelsang</ms:name>
        <ms:linien_nummer>80.383</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709266.425000 1264373.970000</gml:lowerCorner>
        		<gml:upperCorner>2709266.425000 1264373.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.476.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709266.425000 1264373.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>476</ms:objectid>
        <ms:id_didok>85068650</ms:id_didok>
        <ms:name>Hagenbuch ZH, Dorf</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713102.121000 1258296.175000</gml:lowerCorner>
        		<gml:upperCorner>2713102.121000 1258296.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.474.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713102.121000 1258296.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>474</ms:objectid>
        <ms:id_didok>8578623</ms:id_didok>
        <ms:name>Ifwil b. B., Aadorferstrasse</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720631.738000 1257649.951000</gml:lowerCorner>
        		<gml:upperCorner>2720631.738000 1257649.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.435.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720631.738000 1257649.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>435</ms:objectid>
        <ms:id_didok>8578825</ms:id_didok>
        <ms:name>Wil SG, Bergholz</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722606.950000 1259581.835000</gml:lowerCorner>
        		<gml:upperCorner>2722606.950000 1259581.835000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.410.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722606.950000 1259581.835000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>410</ms:objectid>
        <ms:id_didok>8573605</ms:id_didok>
        <ms:name>Rossrüti, Furtbach</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716158.020000 1274617.636000</gml:lowerCorner>
        		<gml:upperCorner>2716158.020000 1274617.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.533.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716158.020000 1274617.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>533</ms:objectid>
        <ms:id_didok>8573357</ms:id_didok>
        <ms:name>Müllheim, Ober Hungerbüel</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2704358.754000 1275854.429000</gml:lowerCorner>
        		<gml:upperCorner>2704358.754000 1275854.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.506.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2704358.754000 1275854.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>506</ms:objectid>
        <ms:id_didok>8506888</ms:id_didok>
        <ms:name>Nussbaumen TG, Schulhaus</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715686.921000 1275741.789000</gml:lowerCorner>
        		<gml:upperCorner>2715686.921000 1275741.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.522.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715686.921000 1275741.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>522</ms:objectid>
        <ms:id_didok>8573358</ms:id_didok>
        <ms:name>Oberhörstetten, Abzw.</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732256.055000 1258250.237000</gml:lowerCorner>
        		<gml:upperCorner>2732256.055000 1258250.237000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.484.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732256.055000 1258250.237000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>484</ms:objectid>
        <ms:id_didok>8506726</ms:id_didok>
        <ms:name>Niederbüren, Nellen</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731060.719000 1257459.575000</gml:lowerCorner>
        		<gml:upperCorner>2731060.719000 1257459.575000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.485.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731060.719000 1257459.575000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>485</ms:objectid>
        <ms:id_didok>8506583</ms:id_didok>
        <ms:name>Oberbüren, Eich/Au</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735120.910000 1259635.148000</gml:lowerCorner>
        		<gml:upperCorner>2735120.910000 1259635.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.478.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735120.910000 1259635.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>478</ms:objectid>
        <ms:id_didok>8506587</ms:id_didok>
        <ms:name>Niederbüren, Museum</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733447.882000 1259393.865000</gml:lowerCorner>
        		<gml:upperCorner>2733447.882000 1259393.865000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.483.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733447.882000 1259393.865000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>483</ms:objectid>
        <ms:id_didok>8506585</ms:id_didok>
        <ms:name>Niederbüren, Husen</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743587.159000 1261476.590000</gml:lowerCorner>
        		<gml:upperCorner>2743587.159000 1261476.590000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.482.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743587.159000 1261476.590000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>482</ms:objectid>
        <ms:id_didok>8579980</ms:id_didok>
        <ms:name>Häggenschwil, Täschlihus</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746717.434000 1258815.675000</gml:lowerCorner>
        		<gml:upperCorner>2746717.434000 1258815.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.504.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746717.434000 1258815.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>504</ms:objectid>
        <ms:id_didok>8574256</ms:id_didok>
        <ms:name>Wittenbach, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747406.995000 1256314.010000</gml:lowerCorner>
        		<gml:upperCorner>2747406.995000 1256314.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.426.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747406.995000 1256314.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>426</ms:objectid>
        <ms:id_didok>8506459</ms:id_didok>
        <ms:name>St. Gallen, Heiligkreuzstrasse</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746599.117000 1255267.604000</gml:lowerCorner>
        		<gml:upperCorner>2746599.117000 1255267.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.429.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746599.117000 1255267.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>429</ms:objectid>
        <ms:id_didok>8589605</ms:id_didok>
        <ms:name>St. Gallen, Olma Messen</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746819.686000 1254816.427000</gml:lowerCorner>
        		<gml:upperCorner>2746819.686000 1254816.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.431.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746819.686000 1254816.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>431</ms:objectid>
        <ms:id_didok>8589625</ms:id_didok>
        <ms:name>St. Gallen, Singenberg</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748404.145000 1255933.441000</gml:lowerCorner>
        		<gml:upperCorner>2748404.145000 1255933.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.424.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748404.145000 1255933.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>424</ms:objectid>
        <ms:id_didok>8580689</ms:id_didok>
        <ms:name>St. Gallen, Neudorf/R&#39;str.</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749018.328000 1256596.583000</gml:lowerCorner>
        		<gml:upperCorner>2749018.328000 1256596.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.425.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749018.328000 1256596.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>425</ms:objectid>
        <ms:id_didok>8580688</ms:id_didok>
        <ms:name>St. Gallen, Remishueb / Klinik</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749458.049000 1259250.279000</gml:lowerCorner>
        		<gml:upperCorner>2749458.049000 1259250.279000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.492.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749458.049000 1259250.279000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>492</ms:objectid>
        <ms:id_didok>8581395</ms:id_didok>
        <ms:name>Mörschwil, Altes Gemeindehaus</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729995.920000 1278803.158000</gml:lowerCorner>
        		<gml:upperCorner>2729995.920000 1278803.158000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.334.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729995.920000 1278803.158000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>334</ms:objectid>
        <ms:id_didok>8573402</ms:id_didok>
        <ms:name>Kreuzlingen, Kolosseumplatz</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720282.951000 1258372.304000</gml:lowerCorner>
        		<gml:upperCorner>2720282.951000 1258372.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.832.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720282.951000 1258372.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>832</ms:objectid>
        <ms:id_didok>8589928</ms:id_didok>
        <ms:name>Wil SG, Zürcherstrasse</ms:name>
        <ms:linien_nummer>80.733 (Abendkurs), 80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716789.015000 1273133.863000</gml:lowerCorner>
        		<gml:upperCorner>2716789.015000 1273133.863000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.520.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716789.015000 1273133.863000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>520</ms:objectid>
        <ms:id_didok>8506595</ms:id_didok>
        <ms:name>Müllheim Dorf, Grüneck</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717111.881000 1274021.541000</gml:lowerCorner>
        		<gml:upperCorner>2717111.881000 1274021.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.521.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717111.881000 1274021.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>521</ms:objectid>
        <ms:id_didok>8579925</ms:id_didok>
        <ms:name>Müllheim Dorf, Himmelbrunnen</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740618.755000 1267675.251000</gml:lowerCorner>
        		<gml:upperCorner>2740618.755000 1267675.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.420.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740618.755000 1267675.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>420</ms:objectid>
        <ms:id_didok>8595456</ms:id_didok>
        <ms:name>Amriswil, Maihalde</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746012.155000 1270070.815000</gml:lowerCorner>
        		<gml:upperCorner>2746012.155000 1270070.815000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.354.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746012.155000 1270070.815000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>354</ms:objectid>
        <ms:id_didok>8587195</ms:id_didok>
        <ms:name>Romanshorn, Bahnhof</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707715.600000 1267071.611000</gml:lowerCorner>
        		<gml:upperCorner>2707715.600000 1267071.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.511.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707715.600000 1267071.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>511</ms:objectid>
        <ms:id_didok>8581410</ms:id_didok>
        <ms:name>Oberwil TG, Dorf</ms:name>
        <ms:linien_nummer>80.836</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720525.318000 1277063.849000</gml:lowerCorner>
        		<gml:upperCorner>2720525.318000 1277063.849000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.534.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720525.318000 1277063.849000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>534</ms:objectid>
        <ms:id_didok>8506984</ms:id_didok>
        <ms:name>Raperswilen, Dorf</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726320.784000 1267098.911000</gml:lowerCorner>
        		<gml:upperCorner>2726320.784000 1267098.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.516.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726320.784000 1267098.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>516</ms:objectid>
        <ms:id_didok>8573610</ms:id_didok>
        <ms:name>Reuti b. Weinfelden, Hauptstr.</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745798.884000 1270539.013000</gml:lowerCorner>
        		<gml:upperCorner>2745798.884000 1270539.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.101.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745798.884000 1270539.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>101</ms:objectid>
        <ms:id_didok>8587194</ms:id_didok>
        <ms:name>Romanshorn, Alleestrasse</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745471.946000 1270721.333000</gml:lowerCorner>
        		<gml:upperCorner>2745471.946000 1270721.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.102.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745471.946000 1270721.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>102</ms:objectid>
        <ms:id_didok>8587196</ms:id_didok>
        <ms:name>Romanshorn, Blumenweg</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733954.922000 1277506.195000</gml:lowerCorner>
        		<gml:upperCorner>2733954.922000 1277506.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.539.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733954.922000 1277506.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>539</ms:objectid>
        <ms:id_didok>8573412</ms:id_didok>
        <ms:name>Scherzingen, Scheidweg</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2734734.892000 1275288.044000</gml:lowerCorner>
        		<gml:upperCorner>2734734.892000 1275288.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.266.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2734734.892000 1275288.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>266</ms:objectid>
        <ms:id_didok>8573417</ms:id_didok>
        <ms:name>Schönenbaumgarten, Dorf</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713981.111000 1266023.403000</gml:lowerCorner>
        		<gml:upperCorner>2713981.111000 1266023.403000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.538.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713981.111000 1266023.403000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>538</ms:objectid>
        <ms:id_didok>8581616</ms:id_didok>
        <ms:name>Stettfurt, Köll</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728174.953000 1279417.859000</gml:lowerCorner>
        		<gml:upperCorner>2728174.953000 1279417.859000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.339.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728174.953000 1279417.859000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>339</ms:objectid>
        <ms:id_didok>8581692</ms:id_didok>
        <ms:name>Tägerwilen, Glaserstrasse</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727524.624000 1279592.768000</gml:lowerCorner>
        		<gml:upperCorner>2727524.624000 1279592.768000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.340.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727524.624000 1279592.768000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>340</ms:objectid>
        <ms:id_didok>8573378</ms:id_didok>
        <ms:name>Tägerwilen, Kirche</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.49">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2751918.382000 1261322.227000</gml:lowerCorner>
        		<gml:upperCorner>2751918.382000 1261322.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.49.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2751918.382000 1261322.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>49</ms:objectid>
        <ms:id_didok>8580866</ms:id_didok>
        <ms:name>Tübach, Schulstrasse</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2704934.484000 1270930.821000</gml:lowerCorner>
        		<gml:upperCorner>2704934.484000 1270930.821000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.235.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2704934.484000 1270930.821000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>235</ms:objectid>
        <ms:id_didok>8582457</ms:id_didok>
        <ms:name>Uesslingen, Zollhausweg</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2702692.993000 1272392.769000</gml:lowerCorner>
        		<gml:upperCorner>2702692.993000 1272392.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.507.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2702692.993000 1272392.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>507</ms:objectid>
        <ms:id_didok>8582718</ms:id_didok>
        <ms:name>Uesslingen, Trüfelbach</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707901.998000 1271295.680000</gml:lowerCorner>
        		<gml:upperCorner>2707901.998000 1271295.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.523.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707901.998000 1271295.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>523</ms:objectid>
        <ms:id_didok>8573300</ms:id_didok>
        <ms:name>Warth, Kreuz</ms:name>
        <ms:linien_nummer>80.819, 80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739813.433000 1261177.695000</gml:lowerCorner>
        		<gml:upperCorner>2739813.433000 1261177.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.479.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739813.433000 1261177.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>479</ms:objectid>
        <ms:id_didok>8578806</ms:id_didok>
        <ms:name>Wilen (Gottshaus), Mollishaus</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737771.481000 1262396.380000</gml:lowerCorner>
        		<gml:upperCorner>2737771.481000 1262396.380000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.480.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737771.481000 1262396.380000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>480</ms:objectid>
        <ms:id_didok>8578803</ms:id_didok>
        <ms:name>Wilen (Gottshaus), Rehalp</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720613.308000 1257078.190000</gml:lowerCorner>
        		<gml:upperCorner>2720613.308000 1257078.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.467.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720613.308000 1257078.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>467</ms:objectid>
        <ms:id_didok>8578823</ms:id_didok>
        <ms:name>Wilen bei Wil, Lerchenfeld</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720573.903000 1256904.999000</gml:lowerCorner>
        		<gml:upperCorner>2720573.903000 1256904.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.468.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720573.903000 1256904.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>468</ms:objectid>
        <ms:id_didok>8578822</ms:id_didok>
        <ms:name>Wilen bei Wil, Scheidweg</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724883.295000 1270263.520000</gml:lowerCorner>
        		<gml:upperCorner>2724883.295000 1270263.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.114.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724883.295000 1270263.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>114</ms:objectid>
        <ms:id_didok>8573373</ms:id_didok>
        <ms:name>Weinfelden, Maienrain</ms:name>
        <ms:linien_nummer>80.722, 80.833, 80.838, 80.932</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726038.881000 1261973.172000</gml:lowerCorner>
        		<gml:upperCorner>2726038.881000 1261973.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.535.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726038.881000 1261973.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>535</ms:objectid>
        <ms:id_didok>8588624</ms:id_didok>
        <ms:name>Wuppenau, Im Rank</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733659.948000 1270618.855000</gml:lowerCorner>
        		<gml:upperCorner>2733659.948000 1270618.855000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.512.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733659.948000 1270618.855000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>512</ms:objectid>
        <ms:id_didok>8582176</ms:id_didok>
        <ms:name>Andwil TG, Eckartshausen</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723525.911000 1268558.558000</gml:lowerCorner>
        		<gml:upperCorner>2723525.911000 1268558.558000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.392.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723525.911000 1268558.558000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>392</ms:objectid>
        <ms:id_didok>8582599</ms:id_didok>
        <ms:name>Bussnang, Alterszentrum</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723801.130000 1268710.478000</gml:lowerCorner>
        		<gml:upperCorner>2723801.130000 1268710.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.566.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723801.130000 1268710.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>566</ms:objectid>
        <ms:id_didok>8594772</ms:id_didok>
        <ms:name>Bussnang, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.722, 80.935</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720326.538000 1257880.094000</gml:lowerCorner>
        		<gml:upperCorner>2720326.538000 1257880.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.834.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720326.538000 1257880.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>834</ms:objectid>
        <ms:id_didok>8578796</ms:id_didok>
        <ms:name>Wil SG, Kantonsschule</ms:name>
        <ms:linien_nummer>80.733, 80.735</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745006.872000 1270164.065000</gml:lowerCorner>
        		<gml:upperCorner>2745006.872000 1270164.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.831.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745006.872000 1270164.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>831</ms:objectid>
        <ms:id_didok>8587202</ms:id_didok>
        <ms:name>Romanshorn, Hueb</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719413.307000 1257594.310000</gml:lowerCorner>
        		<gml:upperCorner>2719413.307000 1257594.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.836.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719413.307000 1257594.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>836</ms:objectid>
        <ms:id_didok>8578794</ms:id_didok>
        <ms:name>Busswil TG, Kreuzstrasse </ms:name>
        <ms:linien_nummer>80.733, 80.735</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750438.210000 1263096.614000</gml:lowerCorner>
        		<gml:upperCorner>2750438.210000 1263096.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.798.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750438.210000 1263096.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>798</ms:objectid>
        <ms:id_didok>8502533</ms:id_didok>
        <ms:name>Steinach, Bifang</ms:name>
        <ms:linien_nummer>80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721806.603000 1270057.778000</gml:lowerCorner>
        		<gml:upperCorner>2721806.603000 1270057.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.575.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721806.603000 1270057.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>575</ms:objectid>
        <ms:id_didok>8573371</ms:id_didok>
        <ms:name>Amlikon, Unterdorf</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710913.646000 1257047.811000</gml:lowerCorner>
        		<gml:upperCorner>2710913.646000 1257047.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.608.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710913.646000 1257047.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>608</ms:objectid>
        <ms:id_didok>8573526</ms:id_didok>
        <ms:name>Bichelsee, Niederhofen-Höfli</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732605.726000 1271718.404000</gml:lowerCorner>
        		<gml:upperCorner>2732605.726000 1271718.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.245.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732605.726000 1271718.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>245</ms:objectid>
        <ms:id_didok>8582175</ms:id_didok>
        <ms:name>Birwinken, Käserei</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715142.165000 1276821.582000</gml:lowerCorner>
        		<gml:upperCorner>2715142.165000 1276821.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.564.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715142.165000 1276821.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>564</ms:objectid>
        <ms:id_didok>8583557</ms:id_didok>
        <ms:name>Hörhausen, Käsereistrasse</ms:name>
        <ms:linien_nummer>80.831</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.15">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733138.386000 1274471.797000</gml:lowerCorner>
        		<gml:upperCorner>2733138.386000 1274471.797000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.15.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733138.386000 1274471.797000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>15</ms:objectid>
        <ms:id_didok>8582173</ms:id_didok>
        <ms:name>Illighausen, Wilen</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720858.809000 1252428.960000</gml:lowerCorner>
        		<gml:upperCorner>2720858.809000 1252428.960000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.553.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720858.809000 1252428.960000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>553</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Kirchberg SG, Post</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720465.874000 1251583.912000</gml:lowerCorner>
        		<gml:upperCorner>2720465.874000 1251583.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.554.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720465.874000 1251583.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>554</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Kirchberg SG, Salen</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732281.515000 1268531.447000</gml:lowerCorner>
        		<gml:upperCorner>2732281.515000 1268531.447000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.246.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732281.515000 1268531.447000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>246</ms:objectid>
        <ms:id_didok>8582179</ms:id_didok>
        <ms:name>Donzhausen, Dorfplatz</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719973.544000 1251387.839000</gml:lowerCorner>
        		<gml:upperCorner>2719973.544000 1251387.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.556.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719973.544000 1251387.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>556</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Kirchberg SG, Tüfrüti</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721343.110000 1253047.313000</gml:lowerCorner>
        		<gml:upperCorner>2721343.110000 1253047.313000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.558.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721343.110000 1253047.313000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>558</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Wolfikon SG, Freihof</ms:name>
        <ms:linien_nummer></ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720613.541000 1251958.888000</gml:lowerCorner>
        		<gml:upperCorner>2720613.541000 1251958.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.555.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720613.541000 1251958.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>555</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Kirchberg SG, Strick</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725796.291000 1261986.765000</gml:lowerCorner>
        		<gml:upperCorner>2725796.291000 1261986.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.481.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725796.291000 1261986.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>481</ms:objectid>
        <ms:id_didok>8595252</ms:id_didok>
        <ms:name>Wuppenau, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720058.010000 1257763.789000</gml:lowerCorner>
        		<gml:upperCorner>2720058.010000 1257763.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.835.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720058.010000 1257763.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>835</ms:objectid>
        <ms:id_didok>8578795</ms:id_didok>
        <ms:name>Wil SG, STIHL</ms:name>
        <ms:linien_nummer>80.733, 80.735</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721615.303000 1256198.253000</gml:lowerCorner>
        		<gml:upperCorner>2721615.303000 1256198.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.452.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721615.303000 1256198.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>452</ms:objectid>
        <ms:id_didok>8588425</ms:id_didok>
        <ms:name>Rickenbach bei Wil, Breite</ms:name>
        <ms:linien_nummer>80.731, 80.732</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2733528.763000 1272244.464000</gml:lowerCorner>
        		<gml:upperCorner>2733528.763000 1272244.464000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.259.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2733528.763000 1272244.464000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>259</ms:objectid>
        <ms:id_didok>8582174</ms:id_didok>
        <ms:name>Klarsreuti, Linde</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730837.018000 1279032.354000</gml:lowerCorner>
        		<gml:upperCorner>2730837.018000 1279032.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.568.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730837.018000 1279032.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>568</ms:objectid>
        <ms:id_didok>8594905</ms:id_didok>
        <ms:name>Kreuzlingen, Kantonsschule</ms:name>
        <ms:linien_nummer>80.921, 80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731098.378000 1277574.544000</gml:lowerCorner>
        		<gml:upperCorner>2731098.378000 1277574.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.260.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731098.378000 1277574.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>260</ms:objectid>
        <ms:id_didok>8581682</ms:id_didok>
        <ms:name>Kreuzlingen, Möösliweg</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732425.315000 1278040.849000</gml:lowerCorner>
        		<gml:upperCorner>2732425.315000 1278040.849000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.549.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732425.315000 1278040.849000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>549</ms:objectid>
        <ms:id_didok>8573409</ms:id_didok>
        <ms:name>Kreuzlingen, Zihlstrasse</ms:name>
        <ms:linien_nummer>80.908, 80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731577.303000 1269125.489000</gml:lowerCorner>
        		<gml:upperCorner>2731577.303000 1269125.489000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.542.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731577.303000 1269125.489000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>542</ms:objectid>
        <ms:id_didok>8506612</ms:id_didok>
        <ms:name>Leimbach TG, Kreuzung</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732878.189000 1275492.357000</gml:lowerCorner>
        		<gml:upperCorner>2732878.189000 1275492.357000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.515.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732878.189000 1275492.357000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>515</ms:objectid>
        <ms:id_didok>8581704</ms:id_didok>
        <ms:name>Lengwil, Ekkharthof</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.74">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732991.840000 1271160.736000</gml:lowerCorner>
        		<gml:upperCorner>2732991.840000 1271160.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.74.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732991.840000 1271160.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>74</ms:objectid>
        <ms:id_didok>8573422</ms:id_didok>
        <ms:name>Mattwil, Ochsen</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706961.149000 1254711.806000</gml:lowerCorner>
        		<gml:upperCorner>2706961.149000 1254711.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.312.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706961.149000 1254711.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>312</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Turbenthal, Kehlhof</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720591.092000 1257427.753000</gml:lowerCorner>
        		<gml:upperCorner>2720591.092000 1257427.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.466.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720591.092000 1257427.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>466</ms:objectid>
        <ms:id_didok>8578824</ms:id_didok>
        <ms:name>Wil SG, Wilenstrasse</ms:name>
        <ms:linien_nummer>80.702</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2693586.490000 1272836.459000</gml:lowerCorner>
        		<gml:upperCorner>2693586.490000 1272836.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.601.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2693586.490000 1272836.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>601</ms:objectid>
        <ms:id_didok>8573197</ms:id_didok>
        <ms:name>Kleinandelfingen, Dorf</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747537.725000 1259496.997000</gml:lowerCorner>
        		<gml:upperCorner>2747537.725000 1259496.997000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.589.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747537.725000 1259496.997000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>589</ms:objectid>
        <ms:id_didok>8574243</ms:id_didok>
        <ms:name>Wittenbach, Gommenschwil</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746216.514000 1254654.091000</gml:lowerCorner>
        		<gml:upperCorner>2746216.514000 1254654.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.497.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746216.514000 1254654.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>497</ms:objectid>
        <ms:id_didok>8574471</ms:id_didok>
        <ms:name>St. Gallen, Marktplatz Bohl</ms:name>
        <ms:linien_nummer>80.200, 80.201, 80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747891.401000 1255439.017000</gml:lowerCorner>
        		<gml:upperCorner>2747891.401000 1255439.017000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.496.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747891.401000 1255439.017000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>496</ms:objectid>
        <ms:id_didok>8589594</ms:id_didok>
        <ms:name>St. Gallen, Krontal</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748662.758000 1256183.433000</gml:lowerCorner>
        		<gml:upperCorner>2748662.758000 1256183.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.493.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748662.758000 1256183.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>493</ms:objectid>
        <ms:id_didok>8589563</ms:id_didok>
        <ms:name>St. Gallen, Naturmuseum</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749419.302000 1257328.962000</gml:lowerCorner>
        		<gml:upperCorner>2749419.302000 1257328.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.498.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749419.302000 1257328.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>498</ms:objectid>
        <ms:id_didok>8580687</ms:id_didok>
        <ms:name>St. Gallen, Obere Waid</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749252.650000 1256970.828000</gml:lowerCorner>
        		<gml:upperCorner>2749252.650000 1256970.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.499.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749252.650000 1256970.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>499</ms:objectid>
        <ms:id_didok>8589610</ms:id_didok>
        <ms:name>St. Gallen, Riederenholz</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721258.938000 1258075.599000</gml:lowerCorner>
        		<gml:upperCorner>2721258.938000 1258075.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.464.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721258.938000 1258075.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>464</ms:objectid>
        <ms:id_didok>8573925</ms:id_didok>
        <ms:name>Wil SG, Rössli</ms:name>
        <ms:linien_nummer>80.729 (Regiobus), 80.730 (PostAuto), 80.731 (Regiobus)</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729226.688000 1269650.317000</gml:lowerCorner>
        		<gml:upperCorner>2729226.688000 1269650.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.543.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729226.688000 1269650.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>543</ms:objectid>
        <ms:id_didok>8506571</ms:id_didok>
        <ms:name>Mauren TG, Dorfstrasse</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745047.463000 1266150.888000</gml:lowerCorner>
        		<gml:upperCorner>2745047.463000 1266150.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.547.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745047.463000 1266150.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>547</ms:objectid>
        <ms:id_didok>8587186</ms:id_didok>
        <ms:name>Neukirch (Egnach), Haldenring</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737833.564000 1268588.265000</gml:lowerCorner>
        		<gml:upperCorner>2737833.564000 1268588.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.567.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737833.564000 1268588.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>567</ms:objectid>
        <ms:id_didok>8583839</ms:id_didok>
        <ms:name>Oberaach, Bahnhof</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2732024.068000 1275715.965000</gml:lowerCorner>
        		<gml:upperCorner>2732024.068000 1275715.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.400.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2732024.068000 1275715.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>400</ms:objectid>
        <ms:id_didok>8581702</ms:id_didok>
        <ms:name>Oberhofen TG, Dorf</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747420.881000 1262808.333000</gml:lowerCorner>
        		<gml:upperCorner>2747420.881000 1262808.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.593.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747420.881000 1262808.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>593</ms:objectid>
        <ms:id_didok>8574244</ms:id_didok>
        <ms:name>Roggwil TG, Ochsen</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2742796.989000 1269039.128000</gml:lowerCorner>
        		<gml:upperCorner>2742796.989000 1269039.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.550.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2742796.989000 1269039.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>550</ms:objectid>
        <ms:id_didok>8587203</ms:id_didok>
        <ms:name>Romanshorn, Oberhüseren</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725182.439000 1264647.688000</gml:lowerCorner>
        		<gml:upperCorner>2725182.439000 1264647.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.488.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725182.439000 1264647.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>488</ms:objectid>
        <ms:id_didok>8582809</ms:id_didok>
        <ms:name>Schönholzerswilen, Häusern</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730080.659000 1278340.423000</gml:lowerCorner>
        		<gml:upperCorner>2730080.659000 1278340.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.546.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730080.659000 1278340.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>546</ms:objectid>
        <ms:id_didok>8573390</ms:id_didok>
        <ms:name>Kreuzlingen, Bergstr</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716449.652000 1258198.402000</gml:lowerCorner>
        		<gml:upperCorner>2716449.652000 1258198.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.841.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716449.652000 1258198.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>841</ms:objectid>
        <ms:id_didok>8578619</ms:id_didok>
        <ms:name>Sirnach, Rosenberg</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2740547.088000 1261408.473000</gml:lowerCorner>
        		<gml:upperCorner>2740547.088000 1261408.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.561.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2740547.088000 1261408.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>561</ms:objectid>
        <ms:id_didok>8557103</ms:id_didok>
        <ms:name>St. Pelagiberg, Landhaus</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741545.240000 1262357.686000</gml:lowerCorner>
        		<gml:upperCorner>2741545.240000 1262357.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.562.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741545.240000 1262357.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>562</ms:objectid>
        <ms:id_didok>8557104</ms:id_didok>
        <ms:name>St. Pelagiberg, Rothen</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750498.404000 1262115.558000</gml:lowerCorner>
        		<gml:upperCorner>2750498.404000 1262115.558000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.599.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750498.404000 1262115.558000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>599</ms:objectid>
        <ms:id_didok>8580868</ms:id_didok>
        <ms:name>Steinach, Obersteinach Käserei</ms:name>
        <ms:linien_nummer>80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708623.908000 1254706.501000</gml:lowerCorner>
        		<gml:upperCorner>2708623.908000 1254706.501000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.607.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708623.908000 1254706.501000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>607</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Turbenthal, Oberhofen</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710133.029000 1257114.391000</gml:lowerCorner>
        		<gml:upperCorner>2710133.029000 1257114.391000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.609.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710133.029000 1257114.391000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>609</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Turbenthal,Strandbad Bichelsee</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724546.511000 1269860.134000</gml:lowerCorner>
        		<gml:upperCorner>2724546.511000 1269860.134000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.115.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724546.511000 1269860.134000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>115</ms:objectid>
        <ms:id_didok>8502599</ms:id_didok>
        <ms:name>Weinfelden, Dunantstrasse</ms:name>
        <ms:linien_nummer>80.722, 80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723906.985000 1266136.850000</gml:lowerCorner>
        		<gml:upperCorner>2723906.985000 1266136.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.525.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723906.985000 1266136.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>525</ms:objectid>
        <ms:id_didok>8506741</ms:id_didok>
        <ms:name>Weingarten b. Märwil, Dorf</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2744205.349000 1261966.803000</gml:lowerCorner>
        		<gml:upperCorner>2744205.349000 1261966.803000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.594.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2744205.349000 1261966.803000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>594</ms:objectid>
        <ms:id_didok>8574219</ms:id_didok>
        <ms:name>Lömmenschwil, Schöntal</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714149.697000 1257732.396000</gml:lowerCorner>
        		<gml:upperCorner>2714149.697000 1257732.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.837.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714149.697000 1257732.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>837</ms:objectid>
        <ms:id_didok>8587412</ms:id_didok>
        <ms:name>Wallenwil, Schlangenzoo</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714604.853000 1257797.184000</gml:lowerCorner>
        		<gml:upperCorner>2714604.853000 1257797.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.838.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714604.853000 1257797.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>838</ms:objectid>
        <ms:id_didok>8588978</ms:id_didok>
        <ms:name>Eschlikon TG, Bahnhof Süd</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715058.722000 1257807.481000</gml:lowerCorner>
        		<gml:upperCorner>2715058.722000 1257807.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.839.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715058.722000 1257807.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>839</ms:objectid>
        <ms:id_didok>8507542</ms:id_didok>
        <ms:name>Eschlikon TG, Industrie</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717153.793000 1258175.079000</gml:lowerCorner>
        		<gml:upperCorner>2717153.793000 1258175.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.842.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717153.793000 1258175.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>842</ms:objectid>
        <ms:id_didok>8588625</ms:id_didok>
        <ms:name>Sirnach, Kett</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746334.323000 1267727.655000</gml:lowerCorner>
        		<gml:upperCorner>2746334.323000 1267727.655000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.659.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746334.323000 1267727.655000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>659</ms:objectid>
        <ms:id_didok>8587158</ms:id_didok>
        <ms:name>Egnach, Bahnhof</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746114.416000 1267447.299000</gml:lowerCorner>
        		<gml:upperCorner>2746114.416000 1267447.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.660.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746114.416000 1267447.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>660</ms:objectid>
        <ms:id_didok>8587161</ms:id_didok>
        <ms:name>Egnach, Kreisel</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722598.255000 1281127.641000</gml:lowerCorner>
        		<gml:upperCorner>2722598.255000 1281127.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.640.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722598.255000 1281127.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>640</ms:objectid>
        <ms:id_didok>8581969</ms:id_didok>
        <ms:name>Ermatingen, Friedhof</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720164.552000 1269075.613000</gml:lowerCorner>
        		<gml:upperCorner>2720164.552000 1269075.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.584.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720164.552000 1269075.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>584</ms:objectid>
        <ms:id_didok>8506864</ms:id_didok>
        <ms:name>Fimmelsberg, Kreuz</ms:name>
        <ms:linien_nummer>80.383</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715198.094000 1253719.956000</gml:lowerCorner>
        		<gml:upperCorner>2715198.094000 1253719.956000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.622.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715198.094000 1253719.956000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>622</ms:objectid>
        <ms:id_didok>8578608</ms:id_didok>
        <ms:name>Fischingen, Scheidweg</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710613.072000 1269125.580000</gml:lowerCorner>
        		<gml:upperCorner>2710613.072000 1269125.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.636.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710613.072000 1269125.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>636</ms:objectid>
        <ms:id_didok>8573301</ms:id_didok>
        <ms:name>Frauenfeld, Thurgipark</ms:name>
        <ms:linien_nummer>80.826, 80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2711200.967000 1269666.976000</gml:lowerCorner>
        		<gml:upperCorner>2711200.967000 1269666.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.637.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2711200.967000 1269666.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>637</ms:objectid>
        <ms:id_didok>8573302</ms:id_didok>
        <ms:name>Frauenfeld, Wellauer</ms:name>
        <ms:linien_nummer>80.826, 80.829</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722328.044000 1280262.485000</gml:lowerCorner>
        		<gml:upperCorner>2722328.044000 1280262.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.638.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722328.044000 1280262.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>638</ms:objectid>
        <ms:id_didok>8506985</ms:id_didok>
        <ms:name>Fruthwilen, Schreinerei</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2691259.678000 1278735.610000</gml:lowerCorner>
        		<gml:upperCorner>2691259.678000 1278735.610000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.645.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2691259.678000 1278735.610000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>645</ms:objectid>
        <ms:id_didok>8503952</ms:id_didok>
        <ms:name>Benken ZH, Dorf</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722406.816000 1276194.934000</gml:lowerCorner>
        		<gml:upperCorner>2722406.816000 1276194.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.673.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722406.816000 1276194.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>673</ms:objectid>
        <ms:id_didok>85026160</ms:id_didok>
        <ms:name>Hattenhausen, Dorf</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712976.101000 1258175.919000</gml:lowerCorner>
        		<gml:upperCorner>2712976.101000 1258175.919000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.627.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712976.101000 1258175.919000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>627</ms:objectid>
        <ms:id_didok>8578624</ms:id_didok>
        <ms:name>Ifwil b. B., Ausserdorf</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714000.439000 1276082.286000</gml:lowerCorner>
        		<gml:upperCorner>2714000.439000 1276082.286000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.633.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714000.439000 1276082.286000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>633</ms:objectid>
        <ms:id_didok>8506592</ms:id_didok>
        <ms:name>Lanzenneunforn, Schweikhof</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2731683.589000 1276446.063000</gml:lowerCorner>
        		<gml:upperCorner>2731683.589000 1276446.063000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.695.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2731683.589000 1276446.063000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>695</ms:objectid>
        <ms:id_didok>8581683</ms:id_didok>
        <ms:name>Lengwil, Bahnhof</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722192.251000 1275849.080000</gml:lowerCorner>
        		<gml:upperCorner>2722192.251000 1275849.080000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.696.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722192.251000 1275849.080000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>696</ms:objectid>
        <ms:id_didok>8504116</ms:id_didok>
        <ms:name>Hattenhausen, Golfpanorama</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718528.425000 1255879.930000</gml:lowerCorner>
        		<gml:upperCorner>2718528.425000 1255879.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.619.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718528.425000 1255879.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>619</ms:objectid>
        <ms:id_didok>8578790</ms:id_didok>
        <ms:name>Littenheid, Sonnenmatt</ms:name>
        <ms:linien_nummer>80.733</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748463.799000 1263613.086000</gml:lowerCorner>
        		<gml:upperCorner>2748463.799000 1263613.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.591.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748463.799000 1263613.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>591</ms:objectid>
        <ms:id_didok>8506256</ms:id_didok>
        <ms:name>Stachen, Museum Momö</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715233.059000 1258103.365000</gml:lowerCorner>
        		<gml:upperCorner>2715233.059000 1258103.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.840.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715233.059000 1258103.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>840</ms:objectid>
        <ms:id_didok>8578621</ms:id_didok>
        <ms:name>Eschlikon TG, Mitteldorf</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713459.436000 1271259.804000</gml:lowerCorner>
        		<gml:upperCorner>2713459.436000 1271259.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.867.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713459.436000 1271259.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>867</ms:objectid>
        <ms:id_didok>8505531</ms:id_didok>
        <ms:name>Felben, Ost</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721519.756000 1256753.837000</gml:lowerCorner>
        		<gml:upperCorner>2721519.756000 1256753.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.868.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721519.756000 1256753.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>868</ms:objectid>
        <ms:id_didok>8578522</ms:id_didok>
        <ms:name>Rickenbach bei Wil, Mühle</ms:name>
        <ms:linien_nummer>80.731</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>REGO</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722109.623000 1259055.556000</gml:lowerCorner>
        		<gml:upperCorner>2722109.623000 1259055.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.610.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722109.623000 1259055.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>610</ms:objectid>
        <ms:id_didok>8587757</ms:id_didok>
        <ms:name>Wil SG, Breitenloo</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2699920.937000 1280316.467000</gml:lowerCorner>
        		<gml:upperCorner>2699920.937000 1280316.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.743.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2699920.937000 1280316.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>743</ms:objectid>
        <ms:id_didok>8573332</ms:id_didok>
        <ms:name>Schlattingen, Hauptstrasse</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736747.086000 1270605.605000</gml:lowerCorner>
        		<gml:upperCorner>2736747.086000 1270605.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.674.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736747.086000 1270605.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>674</ms:objectid>
        <ms:id_didok>8502617</ms:id_didok>
        <ms:name>Kümmertshausen, Oberlöwenhaus</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710330.545000 1267694.108000</gml:lowerCorner>
        		<gml:upperCorner>2710330.545000 1267694.108000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.722.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710330.545000 1267694.108000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>722</ms:objectid>
        <ms:id_didok>8573364</ms:id_didok>
        <ms:name>Frauenfeld, Rosenbergstrasse</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738706.383000 1274272.263000</gml:lowerCorner>
        		<gml:upperCorner>2738706.383000 1274272.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.712.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738706.383000 1274272.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>712</ms:objectid>
        <ms:id_didok>8502629</ms:id_didok>
        <ms:name>Güttingen, Schulhaus</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2699836.851000 1273717.626000</gml:lowerCorner>
        		<gml:upperCorner>2699836.851000 1273717.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.602.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2699836.851000 1273717.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>602</ms:objectid>
        <ms:id_didok>8573201</ms:id_didok>
        <ms:name>Oberneunforn, Dorf</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.16">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2698099.099000 1274120.484000</gml:lowerCorner>
        		<gml:upperCorner>2698099.099000 1274120.484000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.16.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2698099.099000 1274120.484000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>16</ms:objectid>
        <ms:id_didok>8580296</ms:id_didok>
        <ms:name>Oberneunforn, Langmüli</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720934.970000 1257425.061000</gml:lowerCorner>
        		<gml:upperCorner>2720934.970000 1257425.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.692.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720934.970000 1257425.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>692</ms:objectid>
        <ms:id_didok>8507440</ms:id_didok>
        <ms:name>Wil SG, Allmend</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2696666.531000 1274549.519000</gml:lowerCorner>
        		<gml:upperCorner>2696666.531000 1274549.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.604.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2696666.531000 1274549.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>604</ms:objectid>
        <ms:id_didok>8573199</ms:id_didok>
        <ms:name>Ossingen, Bahnhof</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727632.908000 1255269.054000</gml:lowerCorner>
        		<gml:upperCorner>2727632.908000 1255269.054000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.615.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727632.908000 1255269.054000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>615</ms:objectid>
        <ms:id_didok>8573929</ms:id_didok>
        <ms:name>Uzwil, Bahnhof</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729331.177000 1256361.806000</gml:lowerCorner>
        		<gml:upperCorner>2729331.177000 1256361.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.616.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729331.177000 1256361.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>616</ms:objectid>
        <ms:id_didok>8506577</ms:id_didok>
        <ms:name>Oberbüren, Buchental</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729676.886000 1256822.917000</gml:lowerCorner>
        		<gml:upperCorner>2729676.886000 1256822.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.617.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729676.886000 1256822.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>617</ms:objectid>
        <ms:id_didok>8573932</ms:id_didok>
        <ms:name>Oberbüren, Glattfeld</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750473.495000 1258714.221000</gml:lowerCorner>
        		<gml:upperCorner>2750473.495000 1258714.221000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.598.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750473.495000 1258714.221000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>598</ms:objectid>
        <ms:id_didok>8581393</ms:id_didok>
        <ms:name>Mörschwil, Fahrn</ms:name>
        <ms:linien_nummer>80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739065.217000 1274205.594000</gml:lowerCorner>
        		<gml:upperCorner>2739065.217000 1274205.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.713.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739065.217000 1274205.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>713</ms:objectid>
        <ms:id_didok>8581678</ms:id_didok>
        <ms:name>Güttingen, Zentrum</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722126.890000 1275317.711000</gml:lowerCorner>
        		<gml:upperCorner>2722126.890000 1275317.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.671.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722126.890000 1275317.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>671</ms:objectid>
        <ms:id_didok>8506564</ms:id_didok>
        <ms:name>Hefenhausen, Illharterstrasse</ms:name>
        <ms:linien_nummer>80.832, 80.833, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715352.445000 1252311.991000</gml:lowerCorner>
        		<gml:upperCorner>2715352.445000 1252311.991000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.624.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715352.445000 1252311.991000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>624</ms:objectid>
        <ms:id_didok>8578595</ms:id_didok>
        <ms:name>Fischingen, Kloster</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745891.202000 1267141.955000</gml:lowerCorner>
        		<gml:upperCorner>2745891.202000 1267141.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.548.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745891.202000 1267141.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>548</ms:objectid>
        <ms:id_didok>8589066</ms:id_didok>
        <ms:name>Neukirch-Egnach, Bahnhof</ms:name>
        <ms:linien_nummer>80.940, 80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2700130.699000 1273865.308000</gml:lowerCorner>
        		<gml:upperCorner>2700130.699000 1273865.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.563.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2700130.699000 1273865.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>563</ms:objectid>
        <ms:id_didok>8557098</ms:id_didok>
        <ms:name>Oberneunforn, Stocke</ms:name>
        <ms:linien_nummer>70.605</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720652.858000 1277323.202000</gml:lowerCorner>
        		<gml:upperCorner>2720652.858000 1277323.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.639.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720652.858000 1277323.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>639</ms:objectid>
        <ms:id_didok>8580251</ms:id_didok>
        <ms:name>Raperswilen, Schulhaus</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721686.134000 1281064.620000</gml:lowerCorner>
        		<gml:upperCorner>2721686.134000 1281064.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.641.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721686.134000 1281064.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>641</ms:objectid>
        <ms:id_didok>8581945</ms:id_didok>
        <ms:name>Salenstein, Dorf</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745683.509000 1268819.134000</gml:lowerCorner>
        		<gml:upperCorner>2745683.509000 1268819.134000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.658.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745683.509000 1268819.134000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>658</ms:objectid>
        <ms:id_didok>8587207</ms:id_didok>
        <ms:name>Salmsach, Birkenweg</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745692.463000 1268609.281000</gml:lowerCorner>
        		<gml:upperCorner>2745692.463000 1268609.281000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.664.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745692.463000 1268609.281000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>664</ms:objectid>
        <ms:id_didok>8587208</ms:id_didok>
        <ms:name>Salmsach, Bodana</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745476.437000 1268908.869000</gml:lowerCorner>
        		<gml:upperCorner>2745476.437000 1268908.869000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.665.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745476.437000 1268908.869000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>665</ms:objectid>
        <ms:id_didok>8587137</ms:id_didok>
        <ms:name>Salmsach, Seestrasse</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2693783.410000 1281719.466000</gml:lowerCorner>
        		<gml:upperCorner>2693783.410000 1281719.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.647.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2693783.410000 1281719.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>647</ms:objectid>
        <ms:id_didok>8573491</ms:id_didok>
        <ms:name>Schlatt TG, Bahnhof</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708781.097000 1270768.456000</gml:lowerCorner>
        		<gml:upperCorner>2708781.097000 1270768.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.732.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708781.097000 1270768.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>732</ms:objectid>
        <ms:id_didok>8580240</ms:id_didok>
        <ms:name>Frauenfeld, Rorerbrücke</ms:name>
        <ms:linien_nummer>80.823, 80.825</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2694963.418000 1279999.708000</gml:lowerCorner>
        		<gml:upperCorner>2694963.418000 1279999.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.711.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2694963.418000 1279999.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>711</ms:objectid>
        <ms:id_didok>8579838</ms:id_didok>
        <ms:name>Schlatt TG, Turnhallenstrasse</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717752.891000 1257984.379000</gml:lowerCorner>
        		<gml:upperCorner>2717752.891000 1257984.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.715.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717752.891000 1257984.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>715</ms:objectid>
        <ms:id_didok>8578601</ms:id_didok>
        <ms:name>Sirnach, Bahnhof</ms:name>
        <ms:linien_nummer>80.734, 80.735, 80.739</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715617.002000 1279056.162000</gml:lowerCorner>
        		<gml:upperCorner>2715617.002000 1279056.162000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.635.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715617.002000 1279056.162000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>635</ms:objectid>
        <ms:id_didok>8506863</ms:id_didok>
        <ms:name>Steckborn, Eichhölzli</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748035.698000 1265302.496000</gml:lowerCorner>
        		<gml:upperCorner>2748035.698000 1265302.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.657.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748035.698000 1265302.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>657</ms:objectid>
        <ms:id_didok>8587221</ms:id_didok>
        <ms:name>Steineloh, Sternen</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713998.642000 1265194.748000</gml:lowerCorner>
        		<gml:upperCorner>2713998.642000 1265194.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.643.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713998.642000 1265194.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>643</ms:objectid>
        <ms:id_didok>8581617</ms:id_didok>
        <ms:name>Stettfurt, Vorstadt</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727794.046000 1279554.890000</gml:lowerCorner>
        		<gml:upperCorner>2727794.046000 1279554.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.650.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727794.046000 1279554.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>650</ms:objectid>
        <ms:id_didok>8582498</ms:id_didok>
        <ms:name>Tägerwilen Dorf, Bahnhof</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725806.628000 1269741.687000</gml:lowerCorner>
        		<gml:upperCorner>2725806.628000 1269741.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.697.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725806.628000 1269741.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>697</ms:objectid>
        <ms:id_didok>8580250</ms:id_didok>
        <ms:name>Weinfelden, Felsenstrasse</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725446.075000 1268840.319000</gml:lowerCorner>
        		<gml:upperCorner>2725446.075000 1268840.319000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.652.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725446.075000 1268840.319000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>652</ms:objectid>
        <ms:id_didok>8573612</ms:id_didok>
        <ms:name>Weinfelden, Thurland</ms:name>
        <ms:linien_nummer>80.722, 80.932</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708573.511000 1271692.495000</gml:lowerCorner>
        		<gml:upperCorner>2708573.511000 1271692.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.527.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708573.511000 1271692.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>527</ms:objectid>
        <ms:id_didok>8573325</ms:id_didok>
        <ms:name>Weiningen TG, Mehrzweckhalle</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708931.498000 1271977.525000</gml:lowerCorner>
        		<gml:upperCorner>2708931.498000 1271977.525000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.734.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708931.498000 1271977.525000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>734</ms:objectid>
        <ms:id_didok>8506967</ms:id_didok>
        <ms:name>Weiningen TG, Dorfplatz</ms:name>
        <ms:linien_nummer>80.823, 80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709323.357000 1268799.545000</gml:lowerCorner>
        		<gml:upperCorner>2709323.357000 1268799.545000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.728.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709323.357000 1268799.545000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>728</ms:objectid>
        <ms:id_didok>8506901</ms:id_didok>
        <ms:name>Frauenfeld, Schaffhauserplatz</ms:name>
        <ms:linien_nummer>80.822, 80.825</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707766.950000 1274155.635000</gml:lowerCorner>
        		<gml:upperCorner>2707766.950000 1274155.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.738.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707766.950000 1274155.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>738</ms:objectid>
        <ms:id_didok>8581946</ms:id_didok>
        <ms:name>Hüttwilen, Oberdorf</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706427.804000 1274553.766000</gml:lowerCorner>
        		<gml:upperCorner>2706427.804000 1274553.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.739.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706427.804000 1274553.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>739</ms:objectid>
        <ms:id_didok>8506963</ms:id_didok>
        <ms:name>Hüttwilen, Stutheien</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2704757.215000 1275375.319000</gml:lowerCorner>
        		<gml:upperCorner>2704757.215000 1275375.319000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.740.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2704757.215000 1275375.319000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>740</ms:objectid>
        <ms:id_didok>8580247</ms:id_didok>
        <ms:name>Nussbaumen TG, Tobelbrunnen</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709022.041000 1269347.063000</gml:lowerCorner>
        		<gml:upperCorner>2709022.041000 1269347.063000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.730.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709022.041000 1269347.063000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>730</ms:objectid>
        <ms:id_didok>8573322</ms:id_didok>
        <ms:name>Frauenfeld, Sportplatz</ms:name>
        <ms:linien_nummer>80.823, 80.825</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2702946.884000 1272023.079000</gml:lowerCorner>
        		<gml:upperCorner>2702946.884000 1272023.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.751.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2702946.884000 1272023.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>751</ms:objectid>
        <ms:id_didok>8506858</ms:id_didok>
        <ms:name>Dietingen, Abzweigung
</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708761.761000 1269841.246000</gml:lowerCorner>
        		<gml:upperCorner>2708761.761000 1269841.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.731.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708761.761000 1269841.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>731</ms:objectid>
        <ms:id_didok>8506900</ms:id_didok>
        <ms:name>Frauenfeld, Auenfeld</ms:name>
        <ms:linien_nummer>80.823, 80.825</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739583.530000 1267692.573000</gml:lowerCorner>
        		<gml:upperCorner>2739583.530000 1267692.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.761.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739583.530000 1267692.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>761</ms:objectid>
        <ms:id_didok>8587140</ms:id_didok>
        <ms:name>Amriswil, Quellenhof
</ms:name>
        <ms:linien_nummer>80.931, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738178.206000 1267902.765000</gml:lowerCorner>
        		<gml:upperCorner>2738178.206000 1267902.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.765.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738178.206000 1267902.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>765</ms:objectid>
        <ms:id_didok>8583792</ms:id_didok>
        <ms:name>Amriswil, Schrofen
</ms:name>
        <ms:linien_nummer>80.931, 80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717606.194000 1258731.725000</gml:lowerCorner>
        		<gml:upperCorner>2717606.194000 1258731.725000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.844.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717606.194000 1258731.725000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>844</ms:objectid>
        <ms:id_didok>8508124</ms:id_didok>
        <ms:name>Sirnach, Sonnenberg</ms:name>
        <ms:linien_nummer>80.739</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2694943.355000 1279684.731000</gml:lowerCorner>
        		<gml:upperCorner>2694943.355000 1279684.731000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.649.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2694943.355000 1279684.731000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>649</ms:objectid>
        <ms:id_didok>8573488</ms:id_didok>
        <ms:name>Schlatt TG, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2698517.561000 1281049.615000</gml:lowerCorner>
        		<gml:upperCorner>2698517.561000 1281049.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.745.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2698517.561000 1281049.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>745</ms:objectid>
        <ms:id_didok>8573333</ms:id_didok>
        <ms:name>Basadingen, Grüt</ms:name>
        <ms:linien_nummer>80.823, 80.847</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709873.756000 1268778.809000</gml:lowerCorner>
        		<gml:upperCorner>2709873.756000 1268778.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.727.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709873.756000 1268778.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>727</ms:objectid>
        <ms:id_didok>8573312</ms:id_didok>
        <ms:name>Frauenfeld, Jugendmusikschule</ms:name>
        <ms:linien_nummer>80.822, 80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709173.887000 1272751.196000</gml:lowerCorner>
        		<gml:upperCorner>2709173.887000 1272751.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.735.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709173.887000 1272751.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>735</ms:objectid>
        <ms:id_didok>8506966</ms:id_didok>
        <ms:name>Weiningen TG, Weckingen</ms:name>
        <ms:linien_nummer>80.823, 80.825</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726345.689000 1261938.834000</gml:lowerCorner>
        		<gml:upperCorner>2726345.689000 1261938.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.710.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726345.689000 1261938.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>710</ms:objectid>
        <ms:id_didok>8587762</ms:id_didok>
        <ms:name>Wuppenau, Abzw. Welfensberg</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722179.042000 1272008.692000</gml:lowerCorner>
        		<gml:upperCorner>2722179.042000 1272008.692000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.651.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722179.042000 1272008.692000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>651</ms:objectid>
        <ms:id_didok>8573385</ms:id_didok>
        <ms:name>Märstetten, Obstgarten</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709696.781000 1268432.737000</gml:lowerCorner>
        		<gml:upperCorner>2709696.781000 1268432.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.726.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709696.781000 1268432.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>726</ms:objectid>
        <ms:id_didok>8573375</ms:id_didok>
        <ms:name>Frauenfeld, Bahnhof</ms:name>
        <ms:linien_nummer>80.819, 80.822, 80.823, 80.825, 80.826, 80.829, 80.834</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738453.752000 1267953.311000</gml:lowerCorner>
        		<gml:upperCorner>2738453.752000 1267953.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.760.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738453.752000 1267953.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>760</ms:objectid>
        <ms:id_didok>8510282</ms:id_didok>
        <ms:name>Amriswil, Strassenverkehrsamt
</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739131.443000 1267602.923000</gml:lowerCorner>
        		<gml:upperCorner>2739131.443000 1267602.923000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.762.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739131.443000 1267602.923000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>762</ms:objectid>
        <ms:id_didok>8587139</ms:id_didok>
        <ms:name>Amriswil, Grenzstrasse
</ms:name>
        <ms:linien_nummer>80.931, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738746.527000 1267641.959000</gml:lowerCorner>
        		<gml:upperCorner>2738746.527000 1267641.959000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.763.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738746.527000 1267641.959000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>763</ms:objectid>
        <ms:id_didok>8587143</ms:id_didok>
        <ms:name>Amriswil, Köpplishaus
</ms:name>
        <ms:linien_nummer>80.931, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738333.949000 1267615.643000</gml:lowerCorner>
        		<gml:upperCorner>2738333.949000 1267615.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.764.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738333.949000 1267615.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>764</ms:objectid>
        <ms:id_didok>8587146</ms:id_didok>
        <ms:name>Amriswil, Mühlebach
</ms:name>
        <ms:linien_nummer>80.931, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709697.627000 1268263.308000</gml:lowerCorner>
        		<gml:upperCorner>2709697.627000 1268263.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.725.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709697.627000 1268263.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>725</ms:objectid>
        <ms:id_didok>8506872</ms:id_didok>
        <ms:name>Frauenfeld, Hauptpost</ms:name>
        <ms:linien_nummer>80.834, 80.836, 80.837, 80.838</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720638.783000 1268415.288000</gml:lowerCorner>
        		<gml:upperCorner>2720638.783000 1268415.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.573.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720638.783000 1268415.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>573</ms:objectid>
        <ms:id_didok>8573370</ms:id_didok>
        <ms:name>Amlikon-Bissegg, Bänikon</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710173.347000 1267953.920000</gml:lowerCorner>
        		<gml:upperCorner>2710173.347000 1267953.920000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.723.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710173.347000 1267953.920000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>723</ms:objectid>
        <ms:id_didok>8573359</ms:id_didok>
        <ms:name>Frauenfeld, Thundorferstrasse</ms:name>
        <ms:linien_nummer>80.834, 80.837, 80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2741448.019000 1270540.599000</gml:lowerCorner>
        		<gml:upperCorner>2741448.019000 1270540.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.756.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2741448.019000 1270540.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>756</ms:objectid>
        <ms:id_didok>8587174</ms:id_didok>
        <ms:name>Hefenhofen, Hamisfeld
</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717280.696000 1259749.455000</gml:lowerCorner>
        		<gml:upperCorner>2717280.696000 1259749.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.681.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717280.696000 1259749.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>681</ms:objectid>
        <ms:id_didok>8503032</ms:id_didok>
        <ms:name>Münchwilen, Oberhofen</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738790.128000 1270604.685000</gml:lowerCorner>
        		<gml:upperCorner>2738790.128000 1270604.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.752.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738790.128000 1270604.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>752</ms:objectid>
        <ms:id_didok>8502535</ms:id_didok>
        <ms:name>Obersommeri, Dorf
</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743977.011000 1269617.515000</gml:lowerCorner>
        		<gml:upperCorner>2743977.011000 1269617.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.661.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743977.011000 1269617.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>661</ms:objectid>
        <ms:id_didok>8587198</ms:id_didok>
        <ms:name>Romanshorn, Gärtliszelg</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745075.629000 1270861.028000</gml:lowerCorner>
        		<gml:upperCorner>2745075.629000 1270861.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.655.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745075.629000 1270861.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>655</ms:objectid>
        <ms:id_didok>8587200</ms:id_didok>
        <ms:name>Romanshorn, Holzenstein</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2744675.157000 1269958.111000</gml:lowerCorner>
        		<gml:upperCorner>2744675.157000 1269958.111000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.662.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2744675.157000 1269958.111000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>662</ms:objectid>
        <ms:id_didok>8587201</ms:id_didok>
        <ms:name>Romanshorn, Holzgasse</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745028.067000 1270601.804000</gml:lowerCorner>
        		<gml:upperCorner>2745028.067000 1270601.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.656.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745028.067000 1270601.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>656</ms:objectid>
        <ms:id_didok>8587206</ms:id_didok>
        <ms:name>Romanshorn, Weitenzelg</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717752.891000 1257984.379000</gml:lowerCorner>
        		<gml:upperCorner>2717752.891000 1257984.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.718.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717752.891000 1257984.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>718</ms:objectid>
        <ms:id_didok>8578601</ms:id_didok>
        <ms:name>Sirnach, Bahnhof</ms:name>
        <ms:linien_nummer>80.734, 80.735, 80.739</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718121.954000 1258196.075000</gml:lowerCorner>
        		<gml:upperCorner>2718121.954000 1258196.075000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.719.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718121.954000 1258196.075000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>719</ms:objectid>
        <ms:id_didok>8578600</ms:id_didok>
        <ms:name>Sirnach, Kläffler</ms:name>
        <ms:linien_nummer>80.734, 80.735</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721289.464000 1256786.097000</gml:lowerCorner>
        		<gml:upperCorner>2721289.464000 1256786.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.748.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721289.464000 1256786.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>748</ms:objectid>
        <ms:id_didok>8507444</ms:id_didok>
        <ms:name>Rickenbach bei Wil, Pünt
</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727798.370000 1255407.293000</gml:lowerCorner>
        		<gml:upperCorner>2727798.370000 1255407.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.618.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727798.370000 1255407.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>618</ms:objectid>
        <ms:id_didok>8573930</ms:id_didok>
        <ms:name>Uzwil, Mühlehof</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2745318.583000 1259990.857000</gml:lowerCorner>
        		<gml:upperCorner>2745318.583000 1259990.857000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.595.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2745318.583000 1259990.857000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>595</ms:objectid>
        <ms:id_didok>8579846</ms:id_didok>
        <ms:name>Wittenbach, Oberlören</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717143.401000 1257671.815000</gml:lowerCorner>
        		<gml:upperCorner>2717143.401000 1257671.815000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.717.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717143.401000 1257671.815000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>717</ms:objectid>
        <ms:id_didok>8506690</ms:id_didok>
        <ms:name>Sirnach, Bad</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713593.310000 1273294.220000</gml:lowerCorner>
        		<gml:upperCorner>2713593.310000 1273294.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.634.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713593.310000 1273294.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>634</ms:objectid>
        <ms:id_didok>8573336</ms:id_didok>
        <ms:name>Pfyn, Frohsinn</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716882.693000 1259533.488000</gml:lowerCorner>
        		<gml:upperCorner>2716882.693000 1259533.488000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.680.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716882.693000 1259533.488000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>680</ms:objectid>
        <ms:id_didok>8502958</ms:id_didok>
        <ms:name>Münchwilen, Eschlikonerstrasse</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719504.619000 1273545.174000</gml:lowerCorner>
        		<gml:upperCorner>2719504.619000 1273545.174000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.685.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719504.619000 1273545.174000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>685</ms:objectid>
        <ms:id_didok>8507944</ms:id_didok>
        <ms:name>Wigoltingen, Fabrikstrasse</ms:name>
        <ms:linien_nummer>80.829</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719655.831000 1273080.694000</gml:lowerCorner>
        		<gml:upperCorner>2719655.831000 1273080.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.686.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719655.831000 1273080.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>686</ms:objectid>
        <ms:id_didok>8507926</ms:id_didok>
        <ms:name>Wigoltingen Schulweg</ms:name>
        <ms:linien_nummer>80.829, 80.832</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737584.342000 1266681.184000</gml:lowerCorner>
        		<gml:upperCorner>2737584.342000 1266681.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.767.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737584.342000 1266681.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>767</ms:objectid>
        <ms:id_didok>8587210</ms:id_didok>
        <ms:name>Schocherswil, alte Post
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737111.358000 1265081.080000</gml:lowerCorner>
        		<gml:upperCorner>2737111.358000 1265081.080000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.768.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737111.358000 1265081.080000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>768</ms:objectid>
        <ms:id_didok>8587223</ms:id_didok>
        <ms:name>Zihlschlacht, Oberdorf
</ms:name>
        <ms:linien_nummer>80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713184.504000 1257048.780000</gml:lowerCorner>
        		<gml:upperCorner>2713184.504000 1257048.780000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.783.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713184.504000 1257048.780000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>783</ms:objectid>
        <ms:id_didok>8587256</ms:id_didok>
        <ms:name>Balterswil, Rietwies
</ms:name>
        <ms:linien_nummer>80.735, 80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712999.109000 1256850.689000</gml:lowerCorner>
        		<gml:upperCorner>2712999.109000 1256850.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.784.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712999.109000 1256850.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>784</ms:objectid>
        <ms:id_didok>8578625</ms:id_didok>
        <ms:name>Balterswil, Dorf
</ms:name>
        <ms:linien_nummer>80.735</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.6">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707285.786000 1278663.292000</gml:lowerCorner>
        		<gml:upperCorner>2707285.786000 1278663.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.6.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707285.786000 1278663.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>6</ms:objectid>
        <ms:id_didok>8506632</ms:id_didok>
        <ms:name>Eschenz, Höfen</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712709.854000 1256670.228000</gml:lowerCorner>
        		<gml:upperCorner>2712709.854000 1256670.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.786.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712709.854000 1256670.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>786</ms:objectid>
        <ms:id_didok>8578626</ms:id_didok>
        <ms:name>Balterswil, Schulhaus</ms:name>
        <ms:linien_nummer>80.735</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.83">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710797.196000 1267298.272000</gml:lowerCorner>
        		<gml:upperCorner>2710797.196000 1267298.272000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.83.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710797.196000 1267298.272000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>83</ms:objectid>
        <ms:id_didok>8506870</ms:id_didok>
        <ms:name>Frauenfeld, Lachenstrasse</ms:name>
        <ms:linien_nummer>80.837, 80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2711887.421000 1256305.888000</gml:lowerCorner>
        		<gml:upperCorner>2711887.421000 1256305.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.788.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2711887.421000 1256305.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>788</ms:objectid>
        <ms:id_didok>8573527</ms:id_didok>
        <ms:name>Bichelsee, Dorf</ms:name>
        <ms:linien_nummer>80.735, 70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717603.821000 1259298.680000</gml:lowerCorner>
        		<gml:upperCorner>2717603.821000 1259298.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.845.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717603.821000 1259298.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>845</ms:objectid>
        <ms:id_didok>8508126</ms:id_didok>
        <ms:name>Münchwilen TG, Sirnacherstr.</ms:name>
        <ms:linien_nummer>80.739</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710961.693000 1267123.850000</gml:lowerCorner>
        		<gml:upperCorner>2710961.693000 1267123.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.389.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710961.693000 1267123.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>389</ms:objectid>
        <ms:id_didok>8583337</ms:id_didok>
        <ms:name>Frauenfeld, Huben</ms:name>
        <ms:linien_nummer>80.837, 80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713052.950000 1256858.211000</gml:lowerCorner>
        		<gml:upperCorner>2713052.950000 1256858.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.785.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713052.950000 1256858.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>785</ms:objectid>
        <ms:id_didok>8578625</ms:id_didok>
        <ms:name>Balterswil, Dorf
</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2711534.789000 1266962.662000</gml:lowerCorner>
        		<gml:upperCorner>2711534.789000 1266962.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.796.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2711534.789000 1266962.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>796</ms:objectid>
        <ms:id_didok>8506856</ms:id_didok>
        <ms:name>Frauenfeld, Bühl
</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719957.178000 1265253.701000</gml:lowerCorner>
        		<gml:upperCorner>2719957.178000 1265253.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.456.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719957.178000 1265253.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>456</ms:objectid>
        <ms:id_didok>8506679</ms:id_didok>
        <ms:name>Affeltrangen, Dorf</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721561.767000 1269805.128000</gml:lowerCorner>
        		<gml:upperCorner>2721561.767000 1269805.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.582.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721561.767000 1269805.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>582</ms:objectid>
        <ms:id_didok>8580601</ms:id_didok>
        <ms:name>Amlikon, Oberdorf</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739943.198000 1267197.323000</gml:lowerCorner>
        		<gml:upperCorner>2739943.198000 1267197.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.138.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739943.198000 1267197.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>138</ms:objectid>
        <ms:id_didok>8587148</ms:id_didok>
        <ms:name>Amriswil, St. Gallerstrasse</ms:name>
        <ms:linien_nummer>80.942</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735478.600000 1261487.223000</gml:lowerCorner>
        		<gml:upperCorner>2735478.600000 1261487.223000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.778.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735478.600000 1261487.223000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>778</ms:objectid>
        <ms:id_didok>8580424</ms:id_didok>
        <ms:name>Bischofszell, Schwimmbad
</ms:name>
        <ms:linien_nummer>80.740</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721104.633000 1269276.703000</gml:lowerCorner>
        		<gml:upperCorner>2721104.633000 1269276.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.576.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721104.633000 1269276.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>576</ms:objectid>
        <ms:id_didok>8583488</ms:id_didok>
        <ms:name>Bissegg, Junkholz</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721051.896000 1269039.636000</gml:lowerCorner>
        		<gml:upperCorner>2721051.896000 1269039.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.583.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721051.896000 1269039.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>583</ms:objectid>
        <ms:id_didok>8506854</ms:id_didok>
        <ms:name>Bissegg, Wilerstrasse</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707877.405000 1269145.927000</gml:lowerCorner>
        		<gml:upperCorner>2707877.405000 1269145.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.528.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707877.405000 1269145.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>528</ms:objectid>
        <ms:id_didok>8506955</ms:id_didok>
        <ms:name>Frauenfeld, Osterhalden</ms:name>
        <ms:linien_nummer>80.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709326.610000 1269107.603000</gml:lowerCorner>
        		<gml:upperCorner>2709326.610000 1269107.603000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.729.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709326.610000 1269107.603000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>729</ms:objectid>
        <ms:id_didok>8573321</ms:id_didok>
        <ms:name>Frauenfeld, Thurstrasse</ms:name>
        <ms:linien_nummer>80.823, 80.825</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719715.884000 1268778.497000</gml:lowerCorner>
        		<gml:upperCorner>2719715.884000 1268778.497000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.585.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719715.884000 1268778.497000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>585</ms:objectid>
        <ms:id_didok>85069710</ms:id_didok>
        <ms:name>Griesenberg, Hub</ms:name>
        <ms:linien_nummer>80.383</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739351.920000 1270100.951000</gml:lowerCorner>
        		<gml:upperCorner>2739351.920000 1270100.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.753.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739351.920000 1270100.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>753</ms:objectid>
        <ms:id_didok>8587215</ms:id_didok>
        <ms:name>Sommeri, Kirche
</ms:name>
        <ms:linien_nummer>80.944</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708611.445000 1273060.550000</gml:lowerCorner>
        		<gml:upperCorner>2708611.445000 1273060.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.736.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708611.445000 1273060.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>736</ms:objectid>
        <ms:id_didok>8573326</ms:id_didok>
        <ms:name>Hüttwilen, Neumühle</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2709915.743000 1268103.784000</gml:lowerCorner>
        		<gml:upperCorner>2709915.743000 1268103.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.724.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2709915.743000 1268103.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>724</ms:objectid>
        <ms:id_didok>8506732</ms:id_didok>
        <ms:name>Frauenfeld, Marktplatz</ms:name>
        <ms:linien_nummer>80.834, 80.837, 80.838</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712212.288000 1256386.546000</gml:lowerCorner>
        		<gml:upperCorner>2712212.288000 1256386.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.787.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712212.288000 1256386.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>787</ms:objectid>
        <ms:id_didok>8578627</ms:id_didok>
        <ms:name>Bichelsee, Volg</ms:name>
        <ms:linien_nummer>80.735</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717001.298000 1258333.195000</gml:lowerCorner>
        		<gml:upperCorner>2717001.298000 1258333.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.679.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717001.298000 1258333.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>679</ms:objectid>
        <ms:id_didok>8502940</ms:id_didok>
        <ms:name>Sirnach, Pumpwerkstrasse</ms:name>
        <ms:linien_nummer></ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725418.574000 1269788.912000</gml:lowerCorner>
        		<gml:upperCorner>2725418.574000 1269788.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.269.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725418.574000 1269788.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>269</ms:objectid>
        <ms:id_didok>8573286</ms:id_didok>
        <ms:name>Weinfelden, Bahnhof</ms:name>
        <ms:linien_nummer>80.722, 80.833, 80.838, 80.921, 80.924, 80.932, 80.935</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713468.850000 1255302.911000</gml:lowerCorner>
        		<gml:upperCorner>2713468.850000 1255302.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.380.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713468.850000 1255302.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>380</ms:objectid>
        <ms:id_didok>8595875</ms:id_didok>
        <ms:name>Itaslen, alte Landstrasse</ms:name>
        <ms:linien_nummer>70.806</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.64">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715767.458000 1264732.576000</gml:lowerCorner>
        		<gml:upperCorner>2715767.458000 1264732.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.64.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715767.458000 1264732.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>64</ms:objectid>
        <ms:id_didok>8573626</ms:id_didok>
        <ms:name>Kalthäusern, Dorf</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718226.025000 1267658.684000</gml:lowerCorner>
        		<gml:upperCorner>2718226.025000 1267658.684000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.580.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718226.025000 1267658.684000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>580</ms:objectid>
        <ms:id_didok>8573367</ms:id_didok>
        <ms:name>Amlikon-Bisseg, Wolfikon</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729092.739000 1277689.904000</gml:lowerCorner>
        		<gml:upperCorner>2729092.739000 1277689.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.795.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729092.739000 1277689.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>795</ms:objectid>
        <ms:id_didok>8573392</ms:id_didok>
        <ms:name>Kreuzlingen, Kirche Bernrain</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735678.654000 1269879.882000</gml:lowerCorner>
        		<gml:upperCorner>2735678.654000 1269879.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.669.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735678.654000 1269879.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>669</ms:objectid>
        <ms:id_didok>8582166</ms:id_didok>
        <ms:name>Kümmertshausen, Hauptstrasse</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.24">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736640.705000 1271658.110000</gml:lowerCorner>
        		<gml:upperCorner>2736640.705000 1271658.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.24.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736640.705000 1271658.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>24</ms:objectid>
        <ms:id_didok>8582191</ms:id_didok>
        <ms:name>Langrickenbach, Neuhof</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717067.704000 1264177.314000</gml:lowerCorner>
        		<gml:upperCorner>2717067.704000 1264177.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.642.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717067.704000 1264177.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>642</ms:objectid>
        <ms:id_didok>8573623</ms:id_didok>
        <ms:name>Lommis, Matzingerstrasse</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2700004.216000 1273629.139000</gml:lowerCorner>
        		<gml:upperCorner>2700004.216000 1273629.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.603.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2700004.216000 1273629.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>603</ms:objectid>
        <ms:id_didok>8506953</ms:id_didok>
        <ms:name>Oberneunforn, Gemeindehaus</ms:name>
        <ms:linien_nummer>70.822</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714961.038000 1254360.394000</gml:lowerCorner>
        		<gml:upperCorner>2714961.038000 1254360.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.848.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714961.038000 1254360.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>848</ms:objectid>
        <ms:id_didok>8506852</ms:id_didok>
        <ms:name>Dussnang, Kirche/Klinik</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714062.131000 1264850.784000</gml:lowerCorner>
        		<gml:upperCorner>2714062.131000 1264850.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.477.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714062.131000 1264850.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>477</ms:objectid>
        <ms:id_didok>8573628</ms:id_didok>
        <ms:name>Stettfurt, Dorfzentrum</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718633.320000 1267960.810000</gml:lowerCorner>
        		<gml:upperCorner>2718633.320000 1267960.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.579.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718633.320000 1267960.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>579</ms:objectid>
        <ms:id_didok>8573368</ms:id_didok>
        <ms:name>Strohwilen, Dorf</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718429.314000 1267813.709000</gml:lowerCorner>
        		<gml:upperCorner>2718429.314000 1267813.709000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.587.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718429.314000 1267813.709000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>587</ms:objectid>
        <ms:id_didok>8506959</ms:id_didok>
        <ms:name>Strohwilen-Wolfikon, Käserei</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715439.741000 1267395.060000</gml:lowerCorner>
        		<gml:upperCorner>2715439.741000 1267395.060000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.574.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715439.741000 1267395.060000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>574</ms:objectid>
        <ms:id_didok>8506949</ms:id_didok>
        <ms:name>Thundorf, Aufhofen</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715031.300000 1267303.867000</gml:lowerCorner>
        		<gml:upperCorner>2715031.300000 1267303.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.581.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715031.300000 1267303.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>581</ms:objectid>
        <ms:id_didok>8506964</ms:id_didok>
        <ms:name>Thundorf, Friedbergstrasse</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708468.597000 1271165.235000</gml:lowerCorner>
        		<gml:upperCorner>2708468.597000 1271165.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.303.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708468.597000 1271165.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>303</ms:objectid>
        <ms:id_didok>8573323</ms:id_didok>
        <ms:name>Warth, Breite</ms:name>
        <ms:linien_nummer>80.819, 80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716533.356000 1267745.348000</gml:lowerCorner>
        		<gml:upperCorner>2716533.356000 1267745.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.586.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716533.356000 1267745.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>586</ms:objectid>
        <ms:id_didok>8506886</ms:id_didok>
        <ms:name>Lustdorf, Kirche</ms:name>
        <ms:linien_nummer>80.383</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716518.532000 1264703.340000</gml:lowerCorner>
        		<gml:upperCorner>2716518.532000 1264703.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.644.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716518.532000 1264703.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>644</ms:objectid>
        <ms:id_didok>8573624</ms:id_didok>
        <ms:name>Weingarten, Brücke</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735154.132000 1274715.067000</gml:lowerCorner>
        		<gml:upperCorner>2735154.132000 1274715.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.271.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735154.132000 1274715.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>271</ms:objectid>
        <ms:id_didok>8506614</ms:id_didok>
        <ms:name>Zuben, Käserei</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739583.530000 1267692.573000</gml:lowerCorner>
        		<gml:upperCorner>2739583.530000 1267692.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.423.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739583.530000 1267692.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>423</ms:objectid>
        <ms:id_didok>8587140</ms:id_didok>
        <ms:name>Amriswil, Quellenhof</ms:name>
        <ms:linien_nummer>80.931, 80.942, 80.943</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736460.594000 1262307.774000</gml:lowerCorner>
        		<gml:upperCorner>2736460.594000 1262307.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.176.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736460.594000 1262307.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>176</ms:objectid>
        <ms:id_didok>8578800</ms:id_didok>
        <ms:name>Bischofszell, Pflegeheim</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736698.239000 1262347.569000</gml:lowerCorner>
        		<gml:upperCorner>2736698.239000 1262347.569000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.177.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736698.239000 1262347.569000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>177</ms:objectid>
        <ms:id_didok>8578801</ms:id_didok>
        <ms:name>Bischofszell, Stocken</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729909.884000 1265421.373000</gml:lowerCorner>
        		<gml:upperCorner>2729909.884000 1265421.373000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.469.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729909.884000 1265421.373000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>469</ms:objectid>
        <ms:id_didok>8506555</ms:id_didok>
        <ms:name>Buhwil, Dorf</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739434.096000 1261463.326000</gml:lowerCorner>
        		<gml:upperCorner>2739434.096000 1261463.326000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.489.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739434.096000 1261463.326000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>489</ms:objectid>
        <ms:id_didok>8578805</ms:id_didok>
        <ms:name>Wilen (Gottshaus), Hoferberg</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739535.628000 1261256.487000</gml:lowerCorner>
        		<gml:upperCorner>2739535.628000 1261256.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.490.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739535.628000 1261256.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>490</ms:objectid>
        <ms:id_didok>8578806</ms:id_didok>
        <ms:name>Wilen (Gottshaus), Lauften</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735453.154000 1274330.340000</gml:lowerCorner>
        		<gml:upperCorner>2735453.154000 1274330.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.272.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735453.154000 1274330.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>272</ms:objectid>
        <ms:id_didok>8573418</ms:id_didok>
        <ms:name>Zuben, Kreuzstrasse</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721433.814000 1257255.496000</gml:lowerCorner>
        		<gml:upperCorner>2721433.814000 1257255.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.441.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721433.814000 1257255.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>441</ms:objectid>
        <ms:id_didok>8573926</ms:id_didok>
        <ms:name>Wil SG, Rapp</ms:name>
        <ms:linien_nummer>80.729 (Regiobus), 80.730 (PostAuto), 80.731 (Regiobus)</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715490.479000 1254424.049000</gml:lowerCorner>
        		<gml:upperCorner>2715490.479000 1254424.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.793.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715490.479000 1254424.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>793</ms:objectid>
        <ms:id_didok>8506851</ms:id_didok>
        <ms:name>Oberwangen TG, Sonnenhof</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730351.319000 1279439.540000</gml:lowerCorner>
        		<gml:upperCorner>2730351.319000 1279439.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.332.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730351.319000 1279439.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>332</ms:objectid>
        <ms:id_didok>8581697</ms:id_didok>
        <ms:name>Kreuzlingen, Helvetiaplatz</ms:name>
        <ms:linien_nummer>80.908</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.11">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736594.002000 1275053.944000</gml:lowerCorner>
        		<gml:upperCorner>2736594.002000 1275053.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.11.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736594.002000 1275053.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>11</ms:objectid>
        <ms:id_didok>8581675</ms:id_didok>
        <ms:name>Altnau, Schmitteweg</ms:name>
        <ms:linien_nummer>80.923, 80.925</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722977.491000 1262641.565000</gml:lowerCorner>
        		<gml:upperCorner>2722977.491000 1262641.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.157.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722977.491000 1262641.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>157</ms:objectid>
        <ms:id_didok>8506655</ms:id_didok>
        <ms:name>Braunau, Dorf</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.19">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735970.090000 1273087.424000</gml:lowerCorner>
        		<gml:upperCorner>2735970.090000 1273087.424000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.19.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735970.090000 1273087.424000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>19</ms:objectid>
        <ms:id_didok>8506611</ms:id_didok>
        <ms:name>Langrickenbach, Dorf</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721315.935000 1253347.334000</gml:lowerCorner>
        		<gml:upperCorner>2721315.935000 1253347.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.557.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721315.935000 1253347.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>557</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Wolfikon SG, Engel</ms:name>
        <ms:linien_nummer></ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720796.959000 1252185.210000</gml:lowerCorner>
        		<gml:upperCorner>2720796.959000 1252185.210000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.384.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720796.959000 1252185.210000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>384</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Kirchberg SG, Florastrasse</ms:name>
        <ms:linien_nummer>80.732</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2752198.824000 1262059.712000</gml:lowerCorner>
        		<gml:upperCorner>2752198.824000 1262059.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.846.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2752198.824000 1262059.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>846</ms:objectid>
        <ms:id_didok>8574276</ms:id_didok>
        <ms:name>Horn, Grünau</ms:name>
        <ms:linien_nummer>80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728827.802000 1265173.085000</gml:lowerCorner>
        		<gml:upperCorner>2728827.802000 1265173.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.487.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728827.802000 1265173.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>487</ms:objectid>
        <ms:id_didok>8506574</ms:id_didok>
        <ms:name>Schönholzerswilen, Ritzisbuhwil</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720101.563000 1273067.366000</gml:lowerCorner>
        		<gml:upperCorner>2720101.563000 1273067.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.847.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720101.563000 1273067.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>847</ms:objectid>
        <ms:id_didok>8507928</ms:id_didok>
        <ms:name>Wigoltingen, Engwangerstrasse</ms:name>
        <ms:linien_nummer>80.832</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726560.706000 1269529.191000</gml:lowerCorner>
        		<gml:upperCorner>2726560.706000 1269529.191000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.270.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726560.706000 1269529.191000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>270</ms:objectid>
        <ms:id_didok>8506573</ms:id_didok>
        <ms:name>Weinfelden, Alterszentrum</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.76">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726463.577000 1269773.275000</gml:lowerCorner>
        		<gml:upperCorner>2726463.577000 1269773.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.76.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726463.577000 1269773.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>76</ms:objectid>
        <ms:id_didok>8581851</ms:id_didok>
        <ms:name>Weinfelden, Zedernpark</ms:name>
        <ms:linien_nummer>80.924</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716372.055000 1264877.087000</gml:lowerCorner>
        		<gml:upperCorner>2716372.055000 1264877.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.457.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716372.055000 1264877.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>457</ms:objectid>
        <ms:id_didok>8573625</ms:id_didok>
        <ms:name>Weingarten-Kalthäusern, Dorfstrasse</ms:name>
        <ms:linien_nummer>80.837</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2696549.005000 1278244.784000</gml:lowerCorner>
        		<gml:upperCorner>2696549.005000 1278244.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.850.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2696549.005000 1278244.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>850</ms:objectid>
        <ms:id_didok>0</ms:id_didok>
        <ms:name>Dickihof</ms:name>
        <ms:linien_nummer>80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2706454.214000 1279324.572000</gml:lowerCorner>
        		<gml:upperCorner>2706454.214000 1279324.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.314.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2706454.214000 1279324.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>314</ms:objectid>
        <ms:id_didok>8573327</ms:id_didok>
        <ms:name>Stein am Rhein, Bahnhof</ms:name>
        <ms:linien_nummer>80.734, 80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721534.459000 1258645.354000</gml:lowerCorner>
        		<gml:upperCorner>2721534.459000 1258645.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.613.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721534.459000 1258645.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>613</ms:objectid>
        <ms:id_didok>8506672</ms:id_didok>
        <ms:name>Wil SG, Hof zu Wil</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721268.651000 1258477.385000</gml:lowerCorner>
        		<gml:upperCorner>2721268.651000 1258477.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.612.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721268.651000 1258477.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>612</ms:objectid>
        <ms:id_didok>8573603</ms:id_didok>
        <ms:name>Wil SG, Rose</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720959.476000 1258327.374000</gml:lowerCorner>
        		<gml:upperCorner>2720959.476000 1258327.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.614.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720959.476000 1258327.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>614</ms:objectid>
        <ms:id_didok>8573616</ms:id_didok>
        <ms:name>Wil SG, Schwanen</ms:name>
        <ms:linien_nummer>80.706, 80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721769.817000 1258781.783000</gml:lowerCorner>
        		<gml:upperCorner>2721769.817000 1258781.783000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.611.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721769.817000 1258781.783000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>611</ms:objectid>
        <ms:id_didok>8573604</ms:id_didok>
        <ms:name>Wil SG, Kapuziner Kloster</ms:name>
        <ms:linien_nummer>80.722</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2705661.899000 1278939.597000</gml:lowerCorner>
        		<gml:upperCorner>2705661.899000 1278939.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.851.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2705661.899000 1278939.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>851</ms:objectid>
        <ms:id_didok>8511124</ms:id_didok>
        <ms:name>Kaltenbach, Schööferwis</ms:name>
        <ms:linien_nummer>80.825</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747742.251000 1260910.219000</gml:lowerCorner>
        		<gml:upperCorner>2747742.251000 1260910.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.592.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747742.251000 1260910.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>592</ms:objectid>
        <ms:id_didok>8506708</ms:id_didok>
        <ms:name>Freidorf TG, Kreuzegg</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.92">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748977.892000 1263823.838000</gml:lowerCorner>
        		<gml:upperCorner>2748977.892000 1263823.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.92.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748977.892000 1263823.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>92</ms:objectid>
        <ms:id_didok>8574246</ms:id_didok>
        <ms:name>Arbon, Alpenblick</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750149.052000 1264168.414000</gml:lowerCorner>
        		<gml:upperCorner>2750149.052000 1264168.414000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.194.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750149.052000 1264168.414000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>194</ms:objectid>
        <ms:id_didok>8574251</ms:id_didok>
        <ms:name>Arbon, Bahnhof</ms:name>
        <ms:linien_nummer>80.200, 80.201, 80.207, 80.210, 80.211, 80.940, 80.941</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749498.436000 1264006.740000</gml:lowerCorner>
        		<gml:upperCorner>2749498.436000 1264006.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.588.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749498.436000 1264006.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>588</ms:objectid>
        <ms:id_didok>8506255</ms:id_didok>
        <ms:name>Arbon, Wildpark</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749423.969000 1262808.206000</gml:lowerCorner>
        		<gml:upperCorner>2749423.969000 1262808.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.560.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749423.969000 1262808.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>560</ms:objectid>
        <ms:id_didok>8557031</ms:id_didok>
        <ms:name>Arbon, Kupferwiese</ms:name>
        <ms:linien_nummer>80.201, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748421.954000 1265233.811000</gml:lowerCorner>
        		<gml:upperCorner>2748421.954000 1265233.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.858.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748421.954000 1265233.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>858</ms:objectid>
        <ms:id_didok>8587220</ms:id_didok>
        <ms:name>Frasnacht, Rotbuch</ms:name>
        <ms:linien_nummer>80.940</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2698374.829000 1280685.221000</gml:lowerCorner>
        		<gml:upperCorner>2698374.829000 1280685.221000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.744.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2698374.829000 1280685.221000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>744</ms:objectid>
        <ms:id_didok>8506975</ms:id_didok>
        <ms:name>Basadingen, Unterdorf</ms:name>
        <ms:linien_nummer>80.823, 80.847</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718827.404000 1256718.968000</gml:lowerCorner>
        		<gml:upperCorner>2718827.404000 1256718.968000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.472.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718827.404000 1256718.968000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>472</ms:objectid>
        <ms:id_didok>8578791</ms:id_didok>
        <ms:name>Busswil TG, Hauptstrasse</ms:name>
        <ms:linien_nummer>80.733</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2750769.070000 1262847.140000</gml:lowerCorner>
        		<gml:upperCorner>2750769.070000 1262847.140000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.857.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2750769.070000 1262847.140000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>857</ms:objectid>
        <ms:id_didok>8580869</ms:id_didok>
        <ms:name>Steinach, Schule</ms:name>
        <ms:linien_nummer>80.210</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728205.702000 1264225.917000</gml:lowerCorner>
        		<gml:upperCorner>2728205.702000 1264225.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.859.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728205.702000 1264225.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>859</ms:objectid>
        <ms:id_didok>8506575</ms:id_didok>
        <ms:name>Schönholzerswilen, Gemeindehaus</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2723312.727000 1270672.902000</gml:lowerCorner>
        		<gml:upperCorner>2723312.727000 1270672.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.861.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2723312.727000 1270672.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>861</ms:objectid>
        <ms:id_didok>8573372</ms:id_didok>
        <ms:name>Ottoberg, Feldhof</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2698661.895000 1282478.138000</gml:lowerCorner>
        		<gml:upperCorner>2698661.895000 1282478.138000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.747.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2698661.895000 1282478.138000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>747</ms:objectid>
        <ms:id_didok>8573334</ms:id_didok>
        <ms:name>Diessenhofen, Bahnhof</ms:name>
        <ms:linien_nummer>80.823, 80.847</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718962.420000 1257109.904000</gml:lowerCorner>
        		<gml:upperCorner>2718962.420000 1257109.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.862.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718962.420000 1257109.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>862</ms:objectid>
        <ms:id_didok>8578792</ms:id_didok>
        <ms:name>Busswil TG, Dorfplatz</ms:name>
        <ms:linien_nummer>80.733</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737084.426000 1256301.394000</gml:lowerCorner>
        		<gml:upperCorner>2737084.426000 1256301.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.881.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737084.426000 1256301.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>881</ms:objectid>
        <ms:id_didok>8573957</ms:id_didok>
        <ms:name>Arnegg, Weideggstrasse</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737781.818000 1255944.568000</gml:lowerCorner>
        		<gml:upperCorner>2737781.818000 1255944.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.882.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737781.818000 1255944.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>882</ms:objectid>
        <ms:id_didok>8573956</ms:id_didok>
        <ms:name>Andwil SG, Grünau</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738320.380000 1255498.046000</gml:lowerCorner>
        		<gml:upperCorner>2738320.380000 1255498.046000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.884.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738320.380000 1255498.046000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>884</ms:objectid>
        <ms:id_didok>8573955</ms:id_didok>
        <ms:name>Andwil SG, Otmarsegg</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2738245.537000 1254510.944000</gml:lowerCorner>
        		<gml:upperCorner>2738245.537000 1254510.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.885.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2738245.537000 1254510.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>885</ms:objectid>
        <ms:id_didok>8506254</ms:id_didok>
        <ms:name>Andwil SG, St. Margreten</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737996.830000 1253655.634000</gml:lowerCorner>
        		<gml:upperCorner>2737996.830000 1253655.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.886.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737996.830000 1253655.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>886</ms:objectid>
        <ms:id_didok>8591867</ms:id_didok>
        <ms:name>Gossau SG, Ulmenstrasse</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737691.906000 1253276.541000</gml:lowerCorner>
        		<gml:upperCorner>2737691.906000 1253276.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.887.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737691.906000 1253276.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>887</ms:objectid>
        <ms:id_didok>8588496</ms:id_didok>
        <ms:name>Gossau SG, Mooswies</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736607.134000 1253143.126000</gml:lowerCorner>
        		<gml:upperCorner>2736607.134000 1253143.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.889.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736607.134000 1253143.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>889</ms:objectid>
        <ms:id_didok>8588495</ms:id_didok>
        <ms:name>Gossau SG, Herisauerstrasse</ms:name>
        <ms:linien_nummer>80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721527.806000 1256453.810000</gml:lowerCorner>
        		<gml:upperCorner>2721527.806000 1256453.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.412.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721527.806000 1256453.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>412</ms:objectid>
        <ms:id_didok>8506676</ms:id_didok>
        <ms:name>Rickenbach bei Wil, Zentrum</ms:name>
        <ms:linien_nummer>80.731, 80.732</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720754.193000 1258900.303000</gml:lowerCorner>
        		<gml:upperCorner>2720754.193000 1258900.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.458.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720754.193000 1258900.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>458</ms:objectid>
        <ms:id_didok>8591791</ms:id_didok>
        <ms:name>Wil SG, Eggfeld</ms:name>
        <ms:linien_nummer>80.706</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747447.503000 1258879.257000</gml:lowerCorner>
        		<gml:upperCorner>2747447.503000 1258879.257000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.590.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747447.503000 1258879.257000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>590</ms:objectid>
        <ms:id_didok>8574242</ms:id_didok>
        <ms:name>Wittenbach, Hofen</ms:name>
        <ms:linien_nummer>80.200, 80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746002.884000 1258785.899000</gml:lowerCorner>
        		<gml:upperCorner>2746002.884000 1258785.899000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.211.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746002.884000 1258785.899000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>211</ms:objectid>
        <ms:id_didok>8574254</ms:id_didok>
        <ms:name>Wittenbach, Im Grüntal</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2749375.440000 1262496.025000</gml:lowerCorner>
        		<gml:upperCorner>2749375.440000 1262496.025000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.854.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2749375.440000 1262496.025000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>854</ms:objectid>
        <ms:id_didok>8511131</ms:id_didok>
        <ms:name>Berg SG, Landquart</ms:name>
        <ms:linien_nummer>80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748332.278000 1261354.262000</gml:lowerCorner>
        		<gml:upperCorner>2748332.278000 1261354.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.855.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748332.278000 1261354.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>855</ms:objectid>
        <ms:id_didok>8511125</ms:id_didok>
        <ms:name>Berg SG, Dorf</ms:name>
        <ms:linien_nummer>80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2748532.937000 1261611.562000</gml:lowerCorner>
        		<gml:upperCorner>2748532.937000 1261611.562000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.856.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2748532.937000 1261611.562000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>856</ms:objectid>
        <ms:id_didok>8511126</ms:id_didok>
        <ms:name>Berg SG, Brühl</ms:name>
        <ms:linien_nummer>80.207</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717593.825000 1259657.731000</gml:lowerCorner>
        		<gml:upperCorner>2717593.825000 1259657.731000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.825.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717593.825000 1259657.731000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>825</ms:objectid>
        <ms:id_didok>8510759</ms:id_didok>
        <ms:name>Münchwilen TG, Bahnhof Nord</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716940.355000 1260276.888000</gml:lowerCorner>
        		<gml:upperCorner>2716940.355000 1260276.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.893.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716940.355000 1260276.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>893</ms:objectid>
        <ms:id_didok>8503444</ms:id_didok>
        <ms:name>Münchwilen TG, Brunnenstrasse</ms:name>
        <ms:linien_nummer>80.841 (Kantibus)</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715834.203000 1261305.814000</gml:lowerCorner>
        		<gml:upperCorner>2715834.203000 1261305.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.894.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715834.203000 1261305.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>894</ms:objectid>
        <ms:id_didok>8503445</ms:id_didok>
        <ms:name>Wängi, Rosental</ms:name>
        <ms:linien_nummer>80.841 (Kantibus)</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713845.109000 1262401.130000</gml:lowerCorner>
        		<gml:upperCorner>2713845.109000 1262401.130000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.896.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713845.109000 1262401.130000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>896</ms:objectid>
        <ms:id_didok>8503515</ms:id_didok>
        <ms:name>Wängi, Froheggstrasse</ms:name>
        <ms:linien_nummer>80.841 (Kantibus)</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714190.178000 1261955.634000</gml:lowerCorner>
        		<gml:upperCorner>2714190.178000 1261955.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.895.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714190.178000 1261955.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>895</ms:objectid>
        <ms:id_didok>8503448</ms:id_didok>
        <ms:name>Wängi, Dorfschulhaus</ms:name>
        <ms:linien_nummer>80.841 (Kantibus)</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712486.801000 1264174.547000</gml:lowerCorner>
        		<gml:upperCorner>2712486.801000 1264174.547000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.897.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712486.801000 1264174.547000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>897</ms:objectid>
        <ms:id_didok>8503516</ms:id_didok>
        <ms:name>Matzingen, Kirche</ms:name>
        <ms:linien_nummer>80.841 (Kantibus)</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710272.997000 1268429.880000</gml:lowerCorner>
        		<gml:upperCorner>2710272.997000 1268429.880000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.898.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710272.997000 1268429.880000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>898</ms:objectid>
        <ms:id_didok>8594733</ms:id_didok>
        <ms:name>Frauenfeld, Kantonsschule</ms:name>
        <ms:linien_nummer>80.841 (Kantibus)</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720881.918000 1257957.602000</gml:lowerCorner>
        		<gml:upperCorner>2720881.918000 1257957.602000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.473.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720881.918000 1257957.602000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>473</ms:objectid>
        <ms:id_didok>8578826</ms:id_didok>
        <ms:name>Wil SG, Bahnhof Süd</ms:name>
        <ms:linien_nummer>80.702, 80.733, 80.735</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719497.184000 1263269.754000</gml:lowerCorner>
        		<gml:upperCorner>2719497.184000 1263269.754000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.824.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719497.184000 1263269.754000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>824</ms:objectid>
        <ms:id_didok>85107610</ms:id_didok>
        <ms:name>Tägerschen, Bahnhof</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2710078.525000 1261063.744000</gml:lowerCorner>
        		<gml:upperCorner>2710078.525000 1261063.744000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.121.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2710078.525000 1261063.744000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>121</ms:objectid>
        <ms:id_didok>8573362</ms:id_didok>
        <ms:name>Aadorf, Zentrum</ms:name>
        <ms:linien_nummer>80.834</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport></ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2721339.282000 1257681.587000</gml:lowerCorner>
        		<gml:upperCorner>2721339.282000 1257681.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.439.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2721339.282000 1257681.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>439</ms:objectid>
        <ms:id_didok>8506677</ms:id_didok>
        <ms:name>Wil SG, Lindenhof</ms:name>
        <ms:linien_nummer>80.729 (Regiobus), 80.730 (PostAuto), 80.731 (Regiobus)</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.30">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712835.947000 1275752.010000</gml:lowerCorner>
        		<gml:upperCorner>2712835.947000 1275752.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.30.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712835.947000 1275752.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>30</ms:objectid>
        <ms:id_didok>8506882</ms:id_didok>
        <ms:name>Lanzenneunforn, Dorf</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2718181.830000 1273855.686000</gml:lowerCorner>
        		<gml:upperCorner>2718181.830000 1273855.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.296.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2718181.830000 1273855.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>296</ms:objectid>
        <ms:id_didok>8573345</ms:id_didok>
        <ms:name>Müllheim Dorf, Kirche</ms:name>
        <ms:linien_nummer>80.829, 80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716447.012000 1256457.154000</gml:lowerCorner>
        		<gml:upperCorner>2716447.012000 1256457.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.899.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716447.012000 1256457.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>899</ms:objectid>
        <ms:id_didok>8506678</ms:id_didok>
        <ms:name>Wiezikon b. Sirnach, Weingarten</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2722343.420000 1278080.783000</gml:lowerCorner>
        		<gml:upperCorner>2722343.420000 1278080.783000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.900.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2722343.420000 1278080.783000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>900</ms:objectid>
        <ms:id_didok>8506986</ms:id_didok>
        <ms:name>Helsighausen, Kreuzung</ms:name>
        <ms:linien_nummer>80.833</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730297.671000 1278535.157000</gml:lowerCorner>
        		<gml:upperCorner>2730297.671000 1278535.157000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.901.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730297.671000 1278535.157000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>901</ms:objectid>
        <ms:id_didok>8580245</ms:id_didok>
        <ms:name>Kreuzlingen, Rosenegg</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2746009.695000 1254490.540000</gml:lowerCorner>
        		<gml:upperCorner>2746009.695000 1254490.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.902.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2746009.695000 1254490.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>902</ms:objectid>
        <ms:id_didok>8589609</ms:id_didok>
        <ms:name>St. Gallen, Poststrasse</ms:name>
        <ms:linien_nummer>80.200, 80.210, 80.211</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2735891.303000 1261760.447000</gml:lowerCorner>
        		<gml:upperCorner>2735891.303000 1261760.447000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.903.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2735891.303000 1261760.447000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>903</ms:objectid>
        <ms:id_didok>8506588</ms:id_didok>
        <ms:name>Bischofszell Stadt, Bahnhof</ms:name>
        <ms:linien_nummer>80.740, 80.943, 80.950, 80.N50</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729904.327000 1265182.046000</gml:lowerCorner>
        		<gml:upperCorner>2729904.327000 1265182.046000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.179.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729904.327000 1265182.046000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>179</ms:objectid>
        <ms:id_didok>8581621</ms:id_didok>
        <ms:name>Buhwil, Oberdorf</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2708544.949000 1271154.327000</gml:lowerCorner>
        		<gml:upperCorner>2708544.949000 1271154.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.733.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2708544.949000 1271154.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>733</ms:objectid>
        <ms:id_didok>8502746</ms:id_didok>
        <ms:name>Warth, Rohr</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.60">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2743897.974000 1262127.161000</gml:lowerCorner>
        		<gml:upperCorner>2743897.974000 1262127.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.60.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2743897.974000 1262127.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>60</ms:objectid>
        <ms:id_didok>8574220</ms:id_didok>
        <ms:name>Häggenschwil, Scheidweg</ms:name>
        <ms:linien_nummer>80.205</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.2">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2715839.190000 1280472.133000</gml:lowerCorner>
        		<gml:upperCorner>2715839.190000 1280472.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.2.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2715839.190000 1280472.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>2</ms:objectid>
        <ms:id_didok>8573341</ms:id_didok>
        <ms:name>Steckborn, Bahnhof</ms:name>
        <ms:linien_nummer>80.826, BN820</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tag- und Nachtnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724847.832000 1269613.275000</gml:lowerCorner>
        		<gml:upperCorner>2724847.832000 1269613.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.827.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724847.832000 1269613.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>827</ms:objectid>
        <ms:id_didok>8502549</ms:id_didok>
        <ms:name>Weinfelden, Dufourstrasse</ms:name>
        <ms:linien_nummer>80.722, 80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.40">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2712999.917000 1267277.475000</gml:lowerCorner>
        		<gml:upperCorner>2712999.917000 1267277.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.40.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2712999.917000 1267277.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>40</ms:objectid>
        <ms:id_didok>8581297</ms:id_didok>
        <ms:name>Dingenhart, Stählibuck</ms:name>
        <ms:linien_nummer>80.838</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.41">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747591.991000 1266581.451000</gml:lowerCorner>
        		<gml:upperCorner>2747591.991000 1266581.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.41.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747591.991000 1266581.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>41</ms:objectid>
        <ms:id_didok>8587163</ms:id_didok>
        <ms:name>Egnach, Wiedehorn</ms:name>
        <ms:linien_nummer>80.941</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.12">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2727657.476000 1275027.624000</gml:lowerCorner>
        		<gml:upperCorner>2727657.476000 1275027.624000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.12.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2727657.476000 1275027.624000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>12</ms:objectid>
        <ms:id_didok>8506557</ms:id_didok>
        <ms:name>Ellighausen, Dorf</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.31">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2713761.553000 1272744.020000</gml:lowerCorner>
        		<gml:upperCorner>2713761.553000 1272744.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.31.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2713761.553000 1272744.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>31</ms:objectid>
        <ms:id_didok>8506627</ms:id_didok>
        <ms:name>Pfyn, Bürgi</ms:name>
        <ms:linien_nummer>80.826</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2747587.146000 1258220.268000</gml:lowerCorner>
        		<gml:upperCorner>2747587.146000 1258220.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.864.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2747587.146000 1258220.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>864</ms:objectid>
        <ms:id_didok>8506263</ms:id_didok>
        <ms:name>Kronbühl, alte Post</ms:name>
        <ms:linien_nummer>80.200</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2725249.293000 1270572.117000</gml:lowerCorner>
        		<gml:upperCorner>2725249.293000 1270572.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.268.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2725249.293000 1270572.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>268</ms:objectid>
        <ms:id_didok>8582806</ms:id_didok>
        <ms:name>Weinfelden, Bachtobelstrasse</ms:name>
        <ms:linien_nummer>80.921</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2720572.698000 1258346.215000</gml:lowerCorner>
        		<gml:upperCorner>2720572.698000 1258346.215000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.833.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2720572.698000 1258346.215000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>833</ms:objectid>
        <ms:id_didok>8578597</ms:id_didok>
        <ms:name>Wil SG, Psychiatrie</ms:name>
        <ms:linien_nummer>80.733 (Abendkurs), 80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2724510.900000 1277316.762000</gml:lowerCorner>
        		<gml:upperCorner>2724510.900000 1277316.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.541.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2724510.900000 1277316.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>541</ms:objectid>
        <ms:id_didok>8506568</ms:id_didok>
        <ms:name>Wäldi, Dorfplatz</ms:name>
        <ms:linien_nummer>80.920</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716861.858000 1257429.284000</gml:lowerCorner>
        		<gml:upperCorner>2716861.858000 1257429.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.716.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716861.858000 1257429.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>716</ms:objectid>
        <ms:id_didok>8578603</ms:id_didok>
        <ms:name>Sirnach, Weberei</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2716807.803000 1256830.212000</gml:lowerCorner>
        		<gml:upperCorner>2716807.803000 1256830.212000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.559.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2716807.803000 1256830.212000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>559</ms:objectid>
        <ms:id_didok>8595946</ms:id_didok>
        <ms:name>Wiezikon b.Sirnach, Widenacker</ms:name>
        <ms:linien_nummer>80.734</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2698489.100000 1281952.320000</gml:lowerCorner>
        		<gml:upperCorner>2698489.100000 1281952.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.746.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2698489.100000 1281952.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>746</ms:objectid>
        <ms:id_didok>8582826</ms:id_didok>
        <ms:name>Diessenhofen, Landi</ms:name>
        <ms:linien_nummer>80.823, 80.847</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2719280.395000 1258149.239000</gml:lowerCorner>
        		<gml:upperCorner>2719280.395000 1258149.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.720.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2719280.395000 1258149.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>720</ms:objectid>
        <ms:id_didok>8578599</ms:id_didok>
        <ms:name>Sirnach, Gloten</ms:name>
        <ms:linien_nummer>80.734, 80.735</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2717166.303000 1258634.804000</gml:lowerCorner>
        		<gml:upperCorner>2717166.303000 1258634.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.843.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2717166.303000 1258634.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>843</ms:objectid>
        <ms:id_didok>8508122</ms:id_didok>
        <ms:name>Sirnach, Ebnet</ms:name>
        <ms:linien_nummer>80.739</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2739428.130000 1274711.980000</gml:lowerCorner>
        		<gml:upperCorner>2739428.130000 1274711.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.714.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2739428.130000 1274711.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>714</ms:objectid>
        <ms:id_didok>8502631</ms:id_didok>
        <ms:name>Güttingen, Bahnhof</ms:name>
        <ms:linien_nummer>80.923</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Andere</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2707599.309000 1274003.568000</gml:lowerCorner>
        		<gml:upperCorner>2707599.309000 1274003.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.737.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2707599.309000 1274003.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>737</ms:objectid>
        <ms:id_didok>8506760</ms:id_didok>
        <ms:name>Hüttwilen, Zentrum</ms:name>
        <ms:linien_nummer>80.823</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714465.562000 1257367.439000</gml:lowerCorner>
        		<gml:upperCorner>2714465.562000 1257367.439000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.780.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714465.562000 1257367.439000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>780</ms:objectid>
        <ms:id_didok>8578629</ms:id_didok>
        <ms:name>Wallenwil, Schulhaus
</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2714344.111000 1257094.905000</gml:lowerCorner>
        		<gml:upperCorner>2714344.111000 1257094.905000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.781.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2714344.111000 1257094.905000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>781</ms:objectid>
        <ms:id_didok>8578630</ms:id_didok>
        <ms:name>Wallenwil, Frohsinn
</ms:name>
        <ms:linien_nummer>80.736</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>Bus Ostschweiz</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2736447.208000 1268981.862000</gml:lowerCorner>
        		<gml:upperCorner>2736447.208000 1268981.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.513.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2736447.208000 1268981.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>513</ms:objectid>
        <ms:id_didok>8582165</ms:id_didok>
        <ms:name>Engishofen, Dorfplatz</ms:name>
        <ms:linien_nummer>80.931</ms:linien_nummer>
        <ms:behig_status>true</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2729321.743000 1264968.526000</gml:lowerCorner>
        		<gml:upperCorner>2729321.743000 1264968.526000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.190.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2729321.743000 1264968.526000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>190</ms:objectid>
        <ms:id_didok>8573293</ms:id_didok>
        <ms:name>Buhwil, Hinterbach</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2737400.620000 1262779.564000</gml:lowerCorner>
        		<gml:upperCorner>2737400.620000 1262779.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.180.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2737400.620000 1262779.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>180</ms:objectid>
        <ms:id_didok>8578802</ms:id_didok>
        <ms:name>Eberswil, Abzw. Lütschwil</ms:name>
        <ms:linien_nummer>80.950</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Gemeinde</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726719.367000 1266176.386000</gml:lowerCorner>
        		<gml:upperCorner>2726719.367000 1266176.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.291.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726719.367000 1266176.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>291</ms:objectid>
        <ms:id_didok>8573609</ms:id_didok>
        <ms:name>Mettlen, Unterdorf</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2726931.578000 1265770.560000</gml:lowerCorner>
        		<gml:upperCorner>2726931.578000 1265770.560000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.486.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2726931.578000 1265770.560000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>486</ms:objectid>
        <ms:id_didok>8506662</ms:id_didok>
        <ms:name>Mettlen, Wilerstrasse</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2730603.395000 1263711.481000</gml:lowerCorner>
        		<gml:upperCorner>2730603.395000 1263711.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.391.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2730603.395000 1263711.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>391</ms:objectid>
        <ms:id_didok>8506572</ms:id_didok>
        <ms:name>Neukirch an der Thur, Dorf</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
    <wfs:member>
      <ms:bushalte gml:id="bushalte.653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2056">
        		<gml:lowerCorner>2728035.443000 1264396.950000</gml:lowerCorner>
        		<gml:upperCorner>2728035.443000 1264396.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="bushalte.653.1" srsName="urn:ogc:def:crs:EPSG::2056">
            <gml:pos>2728035.443000 1264396.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:objectid>653</ms:objectid>
        <ms:id_didok>8581618</ms:id_didok>
        <ms:name>Schönholzerswilen, Kirche</ms:name>
        <ms:linien_nummer>80.932</ms:linien_nummer>
        <ms:behig_status>false</ms:behig_status>
        <ms:name_transport>PostAuto</ms:name_transport>
        <ms:eigentum>Kanton</ms:eigentum>
        <ms:betriebszeiten>Tagnetz</ms:betriebszeiten>
      </ms:bushalte>
    </wfs:member>
</wfs:FeatureCollection>

